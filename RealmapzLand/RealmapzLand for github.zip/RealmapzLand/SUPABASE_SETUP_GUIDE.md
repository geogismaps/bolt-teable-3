# Supabase Field-Level Permissions Setup Guide

## Overview
This guide walks you through setting up the Supabase-based field-level permissions system for realmapz. The architecture stores only metadata (user accounts, permissions, audit logs) in Supabase while keeping all client land data in Google Sheets.

## Prerequisites
✅ You already have:
- Supabase account
- SUPABASE_URL configured in Replit Secrets
- SUPABASE_ANON_KEY configured in Replit Secrets
- SUPABASE_SERVICE_KEY configured in Replit Secrets

## Step 1: Run the SQL Schema

1. **Open Supabase SQL Editor**
   - Go to https://app.supabase.com
   - Select your project
   - Navigate to **SQL Editor** (left sidebar)

2. **Run the Schema Script**
   - Click **New query**
   - Copy the entire contents of `supabase-schema.sql` from this project
   - Paste into the SQL editor
   - Click **Run** (or press Ctrl/Cmd + Enter)

3. **Verify Success**
   - You should see a success message showing:
     - Organizations count: 1
     - Users count: 2
   - This confirms the tables and seed data were created

## Step 2: Verify Tables Created

Navigate to **Table Editor** in Supabase and verify these tables exist:
- ✅ `organizations` - Multi-tenant isolation
- ✅ `users` - User accounts with roles
- ✅ `google_sheet_connections` - Sheet metadata (no actual data)
- ✅ `field_permissions` - Field-level access control
- ✅ `activity_logs` - Audit trail

## Step 3: Understand the Data Model

### Organizations
- Each organization is isolated (multi-tenant)
- Demo org created: `Demo Organization`

### Users & Roles
- **Owner**: Full access, can manage everything
- **Admin**: Can manage users and permissions
- **Editor**: Can edit fields they have access to
- **Viewer**: Can only view fields (read-only)

Demo users created:
- `admin@demo.com` (admin role)
- `viewer@demo.com` (viewer role)

### Field Permissions
Each permission defines access to a specific field:
- **Connection**: Which Google Sheet
- **Sheet Name**: Which tab/sheet within the spreadsheet
- **Field Name**: Which column
- **Permission Level**:
  - `edit` - Can view and modify
  - `view` - Can view only (read-only)
  - `hidden` - Cannot see the field at all

### Default Permission Logic
If no explicit field permission exists, defaults apply:
- **Owner/Admin**: Edit access to all fields
- **Editor**: Edit access to all fields
- **Viewer**: View access to all fields

You can override defaults by creating explicit field permissions.

## Step 4: Row Level Security (RLS)

All tables have RLS policies enabled for security:
- Users can only see data from their organization
- Admins can manage users/permissions in their org
- Complete tenant isolation (no cross-org data leaks)

## Step 5: Test the Setup

You can test in the Supabase SQL Editor:

```sql
-- View all users
SELECT * FROM users;

-- View the demo organization
SELECT * FROM organizations;

-- Check RLS policies are enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
  AND tablename IN ('users', 'field_permissions', 'organizations');
```

## Next Steps

After running the SQL schema:

1. ✅ Tables are created with RLS policies
2. ✅ Demo organization and users seeded
3. 🔨 Backend API routes will be created to manage permissions
4. 🔨 Frontend UI will be built for permission management
5. 🔨 Google Sheets data fetching will respect permissions

## Security Architecture

**Minimizes SaaS Provider Liability:**
- ❌ Client land data is **NEVER** stored in Supabase
- ✅ Only metadata stored: users, permissions, audit logs
- ✅ Client data stays in their Google Sheets
- ✅ Row Level Security prevents cross-organization access
- ✅ Activity logs provide audit trail

**Data Flow:**
1. User authenticates with Supabase
2. App fetches their permissions from Supabase
3. App queries Google Sheets API directly
4. App filters/hides fields based on permissions
5. Client data never touches Supabase database

## Troubleshooting

**Error: "relation already exists"**
- Tables already created, safe to ignore
- Or drop tables and re-run: `DROP TABLE IF EXISTS [table_name] CASCADE;`

**Error: RLS prevents access**
- Make sure you're authenticated
- Check user belongs to correct organization
- Verify RLS policies with: `SELECT * FROM pg_policies;`

**Need to reset?**
```sql
DROP TABLE IF EXISTS activity_logs CASCADE;
DROP TABLE IF EXISTS field_permissions CASCADE;
DROP TABLE IF EXISTS google_sheet_connections CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS organizations CASCADE;
```
Then re-run the schema script.

## Support

If you encounter issues:
1. Check Supabase logs (Logs & Analytics)
2. Verify environment variables in Replit Secrets
3. Test RLS policies in SQL Editor
4. Check browser console for API errors
