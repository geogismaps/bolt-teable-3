import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean, integer, unique, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Organizations table - root tenant for multi-tenancy
export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  billingPlan: text("billing_plan").notNull().default("free"), // free, basic, pro, enterprise
  maxUsers: integer("max_users").notNull().default(10),
  maxConnections: integer("max_connections").notNull().default(10),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertOrganizationSchema = createInsertSchema(organizations).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey(), // Supabase auth user ID
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  email: text("email").notNull(),
  fullName: text("full_name"),
  role: text("role").notNull().default("viewer"), // admin, editor, viewer
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Google OAuth Grants table - stores OAuth tokens per user (shared across multiple spreadsheets)
export const googleOAuthGrants = pgTable("google_oauth_grants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  accessToken: text("access_token").notNull(), // Current access token
  refreshToken: text("refresh_token").notNull(), // Refresh token for renewing access
  tokenExpiry: timestamp("token_expiry").notNull(), // When access token expires
  scope: text("scope").notNull(), // OAuth scopes granted
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // One grant per user (enforce single OAuth session)
  userIdIdx: unique("google_oauth_grants_user_id_unique").on(table.userId),
}));

export const insertGoogleOAuthGrantSchema = createInsertSchema(googleOAuthGrants).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertGoogleOAuthGrant = z.infer<typeof insertGoogleOAuthGrantSchema>;
export type GoogleOAuthGrant = typeof googleOAuthGrants.$inferSelect;

// Google Sheets connections table - references OAuth grant
export const googleSheetConnections = pgTable("google_sheet_connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  grantId: varchar("grant_id").references(() => googleOAuthGrants.id, { onDelete: "cascade" }), // Reference to OAuth grant (nullable for backward compatibility)
  spreadsheetId: text("spreadsheet_id").notNull(),
  spreadsheetName: text("spreadsheet_name").notNull(),
  accessToken: text("access_token"), // DEPRECATED: Legacy field for backward compatibility
  refreshToken: text("refresh_token"), // DEPRECATED: Legacy field for backward compatibility
  tokenExpiry: timestamp("token_expiry"), // DEPRECATED: Legacy field for backward compatibility
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Prevent duplicate spreadsheet connections per organization
  uniqueOrgSpreadsheet: unique("unique_org_spreadsheet").on(table.organizationId, table.spreadsheetId),
  // Index for efficient grant lookups
  grantIdIdx: index("google_sheet_connections_grant_id_idx").on(table.grantId),
}));

export const insertGoogleSheetConnectionSchema = createInsertSchema(googleSheetConnections).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertGoogleSheetConnection = z.infer<typeof insertGoogleSheetConnectionSchema>;
export type GoogleSheetConnection = typeof googleSheetConnections.$inferSelect;

// Map layers table - stores configuration for each layer/sheet
export const mapLayers = pgTable("map_layers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  connectionId: varchar("connection_id").notNull().references(() => googleSheetConnections.id, { onDelete: "cascade" }),
  sheetName: text("sheet_name").notNull(),
  layerName: text("layer_name").notNull(),
  geometryField: text("geometry_field"), // which column contains geometry
  color: text("color").default("#3498db"),
  visible: boolean("visible").default(true),
  
  // Symbology configuration
  symbologyType: text("symbology_type").default("single"), // single, graduated, categorized
  symbologyConfig: jsonb("symbology_config"), // stores symbology settings
  
  // Label configuration
  labelsEnabled: boolean("labels_enabled").default(false),
  labelConfig: jsonb("label_config"), // field, size, color, background, etc.
  
  // Popup/iTool configuration
  popupsEnabled: boolean("popups_enabled").default(true),
  popupConfig: jsonb("popup_config"), // template, fields, max width, etc.
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertMapLayerSchema = createInsertSchema(mapLayers).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertMapLayer = z.infer<typeof insertMapLayerSchema>;
export type MapLayer = typeof mapLayers.$inferSelect;

// Permissions table - controls access to sheets and columns
export const permissions = pgTable("permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  connectionId: varchar("connection_id").notNull().references(() => googleSheetConnections.id, { onDelete: "cascade" }),
  sheetName: text("sheet_name").notNull(),
  columnName: text("column_name"), // null means sheet-level permission
  permissionLevel: text("permission_level").notNull(), // view, edit, hidden
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPermissionSchema = createInsertSchema(permissions).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertPermission = z.infer<typeof insertPermissionSchema>;
export type Permission = typeof permissions.$inferSelect;

// Filter configurations for layers
export const layerFilters = pgTable("layer_filters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  layerId: varchar("layer_id").notNull().references(() => mapLayers.id, { onDelete: "cascade" }),
  fieldName: text("field_name").notNull(),
  operator: text("operator").notNull(), // equals, contains, greater_than, less_than, etc.
  value: text("value").notNull(),
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertLayerFilterSchema = createInsertSchema(layerFilters).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertLayerFilter = z.infer<typeof insertLayerFilterSchema>;
export type LayerFilter = typeof layerFilters.$inferSelect;

// Audit logs table - tracks all data edits for compliance and security
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  layerId: varchar("layer_id").notNull().references(() => mapLayers.id, { onDelete: "cascade" }),
  recordId: text("record_id").notNull(), // Row index in Google Sheet
  fieldName: text("field_name").notNull(), // Which field was edited
  oldValue: jsonb("old_value"), // Previous value
  newValue: jsonb("new_value"), // New value
  action: text("action").notNull().default("update"), // update, create, delete
  sourceIp: text("source_ip"), // IP address of the user
  sessionId: text("session_id"), // Session identifier
  userAgent: text("user_agent"), // Browser/client info
  editedAt: timestamp("edited_at").defaultNow().notNull(),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ 
  id: true, 
  editedAt: true 
});
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

// Layer Permissions table - controls per-user, per-layer access
export const layerPermissions = pgTable("layer_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  layerId: varchar("layer_id").notNull().references(() => mapLayers.id, { onDelete: "cascade" }),
  permissionLevel: text("permission_level").notNull(), // hidden, view, edit
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Ensure one permission override per user per layer
  uniqueUserLayer: unique("unique_user_layer").on(table.userId, table.layerId),
  // Indexes for efficient queries
  userIdIdx: index("layer_permissions_user_id_idx").on(table.userId),
  layerIdIdx: index("layer_permissions_layer_id_idx").on(table.layerId),
}));

export const insertLayerPermissionSchema = createInsertSchema(layerPermissions).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertLayerPermission = z.infer<typeof insertLayerPermissionSchema>;
export type LayerPermission = typeof layerPermissions.$inferSelect;

// Public Map Shares table - for shareable map links and embeds
export const publicMapShares = pgTable("public_map_shares", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  shareToken: varchar("share_token", { length: 32 }).notNull().unique(), // unique short token for URL
  layerId: varchar("layer_id").notNull().references(() => mapLayers.id, { onDelete: "cascade" }),
  createdByUserId: varchar("created_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at"), // null = never expires
  embedEnabled: boolean("embed_enabled").default(true),
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Indexes for efficient queries
  layerIdIdx: index("public_map_shares_layer_id_idx").on(table.layerId),
  creatorIdIdx: index("public_map_shares_creator_id_idx").on(table.createdByUserId),
  tokenIdx: index("public_map_shares_token_idx").on(table.shareToken),
}));

export const insertPublicMapShareSchema = createInsertSchema(publicMapShares).omit({ 
  id: true, 
  viewCount: true,
  createdAt: true, 
  updatedAt: true 
});
export type InsertPublicMapShare = z.infer<typeof insertPublicMapShareSchema>;
export type PublicMapShare = typeof publicMapShares.$inferSelect;
