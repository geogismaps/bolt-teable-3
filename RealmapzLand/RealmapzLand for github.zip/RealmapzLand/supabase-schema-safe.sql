LL
);

CREATE INDEX IF NOT EXISTS idx_users_org ON users(organization_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ============================================
-- 3. FEATURE DEFINITIONS
-- ============================================
CREATE TABLE IF NOT EXISTS feature_definitions (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  tier TEXT NOT NULL DEFAULT 'free',
  default_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ============================================
-- 4. ORGANIZATION FEATURES
-- ============================================
CREATE TABLE IF NOT EXISTS organization_features (
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  feature_key TEXT REFERENCES feature_definitions(key) ON DELETE CASCADE,
  enabled BOOLEAN DEFAULT false,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  PRIMARY KEY (organization_id, feature_key)
);

CREATE INDEX IF NOT EXISTS idx_org_features ON organization_features(organization_id, enabled);

-- ============================================
-- 5. GOOGLE_SHEET_CONNECTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS google_sheet_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  spreadsheet_id TEXT NOT NULL,
  spreadsheet_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_connections_org ON google_sheet_connections(organization_id);

-- ============================================
-- 6. FIELD_PERMISSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS field_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES google_sheet_connections(id) ON DELETE CASCADE,
  sheet_name TEXT NOT NULL,
  field_name TEXT NOT NULL,
  permission_level TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, connection_id, sheet_name, field_name)
);

CREATE INDEX IF NOT EXISTS idx_field_permissions_user ON field_permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_connection ON field_permissions(connection_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_lookup ON field_permissions(user_id, connection_id, sheet_name);

-- ============================================
-- 7. ACTIVITY_LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_activity_org ON activity_logs(organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_logs(user_id, created_at DESC);

-- ============================================
-- 8. ROW LEVEL SECURITY - DROP EXISTING POLICIES FIRST
-- ============================================

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_sheet_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE field_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "Users can view their own organization" ON organizations;
DROP POLICY IF EXISTS "Owners can update their organization" ON organizations;
DROP POLICY IF EXISTS "Service role can insert organizations" ON organizations;

DROP POLICY IF EXISTS "Users can view users in their organization" ON users;
DROP POLICY IF EXISTS "Admins can manage users in their organization" ON users;
DROP POLICY IF EXISTS "Service role can insert users" ON users;

DROP POLICY IF EXISTS "Anyone can view feature definitions" ON feature_definitions;

DROP POLICY IF EXISTS "Users can view their organization features" ON organization_features;
DROP POLICY IF EXISTS "Owners can manage organization features" ON organization_features;
DROP POLICY IF EXISTS "Service role can insert organization features" ON organization_features;

DROP POLICY IF EXISTS "Users can view connections in their organization" ON google_sheet_connections;
DROP POLICY IF EXISTS "Admins can manage connections in their organization" ON google_sheet_connections;

DROP POLICY IF EXISTS "Users can view permissions in their organization" ON field_permissions;
DROP POLICY IF EXISTS "Admins can manage permissions in their organization" ON field_permissions;

DROP POLICY IF EXISTS "Users can view activity logs in their organization" ON activity_logs;
DROP POLICY IF EXISTS "Authenticated users can create activity logs" ON activity_logs;

-- Recreate policies
CREATE POLICY "Users can view their own organization"
  ON organizations FOR SELECT
  USING (id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Owners can update their organization"
  ON organizations FOR UPDATE
  USING (id IN (SELECT organization_id FROM users WHERE id = auth.uid() AND role = 'owner'));

CREATE POLICY "Service role can insert organizations"
  ON organizations FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Users can view users in their organization"
  ON users FOR SELECT
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Admins can manage users in their organization"
  ON users FOR ALL
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid() AND role IN ('admin', 'owner')));

CREATE POLICY "Service role can insert users"
  ON users FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Anyone can view feature definitions"
  ON feature_definitions FOR SELECT
  USING (true);

CREATE POLICY "Users can view their organization features"
  ON organization_features FOR SELECT
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Owners can manage organization features"
  ON organization_features FOR ALL
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid() AND role = 'owner'));

CREATE POLICY "Service role can insert organization features"
  ON organization_features FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Users can view connections in their organization"
  ON google_sheet_connections FOR SELECT
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Admins can manage connections in their organization"
  ON google_sheet_connections FOR ALL
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid() AND role IN ('admin', 'owner')));

CREATE POLICY "Users can view permissions in their organization"
  ON field_permissions FOR SELECT
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Admins can manage permissions in their organization"
  ON field_permissions FOR ALL
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid() AND role IN ('admin', 'owner')));

CREATE POLICY "Users can view activity logs in their organization"
  ON activity_logs FOR SELECT
  USING (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

CREATE POLICY "Authenticated users can create activity logs"
  ON activity_logs FOR INSERT
  WITH CHECK (organization_id IN (SELECT organization_id FROM users WHERE id = auth.uid()));

-- ============================================
-- 9. SEED FEATURE DEFINITIONS
-- ============================================

INSERT INTO feature_definitions (key, name, description, tier, default_enabled) VALUES
  ('attribute_editing', 'Attribute Editing', 'Edit data directly in Google Sheets from the app', 'basic', false),
  ('image_viewer', 'Image Viewer', 'View images embedded in your data', 'free', true),
  ('pdf_viewer', 'PDF Viewer', 'View PDF documents embedded in your data', 'basic', false),
  ('panorama_viewer', '360° Panorama Viewer', 'View 360° panoramic images with interactive controls', 'pro', false),
  ('drone_imagery', 'Drone Imagery Support', 'Support for high-resolution drone imagery and aerial photos', 'pro', false),
  ('field_permissions', 'Field-Level Permissions', 'Granular control over which users can view/edit specific fields', 'basic', false),
  ('advanced_filtering', 'Advanced Filtering', 'Complex filter rules with AND/OR logic', 'pro', false),
  ('export_data', 'Data Export', 'Export your data as GeoJSON, CSV, or Shapefile', 'basic', false),
  ('api_access', 'API Access', 'REST API access to your data programmatically', 'enterprise', false),
  ('custom_styling', 'Custom Map Styling', 'Advanced symbology and custom map layer styling', 'pro', false),
  ('user_management', 'User Management', 'Invite and manage multiple users in your organization', 'basic', false)
ON CONFLICT (key) DO NOTHING;

-- ============================================
-- COMPLETE!
-- ============================================

SELECT 
  'Schema update complete!' as message,
  (SELECT COUNT(*) FROM feature_definitions) as features_count,
  (SELECT COUNT(*) FROM organizations) as organizations_count;
