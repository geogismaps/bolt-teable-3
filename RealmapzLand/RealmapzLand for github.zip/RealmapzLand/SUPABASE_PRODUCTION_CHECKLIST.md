# Supabase Permissions System - Production Readiness Checklist

## ✅ What's Been Built

Your realmapz application now has a comprehensive field-level permissions system powered by Supabase:

### Backend Infrastructure
- ✅ Supabase client configured with service key and anon key
- ✅ Complete SQL schema with RLS policies for multi-tenant isolation
- ✅ Permission service that filters Google Sheets data by user permissions
- ✅ Activity logging for audit trail of all permission changes
- ✅ API routes for user management, permission management, and data access
- ✅ Fail-closed security: Returns 503 error when permission checks fail

### Frontend UI
- ✅ User management component for adding/editing users with roles
- ✅ Field-level permissions matrix for setting view/edit/hidden access
- ✅ Permissions page accessible via navigation
- ✅ Integration with existing map layers and Google Sheets

### Architecture
- ✅ Minimal metadata approach: Supabase stores ONLY auth/permissions/configs
- ✅ Client data remains in Google Sheets (minimizes SaaS liability)
- ✅ Row Level Security (RLS) policies for multi-tenant data isolation
- ✅ Role-based access control (Owner/Admin/Editor/Viewer)

---

## ⚠️ CRITICAL: Production Security Requirements

**The current authentication is DEVELOPMENT-ONLY and NOT production-safe.**

### Current State
The `requireAuth` middleware in `server/supabaseRoutes.ts` automatically provisions a `dev_user` with admin privileges for every request. This means:
- ❌ Any anonymous user can access Supabase admin APIs
- ❌ Anyone can create/delete users and permissions
- ❌ Service-key APIs are exposed without real authentication

### What You MUST Fix Before Production

#### 1. Replace Development Authentication with Real Auth

**Current code (DO NOT USE IN PRODUCTION):**
```typescript
// server/supabaseRoutes.ts - lines 46-68
async function requireAuth(req: any, res: any, next: any) {
  // This auto-provisions dev_user for everyone - NOT SECURE!
  const user = await storage.getUserByUsername('dev_user');
  req.userId = user.id;
  req.userRole = user.role;
  next();
}
```

**Replace with one of these production-ready options:**

##### Option A: Supabase Auth (Recommended)
```typescript
import { createClient } from '@supabase/supabase-js';

async function requireAuth(req: any, res: any, next: any) {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No authorization token' });
  }

  try {
    // Verify JWT token with Supabase
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Look up user in your database
    const dbUser = await storage.getUserBySupabaseId(user.id);
    if (!dbUser) {
      return res.status(403).json({ error: 'User not found in system' });
    }

    req.userId = dbUser.id;
    req.userRole = dbUser.role;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Authentication failed' });
  }
}
```

##### Option B: Session-Based Auth
```typescript
import session from 'express-session';

// Configure sessions
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: true, httpOnly: true, sameSite: 'strict' }
}));

async function requireAuth(req: any, res: any, next: any) {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const user = await storage.getUserById(req.session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User not found' });
  }

  req.userId = user.id;
  req.userRole = user.role;
  next();
}
```

#### 2. Add Login/Logout Endpoints
Create proper authentication endpoints:
- `POST /api/auth/login` - Authenticate users
- `POST /api/auth/logout` - Clear session/invalidate token
- `GET /api/auth/me` - Get current user info

#### 3. Update Frontend to Handle Authentication
- Add login page/modal
- Store auth token securely (HttpOnly cookies or secure localStorage)
- Add authorization header to all API requests
- Handle 401 errors by redirecting to login

#### 4. Database Migration
Run the SQL schema in your Supabase project:
```bash
# Copy the contents of supabase-schema.sql
# Go to Supabase Dashboard > SQL Editor
# Paste and execute the schema
```

#### 5. Environment Variables
Ensure these are set in production:
```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-role-key
SESSION_SECRET=generate-a-strong-secret
```

#### 6. Security Hardening
- [ ] Enable HTTPS in production (required for secure cookies)
- [ ] Set proper CORS policies
- [ ] Rate limit authentication endpoints
- [ ] Add request validation and sanitization
- [ ] Enable audit logging for sensitive operations
- [ ] Review and test RLS policies in Supabase dashboard

---

## 🧪 Testing the Permissions System

### Manual Testing Steps

1. **Set up Supabase Database**
   - Go to Supabase Dashboard → SQL Editor
   - Run `supabase-schema.sql`
   - Verify tables are created: organizations, users, field_permissions, activity_logs

2. **Create Test Organization**
   ```bash
   curl -X POST http://localhost:5000/api/supabase/organizations \
     -H "Content-Type: application/json" \
     -d '{"name": "Test Org"}'
   ```

3. **Create Test Users**
   - Navigate to `/permissions` in your app
   - Use the User Management UI to create users with different roles
   - Try Owner, Admin, Editor, Viewer roles

4. **Set Field Permissions**
   - Select a user in the Field Permissions matrix
   - Choose a connection and sheet
   - Set different permission levels (view/edit/hidden) for different fields
   - Save changes

5. **Verify Permission Enforcement**
   - View GeoJSON data for a layer: `/api/layers/:layerId/geojson`
   - Verify fields marked as "hidden" are not returned
   - Verify editing is blocked for "view-only" fields

### Automated Testing
Add integration tests for:
- Permission filtering logic
- Fail-closed behavior when Supabase is unavailable
- Role-based access control
- Activity logging

---

## 📊 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    User's Browser                            │
│  (realmapz Frontend - React)                                │
└───────────────────┬─────────────────────────────────────────┘
                    │ HTTP/JSON
                    ▼
┌─────────────────────────────────────────────────────────────┐
│              realmapz Backend (Express)                      │
│                                                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Permission Service (server/permissionService.ts)  │    │
│  │  - Check user permissions from Supabase            │    │
│  │  - Filter GeoJSON based on field permissions      │    │
│  │  - FAIL CLOSED: Deny access if checks fail        │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
└──────┬──────────────────────────────────────┬───────────────┘
       │                                      │
       │ OAuth Token                          │ Service Key
       ▼                                      ▼
┌─────────────────┐                 ┌──────────────────────┐
│  Google Sheets  │                 │  Supabase Database   │
│                 │                 │                      │
│  CLIENT DATA    │                 │  METADATA ONLY:      │
│  (Land parcels, │                 │  - Users & Roles     │
│   Ownership,    │                 │  - Permissions       │
│   Documents)    │                 │  - Organizations     │
│                 │                 │  - Activity Logs     │
└─────────────────┘                 └──────────────────────┘
```

---

## 🔐 Security Best Practices

1. **Never expose service keys** - Use anon key on frontend, service key only on backend
2. **Use RLS policies** - Every Supabase table has RLS enabled
3. **Fail closed** - System denies access when permission checks fail
4. **Audit everything** - All permission changes are logged
5. **Minimize data in Supabase** - Only metadata, never client land data
6. **Regular security reviews** - Audit RLS policies and permission logic

---

## 📝 Next Steps

1. ✅ Review this checklist
2. ⚠️ **DO NOT deploy to production** until authentication is replaced
3. 🔧 Implement real authentication (Option A or B above)
4. 🧪 Test thoroughly with multiple users and roles
5. 🗄️ Run SQL schema in Supabase dashboard
6. 🚀 Deploy with environment variables properly configured

---

## 📚 Additional Resources

- [Supabase Auth Documentation](https://supabase.com/docs/guides/auth)
- [Row Level Security Policies](https://supabase.com/docs/guides/auth/row-level-security)
- [Express Session Best Practices](https://www.npmjs.com/package/express-session)
- [JWT Best Practices](https://tools.ietf.org/html/rfc8725)

---

**Remember: The current system has development-only authentication. Replace it before going to production!**
