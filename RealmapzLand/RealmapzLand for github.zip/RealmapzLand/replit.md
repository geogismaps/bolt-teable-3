# realmapz: AI Powered Land & Legal Management

## Overview

realmapz is a web-based GIS application designed for managing land parcels, legal documents, and ownership data. It enables users to visualize spatial data on interactive maps, manage documents via Google Drive, and track ownership timelines and permissions. The platform centralizes land information from Google Sheets and documents from Google Drive into a unified, searchable interface with rich visualization capabilities. It supports two primary user types: Admins (manage connections, layers, documents) and Clients (view-only access).

The project's ambition is to reduce paperwork and automate data-driven legal workflows by providing a centralized and interactive platform for land and legal information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite.
**Routing**: Wouter.
**UI Framework**: Shadcn/UI (New York style variant on Radix UI) with Tailwind CSS for styling, emphasizing information density and professional trust.
**State Management**: TanStack Query for server state; local React state for UI.
**Key UI Patterns**: Three-panel layout with resizable panels, AG Grid for data tables, and Leaflet.js for map visualization (with marker clustering and drawing).

### Backend Architecture

**Runtime**: Node.js with Express.js.
**Language**: TypeScript with ES modules.
**API Pattern**: RESTful endpoints.
**Database**: Supabase PostgreSQL (single source of truth for all application state).
**Database ORM**: Drizzle ORM with postgres-js driver (`prepare: false` for Supabase transaction pooler compatibility).
**Authentication Flow**: OAuth 2.0 with Google for Sheets/Drive API access; tokens stored securely in Supabase. Multi-tenant SaaS authentication via Supabase Auth with Row-Level Security (RLS) for data isolation and organization scoping.
**Data Flow**: Customer data resides in Google Sheets/Drive; the application fetches and displays it. Live updates via polling. GeoJSON/WKT geometry parsing for map visualization.

### Database Schema

**Core Tables**: `users`, `googleSheetConnections`, `mapLayers` (stores symbology, geometry mapping, visibility), `permissions`, `layerFilters`, `organizations`, `feature_definitions`, `organization_features`, `field_permissions`, `audit_logs` (per-field edit history with metadata).
**Design Decisions**: UUID primary keys, cascade deletion, JSONB fields for flexible metadata/symbology, timestamps for audit trails.

### Feature Specifications

- **Super Admin & Organization Dashboards**: Centralized management for organizations with billing plans, user counts, feature flag toggling, and self-service portals for organization members.
- **Supabase Auth & User Provisioning**: Multi-tenant SaaS authentication, secure user provisioning, feature flag system (free/basic/pro/enterprise tiers), and RLS.
- **Supabase Field-Level Permissions**: Comprehensive field-level permissions architecture using Supabase for metadata, with role-based access control (Admin, Editor, Viewer) and granular view/edit/hidden permissions per user per field. Full UI integration across all components: AttributeTable (column hiding, editability control, read-only styling), map filters (hidden field exclusion), layer properties (label, symbology, popup configurations with automatic hidden field cleanup).
- **Comprehensive Audit Logging**: Per-field granular audit trail capturing user, timestamp, field name, old/new values, IP address, session ID, and user agent. Admin-only audit log page (/audit-log) with filters (date range, user, layer, field name) and pagination. Integrated into PATCH endpoint with diff-based logging (only changed fields), post-success timing, and non-blocking error handling. Uses parameterized queries to prevent SQL injection.
- **Drone Imagery & 360° Panorama Viewer**: Automatic detection of image and panorama URLs in Google Sheets, with thumbnail display, full-screen image viewer, and integrated Pannellum for 360° panoramas.
- **Smart Polling & Manual Refresh**: Backend always returns fresh data; frontend uses conditional polling (30s interval when active) and manual refresh button.
- **Demo Layer Auto-Loading**: Automatic public Google Sheets data loading for unauthenticated first-time visitors with full layer functionality and persistent dismissal.
- **Link Viewer Feature**: Automatic detection and display of URLs in Google Sheets as clickable "View Link" buttons, with modal preview and Google Drive integration.
- **Data Editing System (Two-Way Sync)**: Bidirectional data editing between the app and Google Sheets, with admin-only access, validation, and cache invalidation.
- **Sidebar Filter System**: Prominent sidebar UI for filtering map layers based on field values, supporting various operators, with real-time client-side filtering (AND logic).
- **Natural Language Query System**: AI-powered map filtering using Puter.js (free, browser-based AI service). Users can query the map in plain English (e.g., "show vacant parcels", "area greater than 5000"). The system analyzes available fields with sample values, generates structured FilterRule[] objects via GPT-5-nano model, and applies them to the map. Features include loading states, error handling, visual distinction (Sparkles icon for AI filters), and smart integration with manual filters (AND logic). AI filters can be cleared independently or together with manual filters.
- **UI Simplification**: Streamlined sidebar design with persistent "Connect Google Sheets" button and clearer layer management.
- **Public Map Sharing System**: Production SaaS feature for sharing maps publicly with comprehensive management capabilities. Admins and editors can generate secure, shareable links for individual layers with customizable settings. Features include:
  - **Share Creation**: ShareMapModal for generating public links with configurable expiration dates and embed permissions. Supports link copying and embed code generation.
  - **Public Viewer**: Dedicated /share/:token route with expiry validation, read-only map view, and embed mode support (hides UI chrome for iframe embedding).
  - **Share Management Dashboard**: Settings page integration (SharesManagement component) providing organization-wide share oversight with list view, analytics (view counts), individual/bulk revocation, and per-share editing (EditShareModal for updating expiration and embed settings).
  - **Security**: Cryptographically secure token generation (crypto.randomBytes), organization scoping via Supabase RLS, permission-based creation (requires edit access), and automatic expiration enforcement.
  - **Backend Architecture**: RESTful endpoints (POST /api/share/create, GET /api/share/:token, PATCH/DELETE /api/share/:id, GET /api/share/organization) with Drizzle ORM storage layer using inArray for efficient UUID array operations.

## External Dependencies

**Google Cloud Platform**:
- **Google Sheets API v4**: Primary data source for spatial and tabular data.
- **Google Drive API**: Document storage, retrieval, and preview.

**Database**:
- **Supabase PostgreSQL**: Unified database for all application data (user auth, map layers, share links, audit logs, permissions), authentication, authorization (RLS, field-level permissions), and feature flag management. Uses Supabase's transaction pooler (port 6543) with postgres-js driver for optimal serverless performance.

**Mapping Libraries**:
- **Leaflet.js**: Core mapping engine.
- **wellknown**: WKT/WKB geometry parsing.

**Data Visualization**:
- **AG Grid Community**: Data tables.
- **Pannellum**: 360° panorama viewer.

**Environment Variables Required**:
- `DATABASE_URL`
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI` (optional)