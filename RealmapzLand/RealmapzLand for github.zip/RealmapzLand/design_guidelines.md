# realmapz: AI Powered Land & Legal Management - Design Guidelines

## Design Approach

**Selected Approach**: Design System Foundation with GIS Application Patterns

**Rationale**: This is a utility-focused, information-dense professional tool combining GIS mapping, legal document management, and data visualization. The design prioritizes efficiency, clarity, and trustworthiness over visual flourish.

**Key References**: 
- ArcGIS Online for map interface patterns
- Linear for clean, data-dense productivity UI
- Notion for document organization and hierarchy
- Material Design for component consistency

## Core Design Principles

1. **Information Hierarchy**: Map and data take precedence; controls support but don't compete
2. **Spatial Efficiency**: Maximize viewport for map/content while maintaining accessible controls
3. **Professional Trust**: Clean, structured layouts convey reliability for legal/land data
4. **Workflow-Centric**: Design for task completion, not exploration

---

## Layout System

### Spacing Framework
**Tailwind Units**: Use 2, 4, 6, 8, 12, 16 as primary spacing values
- Tight spacing (p-2, gap-2): Within component groups, form fields
- Standard spacing (p-4, gap-4): Between related elements, card padding
- Medium spacing (p-6, m-6): Section separation, modal padding
- Large spacing (p-8, py-12): Page margins, major section breaks

### Application Structure

**Three-Panel Layout** (desktop):
```
┌─────────────────────────────────────────┐
│ Header: 64px height (h-16)              │
├──────────┬───────────────────┬──────────┤
│ Sidebar  │   Map/Content     │ Optional │
│ 320px    │   Flexible        │ Panel    │
│ w-80     │   flex-1          │ w-80     │
│          │                   │          │
├──────────┴───────────────────┴──────────┤
│ Docked Table (when active): 30-60% vh   │
└─────────────────────────────────────────┘
```

**Sidebar** (left):
- Fixed width: w-80 (320px)
- Collapsible sections with 8px vertical rhythm
- Sticky header within sidebar
- Smooth scroll for overflow content

**Main Content Area**:
- Flex-1 to fill remaining space
- Minimum height: calc(100vh - 64px) for header
- For map view: Full height with absolute positioning
- For document/table views: Standard padding (p-6)

**Responsive Breakpoints**:
- Mobile (<768px): Stack vertically, sidebar becomes drawer
- Tablet (768-1024px): Reduce sidebar to w-64, collapse optional panel
- Desktop (>1024px): Full three-panel layout

---

## Typography Hierarchy

**Font Stack**: 
- Primary: Inter or System UI stack for interface elements
- Monospace: JetBrains Mono for coordinates, IDs, technical data

**Type Scale**:
- Page Titles: text-2xl font-bold (24px)
- Section Headers: text-lg font-semibold (18px)
- Subsection Headers: text-base font-semibold (16px)
- Body Text: text-sm (14px)
- Labels/Captions: text-xs (12px)
- Technical Data: text-xs font-mono (12px monospace)

**Line Heights**:
- Headers: leading-tight (1.25)
- Body: leading-normal (1.5)
- Dense data tables: leading-snug (1.375)

---

## Component Library

### Navigation & Headers

**App Header**:
- Height: h-16 (64px)
- Logo/branding: Left-aligned, max-w-40
- User menu: Right-aligned with role indicator badge
- Horizontal padding: px-6
- Bottom border for definition

**Sidebar Navigation**:
- Collapsible sections with chevron indicators
- Section headers: py-3 px-4, text-sm font-semibold
- Layer items: p-3, rounded-md, with hover state
- Active layer: Distinct border treatment (border-l-4)
- Icon + text layout with gap-3

### Map Components

**Layer Control Panel**:
- Each layer item: Compact card (p-3, rounded-lg)
- Layer name: text-sm font-medium, truncate for long names
- Control buttons: Grid layout (grid-cols-4, gap-1), text-xs
- Visibility toggle: Prominent switch/checkbox (top-right)

**Map Controls** (absolute positioned):
- Top-right corner: Zoom controls, layer switcher
- Bottom-right: Scale, coordinates display
- Spacing from edges: 4 units (right-4, top-4)
- Stack vertically with gap-2

**Attribute Table** (docked):
- When visible: 30% viewport height (expandable to 60%)
- Header: h-10, sticky positioning
- Resize handle: h-1 with drag cursor
- Table cells: px-3 py-2, border-b for row separation

### Data Display

**AG-Grid Tables**:
- Row height: Compact (32px) for data density
- Header: Sticky, font-semibold, text-xs uppercase tracking-wide
- Cell padding: px-3 py-2
- Alternating row treatment for readability
- Editable cells: Subtle indicator (border-l-2 on focus)

**Property Panels**:
- Modal/drawer based: max-w-2xl for readability
- Tab navigation: Horizontal with underline indicator (border-b-2)
- Tab content padding: p-6
- Form groups: space-y-4
- Label-input pairs: grid grid-cols-3 gap-4 (label: col-span-1, input: col-span-2)

### Document Viewer

**PDF Viewer Container**:
- Full-height panel or modal
- Toolbar: h-12, sticky top
- Zoom controls: Right side of toolbar
- Page navigation: Center of toolbar
- Document canvas: Centered with max-w-4xl

**Document List**:
- Card-based layout: p-4, rounded-lg
- Document preview: Thumbnail (w-16 h-20) + metadata
- Grid on larger screens: grid-cols-2 lg:grid-cols-3, gap-4

### Timeline & Ownership Flow

**Timeline Component**:
- Vertical timeline: Left-aligned connector line (w-0.5)
- Events: Relative positioning with left offset (ml-6)
- Event cards: p-4, rounded-lg, with date badge
- Date badges: Absolute positioned (-left-20), text-xs

**Tree View**:
- Indentation: ml-6 per level
- Connectors: Visual hierarchy with pseudo-elements
- Node items: py-2, rounded-md on hover
- Expand/collapse: Chevron icons, rotate on state change

### Forms & Inputs

**Form Layout**:
- Vertical stacking: space-y-4 for related fields
- Multi-column on desktop: grid grid-cols-2 gap-4
- Required field indicators: Adjacent to label
- Help text: text-xs, mt-1

**Input Fields**:
- Height: h-10 for standard inputs
- Padding: px-3
- Border radius: rounded-md
- Focus state: Ring treatment (ring-2)

**Buttons**:
- Primary actions: px-4 py-2, rounded-md, font-medium
- Secondary actions: px-3 py-1.5, text-sm
- Icon buttons: Square (h-9 w-9), centered content
- Button groups: Flex with gap-2, or segmented with rounded corners on ends only

### Modals & Overlays

**Standard Modal**:
- Backdrop: Fixed overlay with opacity transition
- Content: Centered, max-w-2xl (adjustable per use)
- Padding: p-6
- Header: pb-4, border-b
- Footer: pt-4, border-t, flex justify-end gap-2

**Sidepanel** (for filters, properties):
- Fixed right/left, w-96
- Full height: h-screen
- Slide-in transition
- Close button: Absolute top-right

### Permission Indicators

**Role Badges**:
- Inline display: px-2 py-0.5, rounded-full, text-xs font-medium
- Position: Adjacent to username/sheet name

**Column/Field Permissions**:
- Visual indicators: Small dots (w-2 h-2, rounded-full) or border accents
- Tooltip on hover explaining permission level
- Table column headers: Icon suffix for permission type

---

## Responsive Patterns

**Mobile (<768px)**:
- Sidebar becomes full-screen drawer (slide-in from left)
- Map controls: Simplified, bottom sheet for layers
- Tables: Horizontal scroll with sticky first column
- Forms: Single column (grid-cols-1)

**Tablet (768-1024px)**:
- Sidebar: Collapsible to icon-only mode (w-16)
- Optional panel: Hidden, accessible via drawer
- Reduced padding: p-4 instead of p-6

**Desktop (>1024px)**:
- Full three-panel layout
- Hover interactions for layers/controls
- Keyboard shortcuts enabled
- Multi-column grids where appropriate

---

## Interaction Patterns

**Loading States**:
- Skeleton screens for tables/lists
- Spinner overlay for map tiles
- Progress bars for file uploads

**Empty States**:
- Centered content: max-w-sm mx-auto
- Icon (w-16 h-16) + heading + description + action button
- Subtle treatment, not alarming

**Error States**:
- Inline validation: Below input fields
- Toast notifications: Fixed top-right, auto-dismiss
- Banner alerts: Full-width at top of content area

**Drag & Drop**:
- Dashed border treatment on drop zones
- Visual feedback on dragover
- Clear affordance for draggable items (cursor grab)

---

## Accessibility

- **Focus indicators**: Clear ring treatment on all interactive elements
- **Keyboard navigation**: Tab order follows visual hierarchy
- **ARIA labels**: Proper labeling for map controls, icons, dynamic content
- **Color independence**: Permission/status conveyed through icons + text, not color alone
- **Contrast**: Maintain WCAG AA standards for text/background

---

## Performance Considerations

- **Map rendering**: Lazy load markers, cluster for 100+ features
- **Table virtualization**: Render visible rows only for large datasets
- **Image optimization**: Thumbnail generation for document previews
- **Debounced search**: 300ms delay on filter inputs
- **Optimistic updates**: Immediate UI feedback, background sync with Google APIs

This design system prioritizes data clarity, efficient workflows, and professional presentation suitable for legal and land management contexts.

---

## Standard Layout Components

To ensure consistency across all pages, use these reusable layout primitives:

### PageShell
Provides standard page container with consistent padding and responsive max-width.

**Props**:
- `maxWidth`: "sm" | "md" | "lg" | "xl" | "2xl" | "4xl" | "6xl" | "7xl" (default) | "full"
- `className`: Optional additional classes

**Usage**:
```tsx
// Dashboard pages
<PageShell maxWidth="7xl">
  <PageHeader title="Dashboard" />
  {/* content */}
</PageShell>

// Form-focused pages  
<PageShell maxWidth="4xl">
  <PageHeader title="Settings" />
  {/* content */}
</PageShell>
```

### PageHeader
Consistent page header with icon, title, description, and optional actions.

**Design Spec**:
- Title: `text-3xl font-bold tracking-tight`
- Description: `text-muted-foreground`
- Icon container: `h-10 w-10 rounded-md bg-primary/10`
- Icon: `h-6 w-6 text-primary`

**Props**:
- `title`: Page title (required)
- `description`: Optional subtitle
- `icon`: Lucide icon component
- `actions`: Optional action buttons (right-aligned)

**Usage**:
```tsx
<PageHeader 
  icon={Shield} 
  title="Permissions & Access Control"
  description="Manage users, roles, and field-level permissions"
  actions={<Button><Plus className="h-4 w-4 mr-2" />Add User</Button>}
/>
```

### PageSection
Reusable section container with optional card wrapping for organizing page content.

**Design Spec**:
- Section title: `text-lg font-semibold`
- Description: `text-sm text-muted-foreground`
- Default spacing: `space-y-4`

**Props**:
- `title`: Section heading
- `description`: Optional section description
- `icon`: Optional Lucide icon
- `asCard`: Wrap in Card component (default: false)
- `children`: Section content

**Usage**:
```tsx
// As a card
<PageSection 
  title="User Management" 
  description="Add and manage users"
  icon={Users}
  asCard
>
  <UserList />
</PageSection>

// As a plain section
<PageSection title="Statistics">
  <StatsGrid />
</PageSection>
```

### Standard Page Structure

**Recommended Pattern**:
```tsx
export default function MyPage() {
  return (
    <PageShell maxWidth="7xl">
      <PageHeader 
        icon={MyIcon}
        title="Page Title"
        description="Page description"
        actions={<Button>Action</Button>}
      />
      
      <PageSection title="Section 1" asCard>
        {/* content */}
      </PageSection>
      
      <PageSection title="Section 2" asCard>
        {/* content */}
      </PageSection>
    </PageShell>
  );
}
```

**Benefits**:
- Enforces consistent spacing (p-6, space-y-6)
- Guarantees typography hierarchy
- Reduces markup duplication
- Makes responsive behavior predictable
- Simplifies future design updates