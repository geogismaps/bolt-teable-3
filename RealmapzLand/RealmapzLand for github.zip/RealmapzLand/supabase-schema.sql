-- realmapz Field-Level Permissions System
-- Run this SQL in your Supabase SQL Editor (https://app.supabase.com → SQL Editor)
-- This creates the tables and Row Level Security policies for multi-tenant data isolation

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- 1. ORGANIZATIONS TABLE
-- ============================================
-- Organizations for multi-tenant isolation
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ============================================
-- 2. USERS TABLE
-- ============================================
-- Users belong to organizations and have roles
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT,
  role TEXT NOT NULL DEFAULT 'viewer', -- owner, admin, editor, viewer
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_org ON users(organization_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ============================================
-- 3. GOOGLE_SHEET_CONNECTIONS TABLE
-- ============================================
-- Stores metadata about Google Sheets connections (no actual data)
CREATE TABLE IF NOT EXISTS google_sheet_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  spreadsheet_id TEXT NOT NULL,
  spreadsheet_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_connections_org ON google_sheet_connections(organization_id);

-- ============================================
-- 4. FIELD_PERMISSIONS TABLE
-- ============================================
-- Field-level permissions: controls what users can see/edit in Google Sheets
CREATE TABLE IF NOT EXISTS field_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES google_sheet_connections(id) ON DELETE CASCADE,
  sheet_name TEXT NOT NULL,
  field_name TEXT NOT NULL,
  permission_level TEXT NOT NULL, -- view, edit, hidden
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, connection_id, sheet_name, field_name)
);

-- Indexes for faster permission checks
CREATE INDEX IF NOT EXISTS idx_field_permissions_user ON field_permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_connection ON field_permissions(connection_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_lookup ON field_permissions(user_id, connection_id, sheet_name);

-- ============================================
-- 5. ACTIVITY_LOGS TABLE
-- ============================================
-- Audit trail for permission changes
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL, -- permission_created, permission_updated, permission_deleted, user_added, etc.
  entity_type TEXT NOT NULL, -- field_permission, user, connection
  entity_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Index for activity queries
CREATE INDEX IF NOT EXISTS idx_activity_org ON activity_logs(organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_logs(user_id, created_at DESC);

-- ============================================
-- 6. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_sheet_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE field_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- Organizations: Users can only see their own organization
CREATE POLICY "Users can view their own organization"
  ON organizations
  FOR SELECT
  USING (
    id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Users: Users can view users in their organization
CREATE POLICY "Users can view users in their organization"
  ON users
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Users: Admins and owners can insert/update/delete users in their org
CREATE POLICY "Admins can manage users in their organization"
  ON users
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Connections: Users can view connections in their organization
CREATE POLICY "Users can view connections in their organization"
  ON google_sheet_connections
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Connections: Admins can manage connections
CREATE POLICY "Admins can manage connections in their organization"
  ON google_sheet_connections
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Field Permissions: Users can view permissions in their organization
CREATE POLICY "Users can view permissions in their organization"
  ON field_permissions
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Field Permissions: Admins can manage permissions
CREATE POLICY "Admins can manage permissions in their organization"
  ON field_permissions
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Activity Logs: Users can view logs in their organization
CREATE POLICY "Users can view activity logs in their organization"
  ON activity_logs
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Activity Logs: System can insert logs (all authenticated users)
CREATE POLICY "Authenticated users can create activity logs"
  ON activity_logs
  FOR INSERT
  WITH CHECK (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- ============================================
-- 7. HELPER FUNCTIONS
-- ============================================

-- Function to get user's effective permissions for a field
-- Returns: 'edit', 'view', or 'hidden'
-- Logic: Specific field permission > Default role-based permission
CREATE OR REPLACE FUNCTION get_user_field_permission(
  p_user_id UUID,
  p_connection_id UUID,
  p_sheet_name TEXT,
  p_field_name TEXT
)
RETURNS TEXT AS $$
DECLARE
  v_permission TEXT;
  v_user_role TEXT;
BEGIN
  -- Check if there's an explicit field permission
  SELECT permission_level INTO v_permission
  FROM field_permissions
  WHERE user_id = p_user_id
    AND connection_id = p_connection_id
    AND sheet_name = p_sheet_name
    AND field_name = p_field_name;
  
  IF v_permission IS NOT NULL THEN
    RETURN v_permission;
  END IF;
  
  -- Fallback to role-based default permissions
  SELECT role INTO v_user_role
  FROM users
  WHERE id = p_user_id;
  
  -- Default permissions based on role
  RETURN CASE
    WHEN v_user_role IN ('owner', 'admin') THEN 'edit'
    WHEN v_user_role = 'editor' THEN 'edit'
    WHEN v_user_role = 'viewer' THEN 'view'
    ELSE 'hidden'
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to log activity
CREATE OR REPLACE FUNCTION log_activity(
  p_organization_id UUID,
  p_user_id UUID,
  p_action_type TEXT,
  p_entity_type TEXT,
  p_entity_id UUID DEFAULT NULL,
  p_metadata JSONB DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO activity_logs (
    organization_id,
    user_id,
    action_type,
    entity_type,
    entity_id,
    metadata
  ) VALUES (
    p_organization_id,
    p_user_id,
    p_action_type,
    p_entity_type,
    p_entity_id,
    p_metadata
  ) RETURNING id INTO v_log_id;
  
  RETURN v_log_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 8. SEED DATA (OPTIONAL - FOR TESTING)
-- ============================================

-- Insert a demo organization
INSERT INTO organizations (id, name) 
VALUES ('00000000-0000-0000-0000-000000000001', 'Demo Organization')
ON CONFLICT (id) DO NOTHING;

-- Insert a demo admin user
INSERT INTO users (id, organization_id, email, full_name, role)
VALUES (
  '00000000-0000-0000-0000-000000000002',
  '00000000-0000-0000-0000-000000000001',
  'admin@demo.com',
  'Demo Admin',
  'admin'
) ON CONFLICT (email) DO NOTHING;

-- Insert a demo viewer user
INSERT INTO users (id, organization_id, email, full_name, role)
VALUES (
  '00000000-0000-0000-0000-000000000003',
  '00000000-0000-0000-0000-000000000001',
  'viewer@demo.com',
  'Demo Viewer',
  'viewer'
) ON CONFLICT (email) DO NOTHING;

-- ============================================
-- SETUP COMPLETE!
-- ============================================

SELECT 
  'Supabase schema setup complete!' as message,
  (SELECT COUNT(*) FROM organizations) as organizations_count,
  (SELECT COUNT(*) FROM users) as users_count;
