import { Router } from 'express';
import { requireAuth, requireOwner } from './authMiddleware';
import { featureFlagService } from './featureFlagService';

const router = Router();

/**
 * GET /api/feature-flags
 * Get all features for current user's organization
 */
router.get('/feature-flags', requireAuth, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;
    
    const features = await featureFlagService.getAllFeatures(organizationId);
    
    res.json(features);
  } catch (error) {
    console.error('Error fetching feature flags:', error);
    res.status(500).json({ error: 'Failed to fetch feature flags' });
  }
});

/**
 * GET /api/feature-flags/definitions
 * Get all feature definitions (catalog)
 */
router.get('/feature-flags/definitions', requireAuth, async (req, res) => {
  try {
    const definitions = await featureFlagService.getFeatureDefinitions();
    res.json(definitions);
  } catch (error) {
    console.error('Error fetching feature definitions:', error);
    res.status(500).json({ error: 'Failed to fetch feature definitions' });
  }
});

/**
 * PUT /api/feature-flags/:featureKey
 * Toggle feature flag (owners only)
 */
router.put('/feature-flags/:featureKey', requireAuth, requireOwner, async (req, res) => {
  try {
    const { featureKey } = req.params;
    const { enabled, metadata } = req.body;
    const organizationId = req.user!.organizationId;
    
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ error: 'enabled must be a boolean' });
    }
    
    const success = await featureFlagService.setFeature(
      organizationId,
      featureKey,
      enabled,
      metadata
    );
    
    if (!success) {
      return res.status(500).json({ error: 'Failed to update feature flag' });
    }
    
    res.json({ success: true, featureKey, enabled });
  } catch (error) {
    console.error('Error updating feature flag:', error);
    res.status(500).json({ error: 'Failed to update feature flag' });
  }
});

/**
 * POST /api/feature-flags/check
 * Check if specific features are enabled (bulk check)
 */
router.post('/feature-flags/check', requireAuth, async (req, res) => {
  try {
    const { features } = req.body;
    const organizationId = req.user!.organizationId;
    
    if (!Array.isArray(features)) {
      return res.status(400).json({ error: 'features must be an array' });
    }
    
    const results: Record<string, boolean> = {};
    
    for (const featureKey of features) {
      results[featureKey] = await featureFlagService.isEnabled(organizationId, featureKey);
    }
    
    res.json(results);
  } catch (error) {
    console.error('Error checking feature flags:', error);
    res.status(500).json({ error: 'Failed to check feature flags' });
  }
});

export default router;
