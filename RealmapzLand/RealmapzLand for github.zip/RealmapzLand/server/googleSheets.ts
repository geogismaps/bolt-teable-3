import { google } from 'googleapis';
// @ts-ignore - wellknown doesn't have type definitions
import wellknown from 'wellknown';

const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets', // Full read/write access to sheets
  'https://www.googleapis.com/auth/drive.readonly' // Read-only access to Drive for file listing
];

export interface SheetData {
  sheetName: string;
  headers: string[];
  rows: Record<string, any>[];
  geometryField?: string;
}

export interface ParsedFeature {
  type: 'Feature';
  geometry: any;
  properties: Record<string, any>;
}

export class GoogleSheetsService {
  private clientId: string;
  private clientSecret: string;
  private oauth2Client: any;

  constructor() {
    // Initialize OAuth2 client with environment variables
    this.clientId = process.env.GOOGLE_CLIENT_ID || '';
    this.clientSecret = process.env.GOOGLE_CLIENT_SECRET || '';

    if (!this.clientId || !this.clientSecret) {
      console.warn('Google OAuth credentials not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables.');
    }

    // Create OAuth2 client WITHOUT redirect URI (will be set dynamically)
    this.oauth2Client = new google.auth.OAuth2(
      this.clientId,
      this.clientSecret,
      undefined
    );
  }


  /**
   * Get the redirect URI based on the current request
   */
  private getRedirectUri(req?: any): string {
    console.log('🔍 getRedirectUri - checking priorities...');
    
    // Priority 1: Use host header from request (HIGHEST PRIORITY)
    if (req && req.get) {
      const protocol = req.get('x-forwarded-proto') || req.protocol || 'https';
      const host = req.get('host');
      console.log(`🔍 Priority 1: req.get('host') = ${host}, protocol = ${protocol}`);
      if (host) {
        const uri = `${protocol}://${host}/api/auth/google/callback`;
        console.log(`✅ Priority 1: Using request host - ${uri}`);
        return uri;
      }
    } else {
      console.log('❌ Priority 1: req or req.get not available');
    }

    // Priority 2: Explicit environment variable override
    if (process.env.GOOGLE_REDIRECT_URI) {
      console.log('✅ Priority 2: Using GOOGLE_REDIRECT_URI');
      return process.env.GOOGLE_REDIRECT_URI;
    }

    // Priority 3: Production deployment
    if (process.env.REPLIT_DEPLOYMENT === '1' && process.env.REPLIT_DOMAINS) {
      const domain = process.env.REPLIT_DOMAINS.split(',')[0].trim();
      const uri = `https://${domain}/api/auth/google/callback`;
      console.log(`✅ Priority 3: Using REPLIT_DOMAINS - ${uri}`);
      return uri;
    }

    // Priority 4: Development environment
    if (process.env.REPLIT_DEV_DOMAIN) {
      const devDomain = process.env.REPLIT_DEV_DOMAIN;
      const uri = devDomain.startsWith('http') 
        ? `${devDomain}/api/auth/google/callback`
        : `https://${devDomain}/api/auth/google/callback`;
      console.log(`✅ Priority 4: Using REPLIT_DEV_DOMAIN - ${uri}`);
      return uri;
    }

    // Fallback: Local development
    console.log('✅ Fallback: Using localhost');
    return 'http://localhost:5000/api/auth/google/callback';
  }

  /**
   * Generate OAuth authorization URL
   */
  getAuthUrl(userId: string, req?: any): string {
    const redirectUri = this.getRedirectUri(req);
    console.log(`OAuth getAuthUrl - redirect URI: ${redirectUri}`);
    
    // Create a new OAuth2Client with the correct redirect URI for this request
    const client = new google.auth.OAuth2(
      this.clientId,
      this.clientSecret,
      redirectUri
    );

    return client.generateAuthUrl({
      access_type: 'offline',
      scope: SCOPES,
      state: userId,
      prompt: 'consent',
    });
  }

  /**
   * Exchange authorization code for tokens
   */
  async getTokensFromCode(code: string, req?: any) {
    const redirectUri = this.getRedirectUri(req);
    console.log(`OAuth getTokensFromCode - redirect URI: ${redirectUri}`);
    
    // Create a new OAuth2Client with the correct redirect URI for this request
    const client = new google.auth.OAuth2(
      this.clientId,
      this.clientSecret,
      redirectUri
    );

    const { tokens } = await client.getToken(code);
    return tokens;
  }

  /**
   * Set credentials for API calls
   */
  setCredentials(accessToken: string, refreshToken?: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken,
    });
  }

  /**
   * Resolve connection credentials via grant lookup (with legacy fallback)
   * @param connection - The connection record
   * @param storage - Storage instance for grant lookup
   * @returns Object with accessToken and refreshToken
   */
  async resolveConnectionCredentials(connection: any, storage: any): Promise<{ accessToken: string; refreshToken: string | null }> {
    // Try grant-based credentials first (new approach)
    if (connection.grantId) {
      const grant = await storage.getOAuthGrant(connection.grantId);
      if (grant) {
        return {
          accessToken: grant.accessToken,
          refreshToken: grant.refreshToken,
        };
      }
    }
    
    // Fall back to legacy embedded tokens (backward compatibility)
    if (connection.accessToken) {
      return {
        accessToken: connection.accessToken,
        refreshToken: connection.refreshToken || null,
      };
    }
    
    throw new Error('No credentials available for this connection');
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(refreshToken: string) {
    this.oauth2Client.setCredentials({
      refresh_token: refreshToken,
    });
    const { credentials } = await this.oauth2Client.refreshAccessToken();
    return credentials;
  }

  /**
   * List user's Google Spreadsheets from Drive
   */
  async listSpreadsheets() {
    const drive = google.drive({ version: 'v3', auth: this.oauth2Client });
    const response = await drive.files.list({
      q: "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false",
      pageSize: 50,
      fields: 'files(id, name, modifiedTime, webViewLink, thumbnailLink, iconLink)',
      orderBy: 'modifiedTime desc',
    });
    
    return response.data.files || [];
  }

  /**
   * Internal method: Get spreadsheet metadata (uncached)
   */
  private async getSpreadsheetMetadataInternal(spreadsheetId: string) {
    const sheets = google.sheets({ version: 'v4', auth: this.oauth2Client });
    const response = await sheets.spreadsheets.get({
      spreadsheetId,
      fields: 'properties(title),sheets(properties(title,sheetId,gridProperties))',
    });
    return response.data;
  }

  /**
   * Get spreadsheet metadata (always fresh from Google Sheets)
   * React Query on the frontend handles caching and deduplication
   */
  async getSpreadsheetMetadata(spreadsheetId: string, connectionId?: string) {
    return this.getSpreadsheetMetadataInternal(spreadsheetId);
  }

  /**
   * Internal method: Fetch data from a specific sheet (uncached)
   */
  private async fetchSheetDataInternal(spreadsheetId: string, sheetName: string): Promise<SheetData> {
    const sheets = google.sheets({ version: 'v4', auth: this.oauth2Client });
    
    // Get all data from the sheet
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A:ZZ`, // Get all columns up to ZZ
    });

    const rows = response.data.values || [];
    if (rows.length === 0) {
      return {
        sheetName,
        headers: [],
        rows: [],
      };
    }

    const headers = rows[0] as string[];
    const dataRows = rows.slice(1);

    // Convert to array of objects
    const formattedRows = dataRows.map(row => {
      const obj: Record<string, any> = {};
      headers.forEach((header, index) => {
        obj[header] = row[index] || '';
      });
      return obj;
    });

    // Try to auto-detect geometry field
    const geometryField = this.detectGeometryField(headers);

    return {
      sheetName,
      headers,
      rows: formattedRows,
      geometryField,
    };
  }

  /**
   * Fetch data from a specific sheet (always fresh from Google Sheets)
   * React Query on the frontend handles caching and deduplication
   */
  async fetchSheetData(spreadsheetId: string, sheetName: string, connectionId?: string): Promise<SheetData> {
    return this.fetchSheetDataInternal(spreadsheetId, sheetName);
  }

  /**
   * Convert column index to Excel-style column letter (0 = A, 25 = Z, 26 = AA, etc.)
   */
  private columnIndexToLetter(index: number): string {
    let letter = '';
    while (index >= 0) {
      letter = String.fromCharCode((index % 26) + 65) + letter;
      index = Math.floor(index / 26) - 1;
    }
    return letter;
  }

  /**
   * Update a row in Google Sheets
   * @param spreadsheetId - The Google Sheets spreadsheet ID
   * @param sheetName - The name of the sheet
   * @param rowIndex - The actual sheet row number (1-based, where 1 is the header, data starts at 2)
   * @param updates - Object with field names and new values
   * @param headers - Array of column headers in order
   * @param connectionId - Optional connection ID for cache invalidation
   */
  async updateSheetRow(
    spreadsheetId: string,
    sheetName: string,
    rowIndex: number,
    updates: Record<string, any>,
    headers: string[],
    connectionId?: string
  ): Promise<void> {
    const sheets = google.sheets({ version: 'v4', auth: this.oauth2Client });
    
    // Create array of values matching header order
    const values = headers.map(header => {
      return updates.hasOwnProperty(header) ? updates[header] : '';
    });
    
    // rowIndex is already the actual sheet row number (no adjustment needed)
    const sheetRowNumber = rowIndex;
    
    // Calculate the last column letter (e.g., 26 columns = Z, 27 columns = AA)
    const lastColumnLetter = this.columnIndexToLetter(headers.length - 1);
    
    // Update the entire row
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: `${sheetName}!A${sheetRowNumber}:${lastColumnLetter}${sheetRowNumber}`,
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values: [values]
      }
    });
    
    // No cache to invalidate - React Query handles all caching on the frontend
  }

  /**
   * Auto-detect which column contains geometry data
   */
  private detectGeometryField(headers: string[]): string | undefined {
    const geometryKeywords = [
      'geometry',
      'geom',
      'wkt',
      'geojson',
      'shape',
      'location',
      'coordinates',
      'polygon',
      'point',
      'linestring'
    ];

    for (const header of headers) {
      const lowerHeader = header.toLowerCase();
      if (geometryKeywords.some(keyword => lowerHeader.includes(keyword))) {
        return header;
      }
    }

    return undefined;
  }

  /**
   * Parse geometry from WKT or GeoJSON string
   */
  parseGeometry(geometryString: string): any | null {
    if (!geometryString || geometryString.trim() === '') {
      return null;
    }

    try {
      // Try parsing as GeoJSON first
      const parsed = JSON.parse(geometryString);
      if (parsed.type && (parsed.coordinates || parsed.geometries)) {
        return parsed;
      }
    } catch (e) {
      // Not JSON, try WKT
    }

    try {
      // Parse as WKT
      const geometry = wellknown.parse(geometryString);
      return geometry;
    } catch (e) {
      console.error('Failed to parse geometry:', geometryString, e);
      return null;
    }
  }

  /**
   * Convert sheet data to GeoJSON features
   */
  convertToGeoJSON(sheetData: SheetData, geometryFieldName?: string): ParsedFeature[] {
    const geomField = geometryFieldName || sheetData.geometryField;
    if (!geomField) {
      return [];
    }

    const features: ParsedFeature[] = [];

    for (const row of sheetData.rows) {
      const geometryString = row[geomField];
      const geometry = this.parseGeometry(geometryString);

      if (geometry) {
        // Create properties object excluding the geometry field
        const properties: Record<string, any> = {};
        for (const [key, value] of Object.entries(row)) {
          if (key !== geomField) {
            properties[key] = value;
          }
        }

        features.push({
          type: 'Feature',
          geometry,
          properties,
        });
      }
    }

    return features;
  }

  /**
   * Fetch all sheets from a spreadsheet
   */
  async fetchAllSheets(spreadsheetId: string): Promise<SheetData[]> {
    const metadata = await this.getSpreadsheetMetadata(spreadsheetId);
    const sheetNames = metadata.sheets?.map((sheet: any) => sheet.properties?.title).filter(Boolean) || [];

    const allSheetData: SheetData[] = [];
    for (const sheetName of sheetNames) {
      if (sheetName) {
        const data = await this.fetchSheetData(spreadsheetId, sheetName);
        allSheetData.push(data);
      }
    }

    return allSheetData;
  }
}

export const googleSheetsService = new GoogleSheetsService();
