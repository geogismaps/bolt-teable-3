/**
 * Public Google Sheets loader for demo/public data
 * Does not require OAuth authentication
 */

// @ts-ignore - wellknown doesn't have type definitions
import wellknown from 'wellknown';

export interface PublicSheetConfig {
  spreadsheetId: string;
  sheetName: string;
  geometryField: string;
}

interface CachedResponse {
  data: any;
  timestamp: number;
}

export class PublicSheetsService {
  // In-memory cache with TTL
  private cache: Map<string, CachedResponse> = new Map();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  
  /**
   * Get cached data if valid
   */
  private getCached(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;
    
    const age = Date.now() - cached.timestamp;
    if (age > this.CACHE_TTL) {
      this.cache.delete(key);
      return null;
    }
    
    return cached.data;
  }
  
  /**
   * Store data in cache
   */
  private setCached(key: string, data: any) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    });
  }
  
  /**
   * Fetch data from a public Google Sheet
   * No authentication required - uses public API endpoint
   */
  async fetchPublicSheetData(spreadsheetId: string, sheetName: string) {
    // Check cache first
    const cacheKey = `${spreadsheetId}:${sheetName}`;
    const cached = this.getCached(cacheKey);
    if (cached) {
      console.log('📦 Serving cached public sheet data');
      return cached;
    }
    
    try {
      // Use Google Sheets API v4 public endpoint
      // This works for sheets shared with "Anyone with the link"
      const url = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(sheetName)}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        // Provide specific error codes
        if (response.status === 403) {
          throw { status: 403, message: 'Sheet is private or permissions changed' };
        } else if (response.status === 404) {
          throw { status: 404, message: 'Sheet not found or was deleted' };
        } else {
          throw { status: response.status, message: `Failed to fetch sheet: ${response.statusText}` };
        }
      }
      
      const text = await response.text();
      
      // Google Sheets API returns JSONP, need to extract JSON
      // Format: /*O_o*/\ngoogle.visualization.Query.setResponse({...});
      // Use non-greedy match to avoid capturing too much
      const jsonMatch = text.match(/google\.visualization\.Query\.setResponse\(([\s\S]*?)\);?\s*$/);
      
      if (!jsonMatch || !jsonMatch[1]) {
        throw { status: 502, message: 'Invalid response format from Google Sheets' };
      }
      
      let data;
      try {
        data = JSON.parse(jsonMatch[1]);
      } catch (parseError) {
        throw { status: 502, message: 'Failed to parse Google Sheets response' };
      }
      
      if (data.status === 'error') {
        const errorMessage = data.errors?.[0]?.detailed_message || 'Unknown Google Sheets error';
        throw { status: 400, message: errorMessage };
      }
      
      // Parse the table data
      const table = data.table;
      const headers = table.cols.map((col: any) => col.label || col.id);
      
      const rows = table.rows.map((row: any) => {
        const rowData: Record<string, any> = {};
        row.c.forEach((cell: any, index: number) => {
          const header = headers[index];
          rowData[header] = cell?.v ?? null;
        });
        return rowData;
      });
      
      const result = {
        sheetName,
        headers,
        rows,
      };
      
      // Cache the result
      this.setCached(cacheKey, result);
      
      return result;
    } catch (error: any) {
      console.error('Error fetching public sheet:', error);
      // Preserve structured errors
      if (error.status && error.message) {
        throw error;
      }
      throw { status: 500, message: error.message || 'Failed to load public sheet' };
    }
  }

  /**
   * Convert sheet data to GeoJSON format
   */
  convertToGeoJSON(sheetData: any, geometryField: string) {
    const features = sheetData.rows
      .filter((row: any) => row[geometryField]) // Only include rows with geometry
      .map((row: any, index: number) => {
        let geometry = null;
        const geometryValue = row[geometryField];
        
        try {
          // Parse as WKT (Well-Known Text) using top-level import
          geometry = wellknown.parse(geometryValue);
          
          if (!geometry) {
            console.warn(`Could not parse geometry for row ${index + 2}`);
            return null;
          }
        } catch (error) {
          console.warn(`Error parsing geometry for row ${index + 2}:`, error);
          return null;
        }
        
        // Create properties without the geometry field
        const properties: Record<string, any> = { ...row };
        delete properties[geometryField];
        
        return {
          type: 'Feature',
          id: `demo-feature-${index}`, // Add unique feature ID for map diffing
          geometry,
          properties,
        };
      })
      .filter((feature: any) => feature !== null);
    
    return {
      type: 'FeatureCollection',
      features,
    };
  }
}

// Demo layer configuration
export const DEMO_LAYER_CONFIG: PublicSheetConfig = {
  spreadsheetId: '1Iiy960Kp0dftIJF_ZJSjm5uOYxgTjRH9X1ZEsJFAJak',
  sheetName: 'Import Table (1)', // Default first sheet name, can be customized
  geometryField: 'geometry', // Adjust based on your sheet structure
};
