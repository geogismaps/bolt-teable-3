import { db } from './db';
import { auditLogs, users, mapLayers, type InsertAuditLog } from '@shared/schema';
import { eq, and, gte, lte, sql as drizzleSql } from 'drizzle-orm';
import type { Request } from 'express';

/**
 * Service for creating and managing audit logs
 */
export class AuditLogService {
  /**
   * Extract request metadata for audit logging
   */
  static getRequestMetadata(req: Request) {
    // Get IP address (respecting X-Forwarded-For header for proxies)
    const sourceIp = (
      req.headers['x-forwarded-for'] as string ||
      req.socket.remoteAddress ||
      'unknown'
    ).split(',')[0].trim();

    // Get session ID from user object (set by auth middleware)
    const sessionId = (req.user as any)?.sessionId || null;

    // Get user agent
    const userAgent = req.headers['user-agent'] || null;

    return {
      sourceIp,
      sessionId,
      userAgent,
    };
  }

  /**
   * Create an audit log entry for a data edit
   */
  static async logEdit(params: {
    userId: string;
    layerId: string;
    recordId: string;
    fieldName: string;
    oldValue: any;
    newValue: any;
    action?: string;
    req: Request;
  }) {
    const { userId, layerId, recordId, fieldName, oldValue, newValue, action = 'update', req } = params;
    const { sourceIp, sessionId, userAgent } = this.getRequestMetadata(req);

    try {
      const auditLogEntry: InsertAuditLog = {
        userId,
        layerId,
        recordId,
        fieldName,
        oldValue: oldValue !== undefined ? oldValue : null,
        newValue: newValue !== undefined ? newValue : null,
        action,
        sourceIp,
        sessionId,
        userAgent,
      };

      await db.insert(auditLogs).values(auditLogEntry);

      console.log(`[AuditLog] ${action} - User ${userId} edited ${fieldName} in layer ${layerId}, record ${recordId}`);
    } catch (error) {
      // Log the error but don't fail the main operation
      console.error('[AuditLog] Failed to create audit log entry:', error);
    }
  }

  /**
   * Query audit logs with filters and pagination
   * SECURITY: Uses parameterized queries to prevent SQL injection
   */
  static async queryLogs(filters: {
    userId?: string;
    layerId?: string;
    startDate?: Date;
    endDate?: Date;
    fieldName?: string;
    action?: string;
    limit?: number;
    offset?: number;
  }) {
    const { limit = 100, offset = 0, userId, layerId, startDate, endDate, fieldName, action } = filters;

    // Build where conditions using Drizzle's type-safe query builder
    const conditions = [];
    
    if (userId) {
      conditions.push(eq(auditLogs.userId, userId));
    }
    if (layerId) {
      conditions.push(eq(auditLogs.layerId, layerId));
    }
    if (fieldName) {
      conditions.push(eq(auditLogs.fieldName, fieldName));
    }
    if (action) {
      conditions.push(eq(auditLogs.action, action));
    }
    if (startDate) {
      conditions.push(gte(auditLogs.editedAt, startDate));
    }
    if (endDate) {
      conditions.push(lte(auditLogs.editedAt, endDate));
    }

    // Build query using Drizzle's select builder with LEFT JOINs
    const query = db
      .select({
        id: auditLogs.id,
        userId: auditLogs.userId,
        layerId: auditLogs.layerId,
        recordId: auditLogs.recordId,
        fieldName: auditLogs.fieldName,
        oldValue: auditLogs.oldValue,
        newValue: auditLogs.newValue,
        action: auditLogs.action,
        sourceIp: auditLogs.sourceIp,
        sessionId: auditLogs.sessionId,
        userAgent: auditLogs.userAgent,
        editedAt: auditLogs.editedAt,
        userUsername: users.username,
        userEmail: users.email,
        layerName: mapLayers.layerName,
      })
      .from(auditLogs)
      .leftJoin(users, eq(auditLogs.userId, users.id))
      .leftJoin(mapLayers, eq(auditLogs.layerId, mapLayers.id))
      .orderBy(drizzleSql`${auditLogs.editedAt} DESC`)
      .limit(limit)
      .offset(offset);

    // Apply where conditions if any exist
    if (conditions.length > 0) {
      return await query.where(and(...conditions));
    }
    
    return await query;
  }
}
