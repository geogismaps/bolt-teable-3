import { 
  type User, 
  type InsertUser,
  type GoogleOAuthGrant,
  type InsertGoogleOAuthGrant,
  type GoogleSheetConnection,
  type InsertGoogleSheetConnection,
  type MapLayer,
  type InsertMapLayer,
  type Permission,
  type InsertPermission,
  type LayerFilter,
  type InsertLayerFilter,
  type LayerPermission,
  type InsertLayerPermission,
  type PublicMapShare,
  type InsertPublicMapShare,
  users,
  googleOAuthGrants,
  googleSheetConnections,
  mapLayers,
  permissions,
  layerFilters,
  layerPermissions,
  publicMapShares
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Google OAuth Grant operations
  getOAuthGrant(id: string): Promise<GoogleOAuthGrant | undefined>;
  getUserOAuthGrant(userId: string): Promise<GoogleOAuthGrant | undefined>;
  createOAuthGrant(grant: InsertGoogleOAuthGrant): Promise<GoogleOAuthGrant>;
  updateOAuthGrant(id: string, updates: Partial<InsertGoogleOAuthGrant>): Promise<GoogleOAuthGrant | undefined>;
  upsertOAuthGrant(grant: InsertGoogleOAuthGrant): Promise<GoogleOAuthGrant>;
  deleteOAuthGrant(id: string): Promise<void>;
  
  // Google Sheet Connection operations
  getConnection(id: string): Promise<GoogleSheetConnection | undefined>;
  getUserConnections(userId: string): Promise<GoogleSheetConnection[]>;
  createConnection(connection: InsertGoogleSheetConnection): Promise<GoogleSheetConnection>;
  updateConnection(id: string, updates: Partial<InsertGoogleSheetConnection>): Promise<GoogleSheetConnection | undefined>;
  deleteConnection(id: string): Promise<void>;
  
  // Map Layer operations
  getLayer(id: string): Promise<MapLayer | undefined>;
  getUserLayers(userId: string): Promise<MapLayer[]>;
  getLayersByConnection(connectionId: string): Promise<MapLayer[]>;
  getLayersByUserIds(userIds: string[]): Promise<MapLayer[]>;
  createLayer(layer: InsertMapLayer): Promise<MapLayer>;
  updateLayer(id: string, updates: Partial<InsertMapLayer>): Promise<MapLayer | undefined>;
  deleteLayer(id: string): Promise<void>;
  
  // Permission operations
  getPermissions(userId: string, connectionId: string): Promise<Permission[]>;
  createPermission(permission: InsertPermission): Promise<Permission>;
  deletePermission(id: string): Promise<void>;
  
  // Layer Filter operations
  getLayerFilters(layerId: string): Promise<LayerFilter[]>;
  createLayerFilter(filter: InsertLayerFilter): Promise<LayerFilter>;
  updateLayerFilter(id: string, updates: Partial<InsertLayerFilter>): Promise<LayerFilter | undefined>;
  deleteLayerFilter(id: string): Promise<void>;
  
  // Layer Permission operations
  getLayerPermissionsByUser(userId: string): Promise<LayerPermission[]>;
  getLayerPermissionsByLayer(layerId: string): Promise<LayerPermission[]>;
  getLayerPermission(userId: string, layerId: string): Promise<LayerPermission | undefined>;
  upsertLayerPermission(permission: InsertLayerPermission): Promise<LayerPermission>;
  deleteLayerPermission(id: string): Promise<void>;
  deleteLayerPermissionsByUser(userId: string): Promise<void>;
  deleteLayerPermissionsByLayer(layerId: string): Promise<void>;
  
  // Public Map Share operations
  listSharesByLayer(layerId: string): Promise<PublicMapShare[]>;
  listSharesByCreator(userId: string): Promise<PublicMapShare[]>;
  listSharesByOrganization(organizationId: string): Promise<Array<PublicMapShare & { layerName: string }>>;
  getShareByToken(token: string): Promise<PublicMapShare | undefined>;
  createShare(share: InsertPublicMapShare): Promise<PublicMapShare>;
  updateShare(id: string, updates: Partial<InsertPublicMapShare>): Promise<PublicMapShare | undefined>;
  incrementShareViewCount(id: string): Promise<void>;
  deleteShare(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Google OAuth Grant operations
  async getOAuthGrant(id: string): Promise<GoogleOAuthGrant | undefined> {
    const [grant] = await db.select().from(googleOAuthGrants).where(eq(googleOAuthGrants.id, id));
    return grant;
  }

  async getUserOAuthGrant(userId: string): Promise<GoogleOAuthGrant | undefined> {
    const [grant] = await db.select().from(googleOAuthGrants).where(eq(googleOAuthGrants.userId, userId));
    return grant;
  }

  async createOAuthGrant(grant: InsertGoogleOAuthGrant): Promise<GoogleOAuthGrant> {
    const [newGrant] = await db.insert(googleOAuthGrants).values(grant).returning();
    return newGrant;
  }

  async updateOAuthGrant(id: string, updates: Partial<InsertGoogleOAuthGrant>): Promise<GoogleOAuthGrant | undefined> {
    const [updated] = await db.update(googleOAuthGrants)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(googleOAuthGrants.id, id))
      .returning();
    return updated;
  }

  async upsertOAuthGrant(grant: InsertGoogleOAuthGrant): Promise<GoogleOAuthGrant> {
    const [upserted] = await db.insert(googleOAuthGrants)
      .values(grant)
      .onConflictDoUpdate({
        target: [googleOAuthGrants.userId],
        set: {
          accessToken: grant.accessToken,
          refreshToken: grant.refreshToken,
          tokenExpiry: grant.tokenExpiry,
          scope: grant.scope,
          updatedAt: new Date(),
        },
      })
      .returning();
    return upserted;
  }

  async deleteOAuthGrant(id: string): Promise<void> {
    await db.delete(googleOAuthGrants).where(eq(googleOAuthGrants.id, id));
  }

  // Google Sheet Connection operations
  async getConnection(id: string): Promise<GoogleSheetConnection | undefined> {
    const [connection] = await db.select().from(googleSheetConnections).where(eq(googleSheetConnections.id, id));
    return connection;
  }

  async getUserConnections(userId: string): Promise<GoogleSheetConnection[]> {
    return db.select().from(googleSheetConnections).where(eq(googleSheetConnections.userId, userId));
  }

  async createConnection(connection: InsertGoogleSheetConnection): Promise<GoogleSheetConnection> {
    const [newConnection] = await db.insert(googleSheetConnections).values(connection).returning();
    return newConnection;
  }

  async updateConnection(id: string, updates: Partial<InsertGoogleSheetConnection>): Promise<GoogleSheetConnection | undefined> {
    const [updated] = await db.update(googleSheetConnections)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(googleSheetConnections.id, id))
      .returning();
    return updated;
  }

  async deleteConnection(id: string): Promise<void> {
    await db.delete(googleSheetConnections).where(eq(googleSheetConnections.id, id));
  }

  // Map Layer operations
  async getLayer(id: string): Promise<MapLayer | undefined> {
    const [layer] = await db.select().from(mapLayers).where(eq(mapLayers.id, id));
    return layer;
  }

  async getUserLayers(userId: string): Promise<MapLayer[]> {
    return db.select().from(mapLayers).where(eq(mapLayers.userId, userId));
  }

  async getLayersByConnection(connectionId: string): Promise<MapLayer[]> {
    return db.select().from(mapLayers).where(eq(mapLayers.connectionId, connectionId));
  }

  async getLayersByUserIds(userIds: string[]): Promise<MapLayer[]> {
    if (userIds.length === 0) {
      return [];
    }
    
    // Fetch all layers owned by the list of user IDs
    // Note: This method should only be called by permissionService after validating
    // that all userIds belong to the same organization
    return db.select().from(mapLayers).where(sql`${mapLayers.userId} = ANY(${userIds})`);
  }

  async createLayer(layer: InsertMapLayer): Promise<MapLayer> {
    const [newLayer] = await db.insert(mapLayers).values(layer).returning();
    return newLayer;
  }

  async updateLayer(id: string, updates: Partial<InsertMapLayer>): Promise<MapLayer | undefined> {
    const [updated] = await db.update(mapLayers)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(mapLayers.id, id))
      .returning();
    return updated;
  }

  async deleteLayer(id: string): Promise<void> {
    await db.delete(mapLayers).where(eq(mapLayers.id, id));
  }

  // Permission operations
  async getPermissions(userId: string, connectionId: string): Promise<Permission[]> {
    return db.select().from(permissions)
      .where(and(eq(permissions.userId, userId), eq(permissions.connectionId, connectionId)));
  }

  async createPermission(permission: InsertPermission): Promise<Permission> {
    const [newPermission] = await db.insert(permissions).values(permission).returning();
    return newPermission;
  }

  async deletePermission(id: string): Promise<void> {
    await db.delete(permissions).where(eq(permissions.id, id));
  }

  // Layer Filter operations
  async getLayerFilters(layerId: string): Promise<LayerFilter[]> {
    return db.select().from(layerFilters).where(eq(layerFilters.layerId, layerId));
  }

  async createLayerFilter(filter: InsertLayerFilter): Promise<LayerFilter> {
    const [newFilter] = await db.insert(layerFilters).values(filter).returning();
    return newFilter;
  }

  async updateLayerFilter(id: string, updates: Partial<InsertLayerFilter>): Promise<LayerFilter | undefined> {
    const [updated] = await db.update(layerFilters)
      .set(updates)
      .where(eq(layerFilters.id, id))
      .returning();
    return updated;
  }

  async deleteLayerFilter(id: string): Promise<void> {
    await db.delete(layerFilters).where(eq(layerFilters.id, id));
  }

  // Layer Permission operations
  async getLayerPermissionsByUser(userId: string): Promise<LayerPermission[]> {
    return db.select().from(layerPermissions).where(eq(layerPermissions.userId, userId));
  }

  async getLayerPermissionsByLayer(layerId: string): Promise<LayerPermission[]> {
    return db.select().from(layerPermissions).where(eq(layerPermissions.layerId, layerId));
  }

  async getLayerPermission(userId: string, layerId: string): Promise<LayerPermission | undefined> {
    const [permission] = await db.select().from(layerPermissions)
      .where(and(eq(layerPermissions.userId, userId), eq(layerPermissions.layerId, layerId)));
    return permission;
  }

  async upsertLayerPermission(permission: InsertLayerPermission): Promise<LayerPermission> {
    // Use database-level upsert (ON CONFLICT DO UPDATE) to avoid race conditions
    const [upserted] = await db.insert(layerPermissions)
      .values(permission)
      .onConflictDoUpdate({
        target: [layerPermissions.userId, layerPermissions.layerId],
        set: {
          permissionLevel: permission.permissionLevel,
          updatedAt: new Date(),
        },
      })
      .returning();
    return upserted;
  }

  async deleteLayerPermission(id: string): Promise<void> {
    await db.delete(layerPermissions).where(eq(layerPermissions.id, id));
  }

  async deleteLayerPermissionsByUser(userId: string): Promise<void> {
    await db.delete(layerPermissions).where(eq(layerPermissions.userId, userId));
  }

  async deleteLayerPermissionsByLayer(layerId: string): Promise<void> {
    await db.delete(layerPermissions).where(eq(layerPermissions.layerId, layerId));
  }

  // Public Map Share operations
  async listSharesByLayer(layerId: string): Promise<PublicMapShare[]> {
    return db.select().from(publicMapShares).where(eq(publicMapShares.layerId, layerId));
  }

  async listSharesByCreator(userId: string): Promise<PublicMapShare[]> {
    return db.select().from(publicMapShares).where(eq(publicMapShares.createdByUserId, userId));
  }

  async listSharesByOrganization(organizationId: string): Promise<Array<PublicMapShare & { layerName: string }>> {
    // First get all user IDs in the organization
    const orgUsers = await db.select({ id: users.id })
      .from(users)
      .where(eq(users.organization_id, organizationId));
    
    const userIds = orgUsers.map(u => u.id);
    if (userIds.length === 0) {
      return [];
    }

    // Get all layers owned by organization users
    const orgLayers = await db.select()
      .from(mapLayers)
      .where(inArray(mapLayers.userId, userIds));

    if (orgLayers.length === 0) {
      return [];
    }

    const layerIds = orgLayers.map(l => l.id);
    const layerNameMap = new Map(orgLayers.map(l => [l.id, l.layerName]));

    // Get all shares for those layers
    const shares = await db.select()
      .from(publicMapShares)
      .where(inArray(publicMapShares.layerId, layerIds));

    // Enrich shares with layer names
    return shares.map(share => ({
      ...share,
      layerName: layerNameMap.get(share.layerId) || 'Unknown Layer'
    }));
  }

  async getShareByToken(token: string): Promise<PublicMapShare | undefined> {
    const [share] = await db.select().from(publicMapShares)
      .where(eq(publicMapShares.shareToken, token));
    return share;
  }

  async createShare(share: InsertPublicMapShare): Promise<PublicMapShare> {
    const [newShare] = await db.insert(publicMapShares).values(share).returning();
    return newShare;
  }

  async updateShare(id: string, updates: Partial<InsertPublicMapShare>): Promise<PublicMapShare | undefined> {
    const [updated] = await db.update(publicMapShares)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(publicMapShares.id, id))
      .returning();
    return updated;
  }

  async incrementShareViewCount(id: string): Promise<void> {
    await db.update(publicMapShares)
      .set({ viewCount: sql`${publicMapShares.viewCount} + 1` })
      .where(eq(publicMapShares.id, id));
  }

  async deleteShare(id: string): Promise<void> {
    await db.delete(publicMapShares).where(eq(publicMapShares.id, id));
  }
}

export const storage = new DbStorage();
