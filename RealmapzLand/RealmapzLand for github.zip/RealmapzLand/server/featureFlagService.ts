import { supabase, supabaseAdmin } from './supabaseAuth';

export interface Feature {
  key: string;
  name: string;
  description: string;
  tier: 'free' | 'basic' | 'pro' | 'enterprise';
  default_enabled: boolean;
}

export interface OrganizationFeature {
  organization_id: string;
  feature_key: string;
  enabled: boolean;
  metadata: Record<string, any>;
}

class FeatureFlagService {
  private cache: Map<string, Map<string, boolean>> = new Map();
  private cacheExpiry: Map<string, number> = new Map();
  private cacheDuration = 5 * 60 * 1000; // 5 minutes

  /**
   * Check if a feature is enabled for an organization
   * Uses anon client with RLS, not service role
   */
  async isEnabled(organizationId: string, featureKey: string): Promise<boolean> {
    // Check cache first
    const cached = this.getFromCache(organizationId, featureKey);
    if (cached !== null) {
      return cached;
    }

    try {
      // Query organization_features table (use anon client with RLS)
      const { data: orgFeature, error: orgError } = await supabase
        .from('organization_features')
        .select('enabled')
        .eq('organization_id', organizationId)
        .eq('feature_key', featureKey)
        .single();

      if (orgError && orgError.code !== 'PGRST116') { // PGRST116 = no rows found
        console.error('Error checking feature flag:', orgError);
      }

      // If organization has explicit setting, use it
      if (orgFeature) {
        this.setCache(organizationId, featureKey, orgFeature.enabled);
        return orgFeature.enabled;
      }

      // Fall back to feature definition default (use anon client)
      const { data: featureDef, error: defError } = await supabase
        .from('feature_definitions')
        .select('default_enabled')
        .eq('key', featureKey)
        .single();

      if (defError) {
        console.error('Error fetching feature definition:', defError);
        return false; // Fail closed - feature disabled if unknown
      }

      const enabled = featureDef?.default_enabled || false;
      this.setCache(organizationId, featureKey, enabled);
      return enabled;
    } catch (error) {
      console.error('Error in isEnabled:', error);
      return false; // Fail closed
    }
  }

  /**
   * Get all features for an organization
   * Rebuilds cache after fetching to ensure consistency
   */
  async getAllFeatures(organizationId: string): Promise<Record<string, boolean>> {
    try {
      // Get all feature definitions (use anon client with RLS)
      const { data: allFeatures, error: featuresError } = await supabase
        .from('feature_definitions')
        .select('key, default_enabled');

      if (featuresError) {
        console.error('Error fetching feature definitions:', featuresError);
        return {};
      }

      // Get organization-specific overrides (use anon client with RLS)
      const { data: orgFeatures, error: orgError } = await supabase
        .from('organization_features')
        .select('feature_key, enabled')
        .eq('organization_id', organizationId);

      if (orgError) {
        console.error('Error fetching organization features:', orgError);
      }

      // Build feature map
      const features: Record<string, boolean> = {};
      
      // Start with defaults
      allFeatures?.forEach(f => {
        features[f.key] = f.default_enabled;
      });

      // Override with organization settings
      orgFeatures?.forEach(f => {
        features[f.feature_key] = f.enabled;
      });

      // Update cache with fresh data
      Object.entries(features).forEach(([key, enabled]) => {
        this.setCache(organizationId, key, enabled);
      });

      return features;
    } catch (error) {
      console.error('Error in getAllFeatures:', error);
      return {};
    }
  }

  /**
   * Get all feature definitions (catalog)
   * Uses anon client (public read access via RLS)
   */
  async getFeatureDefinitions(): Promise<Feature[]> {
    try {
      const { data, error } = await supabase
        .from('feature_definitions')
        .select('*')
        .order('tier', { ascending: true })
        .order('name', { ascending: true });

      if (error) {
        console.error('Error fetching feature definitions:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error in getFeatureDefinitions:', error);
      return [];
    }
  }

  /**
   * Set feature flag for an organization
   * ADMIN ONLY - Must be called from protected routes
   * Uses service role for privileged write operation
   */
  async setFeature(
    organizationId: string,
    featureKey: string,
    enabled: boolean,
    metadata?: Record<string, any>
  ): Promise<boolean> {
    try {
      // Use service role ONLY for this privileged admin operation
      // Route must verify user is owner/admin before calling this
      const { error } = await supabaseAdmin
        .from('organization_features')
        .upsert({
          organization_id: organizationId,
          feature_key: featureKey,
          enabled,
          metadata: metadata || {},
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('Error setting feature flag:', error);
        return false;
      }

      // Invalidate cache immediately
      this.invalidateCache(organizationId);
      return true;
    } catch (error) {
      console.error('Error in setFeature:', error);
      return false;
    }
  }

  /**
   * Initialize default features for a new organization
   * SYSTEM ONLY - Called by database trigger or signup handler
   * Uses service role for initial provisioning
   */
  async initializeDefaultFeatures(organizationId: string, tier: 'free' | 'basic' | 'pro' | 'enterprise' = 'free'): Promise<boolean> {
    try {
      // Get all features for the tier (use anon client for reading)
      const { data: features, error } = await supabase
        .from('feature_definitions')
        .select('key, tier, default_enabled');

      if (error) {
        console.error('Error fetching features for initialization:', error);
        return false;
      }

      // Determine which features to enable based on tier
      const tierRank = { 'free': 0, 'basic': 1, 'pro': 2, 'enterprise': 3 };
      const orgTierRank = tierRank[tier];

      const featuresToInsert = features?.map(f => ({
        organization_id: organizationId,
        feature_key: f.key,
        enabled: tierRank[f.tier as keyof typeof tierRank] <= orgTierRank || f.default_enabled,
        metadata: {}
      })) || [];

      if (featuresToInsert.length === 0) {
        return true; // No features to insert
      }

      // Use service role ONLY for initial provisioning
      // This is called from database trigger or signup handler, not user requests
      const { error: insertError } = await supabaseAdmin
        .from('organization_features')
        .insert(featuresToInsert);

      if (insertError) {
        console.error('Error initializing default features:', insertError);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in initializeDefaultFeatures:', error);
      return false;
    }
  }

  // Cache helpers
  private getFromCache(organizationId: string, featureKey: string): boolean | null {
    const orgCache = this.cache.get(organizationId);
    const expiry = this.cacheExpiry.get(organizationId);

    if (!orgCache || !expiry || Date.now() > expiry) {
      return null;
    }

    return orgCache.get(featureKey) ?? null;
  }

  private setCache(organizationId: string, featureKey: string, enabled: boolean): void {
    if (!this.cache.has(organizationId)) {
      this.cache.set(organizationId, new Map());
    }
    
    this.cache.get(organizationId)!.set(featureKey, enabled);
    this.cacheExpiry.set(organizationId, Date.now() + this.cacheDuration);
  }

  private invalidateCache(organizationId: string): void {
    this.cache.delete(organizationId);
    this.cacheExpiry.delete(organizationId);
  }
}

// Singleton instance
export const featureFlagService = new FeatureFlagService();
