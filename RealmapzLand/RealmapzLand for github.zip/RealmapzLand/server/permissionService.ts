import { supabaseAdmin } from "./supabase";
import { storage } from "./storage";

interface FieldPermission {
  column_name: string;
  permission_level: 'view' | 'edit' | 'hidden';
}

interface User {
  id: string;
  role: 'admin' | 'editor' | 'viewer';
}

type LayerPermissionLevel = 'hidden' | 'view' | 'edit';

export class PermissionService {
  /**
   * Get all user IDs in an organization from Supabase
   * Internal helper for organization-scoped queries
   */
  async getOrganizationUserIds(organizationId: string): Promise<string[]> {
    try {
      const { data: users } = await supabaseAdmin
        .from('users')
        .select('id')
        .eq('organization_id', organizationId);

      return (users || []).map(u => u.id);
    } catch (error) {
      console.error('Error fetching organization user IDs:', error);
      return [];
    }
  }

  /**
   * Get user's effective permissions for a specific sheet
   * Returns a map of field name -> permission level
   */
  async getUserFieldPermissions(
    userId: string,
    connectionId: string,
    sheetName: string
  ): Promise<Map<string, 'view' | 'edit' | 'hidden'>> {
    const permissionMap = new Map<string, 'view' | 'edit' | 'hidden'>();

    try {
      // Fetch user role
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('role')
        .eq('id', userId)
        .single();

      if (!user) {
        // Default to most restrictive if user not found
        return permissionMap;
      }

      // Fetch explicit field permissions
      const { data: permissions } = await supabaseAdmin
        .from('permissions')
        .select('column_name, permission_level')
        .eq('user_id', userId)
        .eq('connection_id', connectionId)
        .eq('sheet_name', sheetName);

      // Store explicit permissions
      if (permissions) {
        permissions.forEach((perm: FieldPermission) => {
          permissionMap.set(perm.column_name, perm.permission_level);
        });
      }

      // Store user role for default fallback
      (permissionMap as any)._userRole = user.role;

      return permissionMap;
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      return permissionMap;
    }
  }

  /**
   * Get the effective permission for a field
   * If no explicit permission exists, falls back to role default
   */
  getEffectivePermission(
    fieldName: string,
    permissionMap: Map<string, 'view' | 'edit' | 'hidden'>,
    userRole: string = 'viewer'
  ): 'view' | 'edit' | 'hidden' {
    // Check for explicit permission
    if (permissionMap.has(fieldName)) {
      return permissionMap.get(fieldName)!;
    }

    // Fallback to role defaults
    switch (userRole) {
      case 'admin':
        return 'edit'; // Admins can edit all fields by default
      case 'editor':
        return 'edit'; // Editors can edit (unless field permission overrides)
      case 'viewer':
        return 'view'; // Viewers can only view
      default:
        return 'view';
    }
  }

  /**
   * Filter GeoJSON features based on user permissions
   * Removes hidden fields and adds metadata about editability
   */
  filterGeoJSONByPermissions(
    features: any[],
    permissionMap: Map<string, 'view' | 'edit' | 'hidden'>,
    userRole: string = 'viewer'
  ): any[] {
    if (!features || features.length === 0) {
      return features;
    }

    return features.map(feature => {
      if (!feature.properties) {
        return feature;
      }

      const filteredProperties: Record<string, any> = {};
      const editableFields: string[] = [];
      const viewOnlyFields: string[] = [];

      for (const [fieldName, value] of Object.entries(feature.properties)) {
        const permission = this.getEffectivePermission(fieldName, permissionMap, userRole);

        if (permission === 'hidden') {
          // Skip hidden fields completely
          continue;
        }

        // Include the field
        filteredProperties[fieldName] = value;

        // Track editability
        if (permission === 'edit') {
          editableFields.push(fieldName);
        } else if (permission === 'view') {
          viewOnlyFields.push(fieldName);
        }
      }

      // Add metadata about field permissions (optional, can be used by frontend)
      return {
        ...feature,
        properties: filteredProperties,
        _permissions: {
          editable: editableFields,
          viewOnly: viewOnlyFields,
        },
      };
    });
  }

  /**
   * Check if user has permission to edit a specific field
   */
  async canEditField(
    userId: string,
    connectionId: string,
    sheetName: string,
    fieldName: string
  ): Promise<boolean> {
    try {
      const permissionMap = await this.getUserFieldPermissions(userId, connectionId, sheetName);
      const userRole = (permissionMap as any)._userRole || 'viewer';
      const permission = this.getEffectivePermission(fieldName, permissionMap, userRole);
      
      return permission === 'edit';
    } catch (error) {
      console.error('Error checking field permission:', error);
      return false;
    }
  }

  /**
   * Get user by development ID (helper for dev mode)
   * In production, this would come from authentication
   */
  async getUserId(developmentUserId: string): Promise<string | null> {
    try {
      // For now, return the demo admin user ID
      // In production, this would map from your auth system to Supabase users
      return '00000000-0000-0000-0000-000000000002'; // Demo admin ID
    } catch (error) {
      console.error('Error getting user ID:', error);
      return null;
    }
  }

  /**
   * Get normalized field permissions for a layer
   * Returns both a field map and grouped arrays for easy UI consumption
   */
  async getLayerFieldPermissionsSummary(
    userId: string,
    connectionId: string,
    sheetName: string,
    allFields?: string[]
  ): Promise<{
    userRole: 'admin' | 'editor' | 'viewer';
    byField: Record<string, 'edit' | 'view' | 'hidden'>;
    groups: {
      editable: string[];
      readOnly: string[];
      hidden: string[];
    };
  }> {
    try {
      // Get permission map and user role
      const permissionMap = await this.getUserFieldPermissions(userId, connectionId, sheetName);
      const userRole = (permissionMap as any)._userRole || 'viewer';

      // Create byField object
      const byField: Record<string, 'edit' | 'view' | 'hidden'> = {};
      const groups = {
        editable: [] as string[],
        readOnly: [] as string[],
        hidden: [] as string[],
      };

      // If we have a list of all fields, classify each one
      if (allFields && allFields.length > 0) {
        allFields.forEach(fieldName => {
          const permission = this.getEffectivePermission(fieldName, permissionMap, userRole);
          byField[fieldName] = permission;

          // Add to appropriate group
          if (permission === 'edit') {
            groups.editable.push(fieldName);
          } else if (permission === 'view') {
            groups.readOnly.push(fieldName);
          } else if (permission === 'hidden') {
            groups.hidden.push(fieldName);
          }
        });
      } else {
        // Otherwise, just process explicit permissions
        permissionMap.forEach((permission, fieldName) => {
          if (fieldName === '_userRole') return; // Skip metadata
          
          byField[fieldName] = permission;

          // Add to appropriate group
          if (permission === 'edit') {
            groups.editable.push(fieldName);
          } else if (permission === 'view') {
            groups.readOnly.push(fieldName);
          } else if (permission === 'hidden') {
            groups.hidden.push(fieldName);
          }
        });
      }

      return {
        userRole,
        byField,
        groups,
      };
    } catch (error) {
      console.error('Error getting layer field permissions summary:', error);
      // Return default viewer permissions
      return {
        userRole: 'viewer',
        byField: {},
        groups: {
          editable: [],
          readOnly: [],
          hidden: [],
        },
      };
    }
  }

  /**
   * Get the default layer permission level for a user role
   * Viewer = view, Editor/Admin = edit
   */
  getRoleDefaultLayerPermission(role: 'admin' | 'editor' | 'viewer'): LayerPermissionLevel {
    switch (role) {
      case 'admin':
      case 'editor':
        return 'edit';
      case 'viewer':
        return 'view';
      default:
        return 'view';
    }
  }

  /**
   * Get effective layer permission for a user on a specific layer
   * Checks for explicit override first, then falls back to role default
   * Returns both the effective permission and whether it's inherited from role
   */
  async getEffectiveLayerPermission(
    userId: string,
    layerId: string
  ): Promise<{
    permissionLevel: LayerPermissionLevel;
    inherited: boolean;
    userRole: 'admin' | 'editor' | 'viewer';
  }> {
    try {
      // Get user role from Supabase
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('role')
        .eq('id', userId)
        .single();

      const userRole = user?.role || 'viewer';

      // Check for explicit permission override
      const override = await storage.getLayerPermission(userId, layerId);

      if (override) {
        // User has an explicit override
        return {
          permissionLevel: override.permissionLevel as LayerPermissionLevel,
          inherited: false,
          userRole,
        };
      }

      // No override, use role default
      const defaultPermission = this.getRoleDefaultLayerPermission(userRole);
      return {
        permissionLevel: defaultPermission,
        inherited: true,
        userRole,
      };
    } catch (error) {
      console.error('Error getting effective layer permission:', error);
      // Default to most restrictive
      return {
        permissionLevel: 'view',
        inherited: true,
        userRole: 'viewer',
      };
    }
  }

  /**
   * Check if a user can view a specific layer
   */
  async canViewLayer(userId: string, layerId: string): Promise<boolean> {
    const { permissionLevel } = await this.getEffectiveLayerPermission(userId, layerId);
    return permissionLevel === 'view' || permissionLevel === 'edit';
  }

  /**
   * Check if a user can edit a specific layer
   */
  async canEditLayer(userId: string, layerId: string): Promise<boolean> {
    const { permissionLevel } = await this.getEffectiveLayerPermission(userId, layerId);
    return permissionLevel === 'edit';
  }

  /**
   * Get all effective layer permissions for a user across all their accessible layers
   * Returns layer permissions with inherited flag and user role
   */
  async getAllEffectiveLayerPermissions(
    userId: string
  ): Promise<Array<{
    layerId: string;
    permissionLevel: LayerPermissionLevel;
    inherited: boolean;
  }>> {
    try {
      // Get user's explicit permission overrides
      const overrides = await storage.getLayerPermissionsByUser(userId);

      // Get user role and organization for computing defaults
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', userId)
        .single();

      if (!user) {
        return [];
      }

      const userRole = user.role || 'viewer';
      const defaultPermission = this.getRoleDefaultLayerPermission(userRole);

      // Get all user IDs in the organization from Supabase
      const organizationUserIds = await this.getOrganizationUserIds(user.organization_id);
      
      // Get all layers owned by users in the organization
      const allLayers = await storage.getLayersByUserIds(organizationUserIds);

      // Build effective permissions list
      const effectivePermissions = allLayers.map((layer: { id: string }) => {
        const override = overrides.find(o => o.layerId === layer.id);
        
        if (override) {
          return {
            layerId: layer.id,
            permissionLevel: override.permissionLevel as LayerPermissionLevel,
            inherited: false,
          };
        }

        return {
          layerId: layer.id,
          permissionLevel: defaultPermission,
          inherited: true,
        };
      });

      return effectivePermissions;
    } catch (error) {
      console.error('Error getting all effective layer permissions:', error);
      return [];
    }
  }
}

export const permissionService = new PermissionService();
