import { createClient } from '@supabase/supabase-js';

// Supabase configuration for server-side authentication
const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY!; // Service role key for admin operations
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY!; // Anon key for regular operations

if (!supabaseUrl || !supabaseServiceKey || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Admin client (uses service role key - bypasses RLS)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

// Regular client (uses anon key - respects RLS)
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

/**
 * Verify JWT token from Authorization header
 * Uses ANON key (respects RLS) - NOT service role
 * Returns the user object if valid, null otherwise
 */
export async function verifyAuthToken(token: string) {
  try {
    // Use anon client for verification - NOT admin client
    const { data, error } = await supabase.auth.getUser(token);
    
    if (error || !data.user) {
      return null;
    }
    
    return data.user;
  } catch (error) {
    console.error('Error verifying auth token:', error);
    return null;
  }
}

/**
 * Get user's organization and role in a single query
 * Includes retry logic for newly provisioned users
 */
export async function getUserOrgAndRole(
  userId: string,
  maxRetries: number = 3
): Promise<{ organizationId: string; role: string } | null> {
  let attempts = 0;
  
  while (attempts < maxRetries) {
    try {
      // Single query to get both org and role
      // Use anon client with RLS
      const { data, error } = await supabase
        .from('users')
        .select('organization_id, role')
        .eq('id', userId)
        .single();
      
      if (data && data.organization_id && data.role) {
        return {
          organizationId: data.organization_id,
          role: data.role
        };
      }
      
      if (error && error.code !== 'PGRST116') { // Not "no rows found"
        console.error('Error fetching user org/role:', error);
        return null;
      }
      
      // User might not be provisioned yet - retry after delay
      if (attempts < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, 200 * (attempts + 1))); // Exponential backoff
      }
      
      attempts++;
    } catch (error) {
      console.error('Error in getUserOrgAndRole:', error);
      return null;
    }
  }
  
  return null;
}
