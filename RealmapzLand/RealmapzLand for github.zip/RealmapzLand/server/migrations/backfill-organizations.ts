import { db } from '../db';
import { sql } from 'drizzle-orm';
import { 
  organizations, 
  users, 
  googleOAuthGrants, 
  googleSheetConnections, 
  mapLayers, 
  permissions,
  layerFilters,
  layerPermissions,
  auditLogs,
  publicMapShares
} from '../../shared/schema';

/**
 * Migration script to backfill organizationId for existing data
 * 
 * Strategy:
 * 1. Create a default organization
 * 2. Update all existing users to reference the default org
 * 3. Backfill organizationId in all related tables using user joins
 * 
 * Run with: tsx server/migrations/backfill-organizations.ts
 */

async function backfillOrganizations() {
  console.log('[MIGRATION] Starting organization backfill...');
  
  try {
    // Step 1: Create default organization
    console.log('[MIGRATION] Creating default organization...');
    const [defaultOrg] = await db
      .insert(organizations)
      .values({
        name: 'Default Organization',
        billingPlan: 'free',
        maxUsers: 50,
        maxConnections: 50,
        isActive: true,
      })
      .returning();
    
    console.log(`[MIGRATION] Created default organization: ${defaultOrg.id}`);
    
    // Step 2: Update all existing users to reference the default org
    console.log('[MIGRATION] Updating users with organizationId...');
    await db.execute(sql`
      UPDATE users 
      SET organization_id = ${defaultOrg.id}
      WHERE organization_id IS NULL
    `);
    
    // Step 3: Backfill related tables
    console.log('[MIGRATION] Backfilling google_oauth_grants...');
    await db.execute(sql`
      UPDATE google_oauth_grants 
      SET organization_id = u.organization_id
      FROM users u
      WHERE google_oauth_grants.user_id = u.id
        AND google_oauth_grants.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling google_sheet_connections...');
    await db.execute(sql`
      UPDATE google_sheet_connections 
      SET organization_id = u.organization_id
      FROM users u
      WHERE google_sheet_connections.user_id = u.id
        AND google_sheet_connections.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling map_layers...');
    await db.execute(sql`
      UPDATE map_layers 
      SET organization_id = u.organization_id
      FROM users u
      WHERE map_layers.user_id = u.id
        AND map_layers.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling permissions...');
    await db.execute(sql`
      UPDATE permissions 
      SET organization_id = u.organization_id
      FROM users u
      WHERE permissions.user_id = u.id
        AND permissions.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling layer_filters...');
    await db.execute(sql`
      UPDATE layer_filters
      SET organization_id = ml.organization_id
      FROM map_layers ml
      WHERE layer_filters.layer_id = ml.id
        AND layer_filters.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling layer_permissions...');
    await db.execute(sql`
      UPDATE layer_permissions 
      SET organization_id = u.organization_id
      FROM users u
      WHERE layer_permissions.user_id = u.id
        AND layer_permissions.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling audit_logs...');
    await db.execute(sql`
      UPDATE audit_logs 
      SET organization_id = u.organization_id
      FROM users u
      WHERE audit_logs.user_id = u.id
        AND audit_logs.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] Backfilling public_map_shares...');
    await db.execute(sql`
      UPDATE public_map_shares 
      SET organization_id = u.organization_id
      FROM users u
      WHERE public_map_shares.created_by_user_id = u.id
        AND public_map_shares.organization_id IS NULL
    `);
    
    console.log('[MIGRATION] ✅ Migration completed successfully!');
    console.log('[MIGRATION] All existing data has been assigned to the default organization.');
    
  } catch (error) {
    console.error('[MIGRATION] ❌ Migration failed:', error);
    throw error;
  }
}

// Run the migration
backfillOrganizations()
  .then(() => {
    console.log('[MIGRATION] Exiting...');
    process.exit(0);
  })
  .catch((error) => {
    console.error('[MIGRATION] Failed with error:', error);
    process.exit(1);
  });
