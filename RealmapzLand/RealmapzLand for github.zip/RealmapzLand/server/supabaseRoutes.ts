import type { Express } from "express";
import { supabaseAdmin } from "./supabase";
import { z } from "zod";

// Validation schemas
const createUserSchema = z.object({
  email: z.string().email(),
  fullName: z.string().optional(),
  role: z.enum(['admin', 'editor', 'viewer']),
  organizationId: z.string().uuid(),
  password: z.string().min(8).optional(), // Admin-set password
});

const updateUserSchema = z.object({
  fullName: z.string().optional(),
  role: z.enum(['admin', 'editor', 'viewer']).optional(),
});

const setFieldPermissionSchema = z.object({
  userId: z.string().uuid(),
  connectionId: z.string().uuid(),
  sheetName: z.string(),
  fieldName: z.string(),
  permissionLevel: z.enum(['view', 'edit', 'hidden']),
});

const bulkSetPermissionsSchema = z.object({
  userId: z.string().uuid(),
  connectionId: z.string().uuid(),
  sheetName: z.string(),
  permissions: z.array(z.object({
    fieldName: z.string(),
    permissionLevel: z.enum(['view', 'edit', 'hidden']),
  })),
});

// Middleware to check if user is authenticated
// SECURITY: This implements a basic authentication guard to prevent anonymous access
// For production with multiple users, replace with JWT/session validation
async function requireAuth(req: any, res: any, next: any) {
  // Check for authorization header (API key or Bearer token)
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'Missing Authorization header'
    });
  }

  try {
    // For development: Accept "Bearer dev" or verify against SESSION_SECRET
    const token = authHeader.replace('Bearer ', '').replace('ApiKey ', '');
    
    // Verify token matches SESSION_SECRET (acts as API key for now)
    const validToken = process.env.SESSION_SECRET || 'dev_secret_change_in_production';
    
    if (token !== validToken && token !== 'dev') {
      return res.status(401).json({ 
        error: 'Invalid authentication token',
        message: 'Token does not match expected value'
      });
    }

    // TODO PRODUCTION: Replace with real JWT/session validation
    // Example: const user = await verifyJWT(token);
    //          if (!user) return res.status(401).json({ error: 'Invalid token' });
    //          req.userId = user.id; req.userRole = user.role;
    
    // For development: Get user by email or first user
    const { storage } = await import("./storage");
    const { db } = await import("./db");
    const { users: usersTable } = await import("../shared/schema");
    
    let user = await storage.getUserByEmail('dev@example.com');
    if (!user) {
      // Get first user from database
      const users = await db.select().from(usersTable).limit(1);
      if (users.length > 0) {
        user = users[0];
      } else {
        return res.status(401).json({ error: 'No users found. Please create an account first.' });
      }
    }
    
    req.userId = user.id;
    req.userRole = user.role;
    next();
  } catch (error) {
    console.error('Authentication error in requireAuth middleware:', error);
    res.status(401).json({ error: 'Authentication failed' });
  }
}

// Middleware to check if user is admin
function requireAdmin(req: any, res: any, next: any) {
  if (req.userRole !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

export function registerSupabaseRoutes(app: Express) {
  
  // ============================================
  // FEATURE DEFINITIONS
  // ============================================
  
  /**
   * GET /api/supabase/features
   * List all feature definitions (admin only)
   */
  app.get('/api/supabase/features', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { data, error } = await supabaseAdmin
        .from('feature_definitions')
        .select('*')
        .order('tier', { ascending: true });

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching feature definitions:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================
  // ORGANIZATIONS
  // ============================================
  
  /**
   * GET /api/supabase/organizations
   * List all organizations (admin only)
   */
  app.get('/api/supabase/organizations', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { data, error } = await supabaseAdmin
        .from('organizations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching organizations:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/supabase/organizations/:orgId/features
   * Get all features for a specific organization (admin only)
   */
  app.get('/api/supabase/organizations/:orgId/features', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { orgId } = req.params;

      // Get organization features with feature definition details
      const { data, error } = await supabaseAdmin
        .from('organization_features')
        .select(`
          *,
          feature_definitions (
            name,
            tier
          )
        `)
        .eq('organization_id', orgId);

      if (error) throw error;

      // Flatten the response to make it easier to consume
      const features = (data || []).map(f => ({
        organization_id: f.organization_id,
        feature_key: f.feature_key,
        enabled: f.enabled,
        feature_name: (f as any).feature_definitions?.name,
        feature_tier: (f as any).feature_definitions?.tier,
      }));

      res.json(features);
    } catch (error: any) {
      console.error('Error fetching organization features:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * PATCH /api/supabase/organizations/:orgId/features/:featureKey
   * Toggle a feature for an organization (admin only)
   */
  app.patch('/api/supabase/organizations/:orgId/features/:featureKey', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { orgId, featureKey } = req.params;
      const { enabled } = req.body;

      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ error: 'enabled must be a boolean' });
      }

      // Update or insert the organization feature
      const { data, error } = await supabaseAdmin
        .from('organization_features')
        .upsert({
          organization_id: orgId,
          feature_key: featureKey,
          enabled: enabled
        }, {
          onConflict: 'organization_id,feature_key'
        })
        .select()
        .single();

      if (error) throw error;

      res.json(data);
    } catch (error: any) {
      console.error('Error toggling feature:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/organizations
   * Create a new organization with first admin user (super admin only)
   */
  app.post('/api/supabase/organizations', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { companyName, adminEmail, adminName, adminPassword } = req.body;
      
      if (!companyName || !adminEmail || !adminName || !adminPassword) {
        return res.status(400).json({ error: 'Company name, admin email, name, and password required' });
      }

      // Step 1: Create organization
      const { data: orgData, error: orgError } = await supabaseAdmin
        .from('organizations')
        .insert({
          name: companyName,
          billing_plan: 'free',
          max_users: 5, // Free tier limit
          max_connections: 2, // Free tier limit
        })
        .select()
        .single();

      if (orgError) throw orgError;

      let authUserId: string | null = null;

      try {
        // Step 2: Create admin auth user
        const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
          email: adminEmail,
          password: adminPassword,
          email_confirm: true, // Auto-confirm so admin can login immediately
          user_metadata: {
            full_name: adminName,
            organization_id: orgData.id,
            role: 'admin'
          }
        });

        if (authError || !authData.user) {
          throw new Error(`Failed to create admin auth user: ${authError?.message}`);
        }

        authUserId = authData.user.id;

        // Step 3: Create user record
        const { error: userError } = await supabaseAdmin
          .from('users')
          .insert({
            id: authUserId,
            email: adminEmail,
            full_name: adminName,
            role: 'admin',
            organization_id: orgData.id,
            must_change_password: true, // Force password change on first login
          });

        if (userError) throw userError;

        // Step 4: Set up default free tier features
        const defaultFeatures = [
          'google_sheets_connection',
          'map_visualization',
          'document_management',
        ];

        const featureInserts = defaultFeatures.map(featureKey => ({
          organization_id: orgData.id,
          feature_key: featureKey,
          enabled: true,
        }));

        const { error: featureError } = await supabaseAdmin
          .from('organization_features')
          .insert(featureInserts);

        if (featureError) console.error('Error setting up features:', featureError);

        res.json({
          organization: orgData,
          adminUserId: authUserId,
          adminEmail,
        });
      } catch (error) {
        // Rollback: Delete organization if user creation failed
        console.error('Error creating admin user, rolling back organization:', error);
        await supabaseAdmin.from('organizations').delete().eq('id', orgData.id);
        if (authUserId) {
          await supabaseAdmin.auth.admin.deleteUser(authUserId);
        }
        throw error;
      }
    } catch (error: any) {
      console.error('Error creating organization:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================
  // PASSWORD MANAGEMENT
  // ============================================

  /**
   * GET /api/supabase/users/:userId/must-change-password
   * Check if user must change password on login
   */
  app.get('/api/supabase/users/:userId/must-change-password', requireAuth, async (req, res) => {
    try {
      const { userId } = req.params;

      // Ensure user can only check their own status (unless admin)
      const isAdmin = req.user?.role === 'admin';
      if (!isAdmin && req.user?.id !== userId) {
        return res.status(403).json({ error: 'Forbidden' });
      }

      const { data, error } = await supabaseAdmin
        .from('users')
        .select('must_change_password')
        .eq('id', userId)
        .single();

      if (error) throw error;
      res.json({ mustChangePassword: data.must_change_password });
    } catch (error: any) {
      console.error('Error checking must_change_password:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/change-password
   * User changes their own password
   */
  app.post('/api/supabase/change-password', requireAuth, async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;

      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: 'Current and new password required' });
      }

      if (newPassword.length < 8) {
        return res.status(400).json({ error: 'New password must be at least 8 characters' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'Unauthorized' });
      }

      // Verify current password by attempting to sign in
      const userEmail = req.user?.email;
      if (!userEmail) {
        return res.status(400).json({ error: 'User email not found' });
      }

      const { error: signInError } = await supabaseAdmin.auth.signInWithPassword({
        email: userEmail,
        password: currentPassword,
      });

      if (signInError) {
        return res.status(401).json({ error: 'Current password is incorrect' });
      }

      // Update password
      const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: newPassword,
      });

      if (updateError) throw updateError;

      // Clear must_change_password flag
      const { error: dbError } = await supabaseAdmin
        .from('users')
        .update({ must_change_password: false })
        .eq('id', userId);

      if (dbError) console.error('Error updating must_change_password:', dbError);

      res.json({ success: true, message: 'Password changed successfully' });
    } catch (error: any) {
      console.error('Error changing password:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/reset-user-password
   * Admin resets a user's password
   */
  app.post('/api/supabase/reset-user-password', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { userId, newPassword } = req.body;

      if (!userId || !newPassword) {
        return res.status(400).json({ error: 'User ID and new password required' });
      }

      if (newPassword.length < 8) {
        return res.status(400).json({ error: 'New password must be at least 8 characters' });
      }

      // Update password
      const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: newPassword,
      });

      if (updateError) throw updateError;

      // Set must_change_password flag
      const { error: dbError } = await supabaseAdmin
        .from('users')
        .update({ must_change_password: true })
        .eq('id', userId);

      if (dbError) console.error('Error updating must_change_password:', dbError);

      res.json({ success: true, message: 'Password reset successfully' });
    } catch (error: any) {
      console.error('Error resetting password:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/forgot-password
   * Send password reset email
   */
  app.post('/api/supabase/forgot-password', async (req, res) => {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({ error: 'Email required' });
      }

      const { error } = await supabaseAdmin.auth.resetPasswordForEmail(email, {
        redirectTo: `${process.env.APP_URL || 'http://localhost:5000'}/reset-password`,
      });

      if (error) throw error;

      // Always return success even if email doesn't exist (security)
      res.json({ success: true, message: 'If an account exists with that email, a password reset link has been sent' });
    } catch (error: any) {
      console.error('Error sending password reset email:', error);
      // Don't reveal if email exists
      res.json({ success: true, message: 'If an account exists with that email, a password reset link has been sent' });
    }
  });

  // ============================================
  // USERS
  // ============================================
  
  /**
   * GET /api/supabase/organizations/:orgId/users
   * List users in an organization (authenticated users only)
   */
  app.get('/api/supabase/organizations/:orgId/users', requireAuth, async (req, res) => {
    try {
      const { orgId } = req.params;

      const { data, error } = await supabaseAdmin
        .from('users')
        .select('*')
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/users
   * Create a new user with admin-set password
   * Admin only
   */
  app.post('/api/supabase/users', requireAuth, requireAdmin, async (req, res) => {
    try {
      const validatedData = createUserSchema.parse(req.body);
      let authUserId: string | null = null;

      // Step 1: Create Supabase Auth user with admin-set password
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: validatedData.email,
        password: validatedData.password || `temp${Math.random().toString(36).slice(2, 10)}`, // Fallback temp password
        email_confirm: true, // Auto-confirm email so user can login immediately
        user_metadata: {
          full_name: validatedData.fullName,
          organization_id: validatedData.organizationId,
          role: validatedData.role
        }
      });

      if (authError || !authData.user) {
        console.error('Error creating user:', authError);
        return res.status(500).json({ error: 'Failed to create auth user', details: authError?.message });
      }

      authUserId = authData.user.id;

      // Step 2: Insert user record into users table
      const { data, error } = await supabaseAdmin
        .from('users')
        .insert({
          id: authUserId,
          email: validatedData.email,
          full_name: validatedData.fullName,
          role: validatedData.role,
          organization_id: validatedData.organizationId,
        })
        .select()
        .single();

      if (error) {
        // Rollback: Delete the auth user we just created
        console.error('Error creating user record, rolling back auth user:', error);
        await supabaseAdmin.auth.admin.deleteUser(authUserId);
        throw error;
      }

      // Log activity
      try {
        await supabaseAdmin.rpc('log_activity', {
          p_organization_id: validatedData.organizationId,
          p_user_id: data.id,
          p_action_type: 'user_created',
          p_entity_type: 'user',
          p_entity_id: data.id,
          p_metadata: { email: validatedData.email, role: validatedData.role },
        });
      } catch (logError) {
        console.error('Failed to log activity:', logError);
        // Continue anyway - logging failure shouldn't block user creation
      }

      res.json(data);
    } catch (error: any) {
      console.error('Error creating user:', error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid input', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * PATCH /api/supabase/users/:userId
   * Update a user (admin only)
   */
  app.patch('/api/supabase/users/:userId', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { userId } = req.params;
      const validatedData = updateUserSchema.parse(req.body);

      const updateData: any = { updated_at: new Date().toISOString() };
      if (validatedData.fullName !== undefined) updateData.full_name = validatedData.fullName;
      if (validatedData.role !== undefined) updateData.role = validatedData.role;

      const { data, error } = await supabaseAdmin
        .from('users')
        .update(updateData)
        .eq('id', userId)
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabaseAdmin.rpc('log_activity', {
        p_organization_id: data.organization_id,
        p_user_id: userId,
        p_action_type: 'user_updated',
        p_entity_type: 'user',
        p_entity_id: userId,
        p_metadata: validatedData,
      });

      res.json(data);
    } catch (error: any) {
      console.error('Error updating user:', error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid input', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * DELETE /api/supabase/users/:userId
   * Delete a user (admin only)
   */
  app.delete('/api/supabase/users/:userId', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { userId } = req.params;

      // Get user details before deletion for logging
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      const { error } = await supabaseAdmin
        .from('users')
        .delete()
        .eq('id', userId);

      if (error) throw error;

      // Log activity
      if (user) {
        await supabaseAdmin.rpc('log_activity', {
          p_organization_id: user.organization_id,
          p_user_id: userId,
          p_action_type: 'user_deleted',
          p_entity_type: 'user',
          p_entity_id: userId,
          p_metadata: { email: user.email },
        });
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting user:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================
  // FIELD PERMISSIONS
  // ============================================
  
  /**
   * GET /api/supabase/permissions/:userId/:spreadsheetId/:sheetName
   * Get all field permissions for a user on a specific sheet (authenticated users)
   */
  app.get('/api/supabase/permissions/:userId/:spreadsheetId/:sheetName', requireAuth, async (req, res) => {
    try {
      const { userId, spreadsheetId, sheetName } = req.params;

      const { data, error } = await supabaseAdmin
        .from('permissions')
        .select('*')
        .eq('user_id', userId)
        .eq('connection_id', spreadsheetId)
        .eq('sheet_name', sheetName);

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching permissions:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/supabase/permissions/user/:userId
   * Get all permissions for a user across all connections (authenticated users)
   */
  app.get('/api/supabase/permissions/user/:userId', requireAuth, async (req, res) => {
    try {
      const { userId } = req.params;

      const { data, error } = await supabaseAdmin
        .from('permissions')
        .select('*')
        .eq('user_id', userId);

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching user permissions:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/permissions
   * Set a single field permission (admin only)
   */
  app.post('/api/supabase/permissions', requireAuth, requireAdmin, async (req, res) => {
    try {
      const validatedData = setFieldPermissionSchema.parse(req.body);

      // Get organization_id from user
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', validatedData.userId)
        .single();

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const { data, error } = await supabaseAdmin
        .from('permissions')
        .upsert({
          organization_id: user.organization_id,
          user_id: validatedData.userId,
          connection_id: validatedData.connectionId,
          sheet_name: validatedData.sheetName,
          column_name: validatedData.fieldName,
          permission_level: validatedData.permissionLevel,
        })
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabaseAdmin.rpc('log_activity', {
        p_organization_id: user.organization_id,
        p_user_id: validatedData.userId,
        p_action_type: 'permission_set',
        p_entity_type: 'field_permission',
        p_entity_id: data.id,
        p_metadata: {
          sheet_name: validatedData.sheetName,
          field_name: validatedData.fieldName,
          permission_level: validatedData.permissionLevel,
        },
      });

      res.json(data);
    } catch (error: any) {
      console.error('Error setting permission:', error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid input', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/supabase/permissions/bulk
   * Set multiple field permissions at once (admin only)
   */
  app.post('/api/supabase/permissions/bulk', requireAuth, requireAdmin, async (req, res) => {
    try {
      const validatedData = bulkSetPermissionsSchema.parse(req.body);

      // Get organization_id from user
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', validatedData.userId)
        .single();

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const permissionsToInsert = validatedData.permissions.map(p => ({
        organization_id: user.organization_id,
        user_id: validatedData.userId,
        connection_id: validatedData.connectionId,
        sheet_name: validatedData.sheetName,
        column_name: p.fieldName,
        permission_level: p.permissionLevel,
      }));

      const { data, error } = await supabaseAdmin
        .from('permissions')
        .upsert(permissionsToInsert)
        .select();

      if (error) throw error;

      // Log activity
      await supabaseAdmin.rpc('log_activity', {
        p_organization_id: user.organization_id,
        p_user_id: validatedData.userId,
        p_action_type: 'permissions_bulk_set',
        p_entity_type: 'field_permission',
        p_metadata: {
          sheet_name: validatedData.sheetName,
          count: validatedData.permissions.length,
        },
      });

      res.json(data);
    } catch (error: any) {
      console.error('Error setting bulk permissions:', error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid input', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * DELETE /api/supabase/permissions/:permissionId
   * Delete a field permission (reverts to role defaults) (admin only)
   */
  app.delete('/api/supabase/permissions/:permissionId', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { permissionId } = req.params;

      // Get permission details before deletion
      const { data: permission } = await supabaseAdmin
        .from('permissions')
        .select('*')
        .eq('id', permissionId)
        .single();

      const { error } = await supabaseAdmin
        .from('permissions')
        .delete()
        .eq('id', permissionId);

      if (error) throw error;

      // Log activity
      if (permission) {
        await supabaseAdmin.rpc('log_activity', {
          p_organization_id: permission.organization_id,
          p_user_id: permission.user_id,
          p_action_type: 'permission_deleted',
          p_entity_type: 'field_permission',
          p_entity_id: permissionId,
          p_metadata: {
            sheet_name: permission.sheet_name,
            field_name: permission.field_name,
          },
        });
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting permission:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================
  // ACTIVITY LOGS
  // ============================================
  
  /**
   * GET /api/supabase/activity/:orgId
   * Get activity logs for an organization (authenticated users)
   */
  app.get('/api/supabase/activity/:orgId', requireAuth, async (req, res) => {
    try {
      const { orgId } = req.params;
      const { limit = '100', offset = '0' } = req.query;

      const { data, error } = await supabaseAdmin
        .from('activity_logs')
        .select(`
          *,
          users!inner(email, full_name)
        `)
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false })
        .range(parseInt(offset as string), parseInt(offset as string) + parseInt(limit as string) - 1);

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching activity logs:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================
  // HELPER ENDPOINTS
  // ============================================
  
  /**
   * POST /api/supabase/connections
   * Register a Google Sheets connection in Supabase (admin only)
   */
  app.post('/api/supabase/connections', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { organizationId, createdByUserId, spreadsheetId, spreadsheetName } = req.body;

      if (!organizationId || !createdByUserId || !spreadsheetId || !spreadsheetName) {
        return res.status(400).json({ 
          error: 'Missing required fields: organizationId, createdByUserId, spreadsheetId, spreadsheetName' 
        });
      }

      const { data, error } = await supabaseAdmin
        .from('google_sheet_connections')
        .insert({
          organization_id: organizationId,
          created_by_user_id: createdByUserId,
          spreadsheet_id: spreadsheetId,
          spreadsheet_name: spreadsheetName,
        })
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabaseAdmin.rpc('log_activity', {
        p_organization_id: organizationId,
        p_user_id: createdByUserId,
        p_action_type: 'connection_created',
        p_entity_type: 'google_sheet_connection',
        p_entity_id: data.id,
        p_metadata: { spreadsheet_name: spreadsheetName },
      });

      res.json(data);
    } catch (error: any) {
      console.error('Error creating connection:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/supabase/connections/:orgId
   * Get all connections for an organization (authenticated users)
   */
  app.get('/api/supabase/connections/:orgId', requireAuth, async (req, res) => {
    try {
      const { orgId } = req.params;

      const { data, error } = await supabaseAdmin
        .from('google_sheet_connections')
        .select('*')
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      res.json(data || []);
    } catch (error: any) {
      console.error('Error fetching connections:', error);
      res.status(500).json({ error: error.message });
    }
  });
}
