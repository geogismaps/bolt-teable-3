import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { googleSheetsService } from "./googleSheets";
import { PublicSheetsService, DEMO_LAYER_CONFIG } from "./publicSheets";
import { insertGoogleSheetConnectionSchema, insertMapLayerSchema, insertLayerPermissionSchema, users as usersTable } from "@shared/schema";
import { registerSupabaseRoutes } from "./supabaseRoutes";
import { permissionService } from "./permissionService";
import { AuditLogService } from "./auditLogService";
import featureFlagRoutes from "./featureFlagRoutes";
import { supabaseAdmin } from "./supabaseAuth";
import { requireAuth } from "./authMiddleware";
import { z } from "zod";
import { randomBytes } from "crypto";

// Validation schemas for layer permissions API
const bulkLayerPermissionSchema = z.object({
  userId: z.string(),
  permissionLevel: z.enum(['hidden', 'view', 'edit']),
  layerIds: z.array(z.string()).optional(),
});

const shareTokenSchema = z.object({
  layerId: z.string(),
  expiresAt: z.string().datetime().optional().nullable(),
  embedEnabled: z.boolean().optional(),
});

// Validation schema for superadmin bootstrap
const bootstrapSchema = z.object({
  companyName: z.string().min(1, 'Company name is required').max(256),
  adminEmail: z.string().email('Invalid email address').max(256),
  adminName: z.string().min(1, 'Admin name is required').max(256),
  adminPassword: z.string().min(6, 'Password must be at least 6 characters').max(256),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Register Supabase permission routes
  registerSupabaseRoutes(app);
  
  // Register feature flag routes
  app.use('/api', featureFlagRoutes);
  
  // ============================================
  // SUPERADMIN BOOTSTRAP ENDPOINT (Development/Testing Only)
  // ============================================
  
  /**
   * POST /api/superadmin/bootstrap
   * Bootstrap the first organization and admin user (no auth required)
   * 
   * DEVELOPMENT/TESTING ONLY - Self-disables after first organization is created
   * 
   * Requirements:
   * - ENABLE_SUPERADMIN_BOOTSTRAP=true environment variable
   * 
   * Features:
   * - Zod validation for all inputs with length limits
   * - Structured JSON logging for all events (success/failure)
   * - Automatic rollback on errors
   * - Self-disabling guard (checks for existing organizations)
   * 
   * Known Limitation:
   * - Race condition on concurrent requests (acceptable for dev/testing)
   * - For production use, would need database-level locking
   * 
   * Security:
   * - Logs IP address, user-agent, and all actions
   * - Rate limiting recommended but not implemented (dev use only)
   */
  app.post('/api/superadmin/bootstrap', async (req, res) => {
    const startTime = Date.now();
    const requestMetadata = {
      ip: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      timestamp: new Date().toISOString(),
    };
    
    try {
      // Check if bootstrap is enabled
      if (process.env.ENABLE_SUPERADMIN_BOOTSTRAP !== 'true') {
        const logEntry = {
          ...requestMetadata,
          event: 'bootstrap_disabled',
          success: false,
          reason: 'ENABLE_SUPERADMIN_BOOTSTRAP not set',
        };
        console.log(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        return res.status(403).json({ 
          error: 'Bootstrap endpoint is disabled. Set ENABLE_SUPERADMIN_BOOTSTRAP=true to enable.' 
        });
      }
      
      // Validate and parse request body using Zod
      const validation = bootstrapSchema.safeParse(req.body);
      if (!validation.success) {
        const logEntry = {
          ...requestMetadata,
          event: 'validation_failed',
          success: false,
          errors: validation.error.errors,
        };
        console.log(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        return res.status(400).json({ 
          error: 'Validation failed',
          details: validation.error.errors 
        });
      }
      
      const { companyName, adminEmail, adminName, adminPassword } = validation.data;
      
      // Check if any organizations already exist (self-disabling guard)
      // NOTE: Acceptable race condition for dev/testing - serialize requests manually
      const { data: existingOrgs, error: checkError } = await supabaseAdmin
        .from('organizations')
        .select('id')
        .limit(1);
      
      if (checkError) {
        const logEntry = {
          ...requestMetadata,
          event: 'check_failed',
          success: false,
          error: checkError.message,
        };
        console.error(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        return res.status(500).json({ error: 'Failed to check system state' });
      }
      
      if (existingOrgs && existingOrgs.length > 0) {
        const logEntry = {
          ...requestMetadata,
          event: 'already_bootstrapped',
          success: false,
          email: adminEmail,
        };
        console.log(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        return res.status(403).json({ 
          error: 'Bootstrap endpoint is disabled - organizations already exist. Use the normal admin panel.' 
        });
      }
      
      // Create organization
      const { data: org, error: orgError } = await supabaseAdmin
        .from('organizations')
        .insert({
          name: companyName,
          billing_plan: 'free',
          max_users: 10,
          max_connections: 10
        })
        .select()
        .single();
      
      if (orgError || !org) {
        const logEntry = {
          ...requestMetadata,
          event: 'org_creation_failed',
          success: false,
          error: orgError?.message,
          companyName,
        };
        console.error(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        return res.status(500).json({ error: 'Failed to create organization' });
      }
      
      // Create admin user in Supabase Auth
      const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: adminEmail,
        password: adminPassword,
        email_confirm: true,
        user_metadata: {
          role: 'admin',
          full_name: adminName,
        },
      });
      
      if (authError || !authUser.user) {
        const logEntry = {
          ...requestMetadata,
          event: 'auth_user_creation_failed',
          success: false,
          error: authError?.message,
          email: adminEmail,
        };
        console.error(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        await supabaseAdmin.from('organizations').delete().eq('id', org.id);
        return res.status(500).json({ error: `Failed to create admin user: ${authError?.message}` });
      }
      
      // Create user record in users table
      const { error: userError } = await supabaseAdmin
        .from('users')
        .insert({
          id: authUser.user.id,
          organization_id: org.id,
          email: adminEmail,
          full_name: adminName,
          role: 'admin'
        });
      
      if (userError) {
        const logEntry = {
          ...requestMetadata,
          event: 'user_record_creation_failed',
          success: false,
          error: userError.message,
          email: adminEmail,
        };
        console.error(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
        await supabaseAdmin.auth.admin.deleteUser(authUser.user.id);
        await supabaseAdmin.from('organizations').delete().eq('id', org.id);
        return res.status(500).json({ error: 'Failed to create user record' });
      }
      
      // Log successful bootstrap with structured data
      const duration = Date.now() - startTime;
      const successLog = {
        ...requestMetadata,
        event: 'bootstrap_success',
        success: true,
        organizationId: org.id,
        organizationName: companyName,
        userId: authUser.user.id,
        email: adminEmail,
        adminName,
        duration,
      };
      console.log(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(successLog)}`);
      console.warn(`[SUPERADMIN_BOOTSTRAP] REMINDER: Set ENABLE_SUPERADMIN_BOOTSTRAP=false and remove /superadmin before production`);
      
      res.json({ 
        success: true, 
        organizationId: org.id,
        userId: authUser.user.id,
        message: 'Organization and admin user created successfully. You can now log in.'
      });
    } catch (error: any) {
      const logEntry = {
        ...requestMetadata,
        event: 'unexpected_error',
        success: false,
        error: error.message,
        stack: error.stack,
      };
      console.error(`[SUPERADMIN_BOOTSTRAP] ${JSON.stringify(logEntry)}`);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  // ============================================
  // AUTHENTICATION ENDPOINTS
  // ============================================
  
  /**
   * GET /api/me
   * Get current authenticated user's information
   */
  app.get('/api/me', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Fetch user details from Supabase
      const { data: user, error } = await supabaseAdmin
        .from('users')
        .select('id, email, full_name, role, organization_id')
        .eq('id', userId)
        .single();
      
      if (error || !user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      res.json(user);
    } catch (error: any) {
      console.error('Error fetching current user:', error);
      res.status(500).json({ error: 'Failed to fetch user information' });
    }
  });
  
  // ============================================
  // ORGANIZATION DASHBOARD ENDPOINTS
  // ============================================
  
  /**
   * GET /api/organization/stats
   * Get stats for the current user's organization (requires authentication)
   */
  app.get('/api/organization/stats', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const orgId = req.user!.organizationId;

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Get organization details
      const { data: org } = await supabaseAdmin
        .from('organizations')
        .select('*')
        .eq('id', orgId)
        .single();

      // Count users
      const { count: userCount } = await supabaseAdmin
        .from('users')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', orgId);

      // Count connections (from main database)
      const connections = await storage.getUserConnections(user.id);
      const connectionCount = connections.length;

      // Count layers (from main database)
      const layers = await storage.getUserLayers(user.id);
      const layerCount = layers.length;

      res.json({
        id: org?.id,
        name: org?.name,
        billing_plan: org?.billing_plan || 'free',
        user_count: userCount || 0,
        connection_count: connectionCount,
        layer_count: layerCount,
      });
    } catch (error: any) {
      console.error('Error fetching organization stats:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/organization/features
   * Get enabled features for the current user's organization (requires authentication)
   */
  app.get('/api/organization/features', requireAuth, async (req, res) => {
    try {
      const orgId = req.user!.organizationId;

      // Get organization features
      const { data: features } = await supabaseAdmin
        .from('organization_features')
        .select(`
          *,
          feature_definitions (
            name,
            description
          )
        `)
        .eq('organization_id', orgId);

      // Transform the response
      const featureSummary = (features || []).map(f => ({
        feature_key: f.feature_key,
        enabled: f.enabled,
        feature_name: (f as any).feature_definitions?.name || f.feature_key,
      }));

      res.json(featureSummary);
    } catch (error: any) {
      console.error('Error fetching organization features:', error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // User provisioning endpoint (called after Supabase signup)
  // SECURITY: Verifies JWT token to ensure only the authenticated user can provision themselves
  app.post('/api/auth/provision', async (req, res) => {
    try {
      const { userId, email, fullName, organizationName } = req.body;
      
      if (!userId || !email) {
        return res.status(400).json({ error: 'Missing required fields' });
      }
      
      // SECURITY: Verify the authorization token matches the userId
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized: Missing token' });
      }
      
      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
      
      if (authError || !user) {
        console.error('Auth verification failed:', authError);
        return res.status(401).json({ error: 'Unauthorized: Invalid token' });
      }
      
      // Verify the userId matches the authenticated user
      if (user.id !== userId) {
        console.error(`User ID mismatch: token=${user.id}, body=${userId}`);
        return res.status(403).json({ error: 'Forbidden: User ID mismatch' });
      }
      
      // Check if user already provisioned (prevent duplicates)
      const { data: existingUser } = await supabaseAdmin
        .from('users')
        .select('id')
        .eq('id', userId)
        .single();
      
      if (existingUser) {
        console.log('User already provisioned:', userId);
        return res.json({ success: true, message: 'Already provisioned' });
      }
      
      // Create organization
      const { data: org, error: orgError } = await supabaseAdmin
        .from('organizations')
        .insert({
          name: organizationName || `${fullName}'s Organization`,
          billing_plan: 'free',
          max_users: 1,
          max_connections: 1
        })
        .select()
        .single();
      
      if (orgError || !org) {
        console.error('Error creating organization:', orgError);
        return res.status(500).json({ error: 'Failed to create organization' });
      }
      
      // Create user record
      const { error: userError } = await supabaseAdmin
        .from('users')
        .insert({
          id: userId,
          organization_id: org.id,
          email,
          full_name: fullName || '',
          role: 'admin'
        });
      
      if (userError) {
        console.error('Error creating user:', userError);
        // Rollback: Delete the orphaned organization
        await supabaseAdmin.from('organizations').delete().eq('id', org.id);
        return res.status(500).json({ error: 'Failed to create user record' });
      }
      
      // Initialize feature flags for free tier
      const { data: features } = await supabaseAdmin
        .from('feature_definitions')
        .select('key, tier');
      
      if (features) {
        const featuresToInsert = features.map(f => ({
          organization_id: org.id,
          feature_key: f.key,
          enabled: f.tier === 'free'
        }));
        
        const { error: featuresError } = await supabaseAdmin
          .from('organization_features')
          .insert(featuresToInsert);
        
        if (featuresError) {
          console.error('Error creating features:', featuresError);
          // Continue anyway - features can be initialized later
        }
      }
      
      res.json({ success: true, organizationId: org.id });
    } catch (error) {
      console.error('Provisioning error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  // Temporary user ID for development (in production, this would come from authentication)
  const getDevelopmentUserId = async () => {
    let user = await storage.getUserByEmail('dev@example.com');
    if (!user) {
      // Get first user from database
      const users = await db.select().from(usersTable).limit(1);
      if (users.length > 0) {
        return users[0].id;
      }
      throw new Error('No users found in database. Please create an account via /superadmin first.');
    }
    return user.id;
  };

  // === Google Sheets OAuth Routes ===

  /**
   * Check OAuth grant status
   */
  app.get('/api/oauth/grants', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const grant = await storage.getUserOAuthGrant(userId);
      
      if (!grant) {
        return res.json({
          hasGrant: false,
          grantExpiry: null,
          isExpired: false,
        });
      }

      const isExpired = grant.tokenExpiry ? new Date(grant.tokenExpiry) < new Date() : false;

      res.json({
        hasGrant: true,
        grantExpiry: grant.tokenExpiry,
        isExpired,
        accessToken: grant.accessToken,
      });
    } catch (error: any) {
      console.error('Error checking OAuth grant:', error);
      res.status(500).json({ error: 'Failed to check grant status' });
    }
  });

  /**
   * Initiate OAuth flow
   */
  app.get('/api/auth/google', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const authUrl = googleSheetsService.getAuthUrl(userId, req);
      res.json({ authUrl });
    } catch (error: any) {
      console.error('Error generating auth URL:', error);
      res.status(500).json({ error: 'Failed to generate authorization URL' });
    }
  });

  /**
   * OAuth callback handler - SAVES TOKENS TO DATABASE
   */
  app.get('/api/auth/google/callback', async (req, res) => {
    console.log('==========================================');
    console.log('🔵 OAUTH CALLBACK HIT!');
    console.log('==========================================');
    
    const { code, state } = req.query;

    // Log the request details for debugging
    console.log('OAuth callback received:', {
      url: req.url,
      fullUrl: `${req.protocol}://${req.get('host')}${req.url}`,
      host: req.get('host'),
      protocol: req.get('x-forwarded-proto') || req.protocol,
      hasCode: !!code,
      codeLength: code ? String(code).length : 0,
      state,
      query: req.query
    });

    if (!code || typeof code !== 'string') {
      return res.status(400).send('Missing authorization code');
    }

    try {
      // Always use getDevelopmentUserId to ensure user exists in database
      const userId = await getDevelopmentUserId();
      console.log('OAuth callback - userId from getDevelopmentUserId:', userId);
      
      // Verify user exists in database
      const user = await storage.getUser(userId);
      console.log('OAuth callback - user exists in DB:', !!user, user ? `(${user.email})` : '(not found)');
      
      if (!user) {
        throw new Error(`User ${userId} not found in database`);
      }
      
      if (!user.organizationId) {
        throw new Error('User does not belong to an organization. Please contact support.');
      }
      
      // Exchange code for tokens (pass req for correct redirect URI)
      const tokens = await googleSheetsService.getTokensFromCode(code, req);
      
      if (!tokens.access_token) {
        throw new Error('No access token received');
      }

      console.log('OAuth callback - about to upsert grant with userId:', userId);
      
      // Get existing grant to preserve refresh token if Google doesn't provide a new one
      const existingGrant = await storage.getUserOAuthGrant(userId);
      
      // Determine refresh token (preserve existing if Google omits on reauth)
      const refreshToken = tokens.refresh_token || existingGrant?.refreshToken;
      
      if (!refreshToken) {
        throw new Error('No refresh token available. Please reauthorize with full consent.');
      }
      
      // IMMEDIATELY save tokens to grant table (shared across all user's spreadsheets)
      const grant = await storage.upsertOAuthGrant({
        userId,
        organizationId: user.organizationId,
        accessToken: tokens.access_token!,
        refreshToken,
        tokenExpiry: tokens.expiry_date ? new Date(tokens.expiry_date) : new Date(Date.now() + 3600 * 1000),
        scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.readonly',
      });
      
      console.log('OAuth grant created/updated, grant ID:', grant.id);
      console.log('OAuth callback successful, redirecting to Settings');
      
      // Redirect to Settings page Connections tab with success indicator
      // This will auto-open the Google Drive Picker
      res.redirect(`/settings?tab=connections&auth=success&grantId=${grant.id}`);
    } catch (error: any) {
      console.error('OAuth callback error:', {
        message: error.message,
        status: error.status || error.code,
        response: error.response?.data,
        fullError: error
      });
      
      // Send detailed error page with troubleshooting info
      const errorDetails = {
        message: error.message,
        error: error.response?.data?.error || 'Unknown',
        description: error.response?.data?.error_description || 'No description available'
      };
      
      const errorHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Authentication Error</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .error { background: #fee; border: 1px solid #fcc; padding: 20px; border-radius: 5px; }
            .error h1 { color: #c00; margin-top: 0; }
            .details { background: #f5f5f5; padding: 15px; margin: 15px 0; border-radius: 5px; }
            .details pre { margin: 0; white-space: pre-wrap; }
            .action { margin-top: 20px; }
            .action a { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; }
          </style>
        </head>
        <body>
          <div class="error">
            <h1>Authentication Failed</h1>
            <p>We couldn't complete the Google OAuth authentication.</p>
            
            <div class="details">
              <strong>Error:</strong> ${errorDetails.error}<br>
              <strong>Message:</strong> ${errorDetails.message}<br>
              <strong>Description:</strong> ${errorDetails.description}
            </div>
            
            <div class="action">
              <a href="/">Try Again</a>
            </div>
            
            <p style="margin-top: 30px; font-size: 12px; color: #666;">
              <strong>Common Issues:</strong><br>
              • OAuth codes expire after a few minutes<br>
              • Codes can only be used once<br>
              • Check that redirect URI matches in Google Console
            </p>
          </div>
        </body>
        </html>
      `;
      
      res.status(500).send(errorHtml);
    }
  });

  /**
   * Batch-add multiple Google Sheets connections from Drive Picker
   * SECURITY: Uses user's OAuth grant (no tokens from client)
   */
  app.post('/api/connections/batch-add', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { spreadsheets } = req.body;
      
      if (!Array.isArray(spreadsheets) || spreadsheets.length === 0) {
        return res.status(400).json({ error: 'Missing spreadsheets array' });
      }
      
      // Get user with organization_id
      const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
      if (users.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
      const user = users[0];
      
      if (!user.organizationId) {
        return res.status(400).json({ error: 'User has no organization assigned' });
      }
      
      // Get user's OAuth grant
      const grant = await storage.getUserOAuthGrant(userId);
      if (!grant) {
        return res.status(401).json({ error: 'No OAuth grant found. Please authenticate first.' });
      }
      
      // Create connections for each selected spreadsheet
      const createdConnections = [];
      for (const sheet of spreadsheets) {
        try {
          const connection = await storage.createConnection({
            userId,
            organizationId: user.organizationId,
            grantId: grant.id,
            spreadsheetId: sheet.id,
            spreadsheetName: sheet.name,
            accessToken: null, // Use grant instead
            refreshToken: null,
            tokenExpiry: null,
          });
          createdConnections.push({
            id: connection.id,
            spreadsheetId: connection.spreadsheetId,
            spreadsheetName: connection.spreadsheetName,
            createdAt: connection.createdAt,
          });
        } catch (err: any) {
          // Skip duplicates (unique constraint violation)
          if (err.code === '23505') {
            console.log(`Skipping duplicate connection for ${sheet.name}`);
            continue;
          }
          throw err;
        }
      }
      
      res.json({
        success: true,
        connections: createdConnections,
        count: createdConnections.length,
      });
    } catch (error: any) {
      console.error('Error batch-adding connections:', error);
      res.status(500).json({ error: 'Failed to add connections' });
    }
  });

  /**
   * Create a new connection (SECURE - never accepts tokens from client)
   */
  app.post('/api/connections', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      const { spreadsheetId, spreadsheetName } = req.body;
      
      if (!spreadsheetId || !spreadsheetName) {
        return res.status(400).json({ error: 'Missing spreadsheetId or spreadsheetName' });
      }

      // NOTE: This endpoint should only be used to create connections where tokens
      // are already stored (e.g., updating a pending connection from OAuth)
      // NEVER accept accessToken/refreshToken from client
      const connection = await storage.createConnection({
        userId,
        spreadsheetId,
        spreadsheetName,
        accessToken: null,
        refreshToken: null,
        tokenExpiry: null,
      });
      
      res.json({
        id: connection.id,
        spreadsheetId: connection.spreadsheetId,
        spreadsheetName: connection.spreadsheetName,
        hasTokens: !!(connection.grantId || connection.accessToken), // Check grantId first (new system), fallback to accessToken (legacy)
        createdAt: connection.createdAt,
      });
    } catch (error: any) {
      console.error('Error creating connection:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Failed to create connection' });
    }
  });

  /**
   * List spreadsheets for a pending connection (uses stored access token)
   * SECURITY: Verifies requesting user owns the connection
   */
  app.get('/api/connections/:id/spreadsheets', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { connection, error } = await verifyConnectionOwnership(req.params.id, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);
      
      // Set credentials and list spreadsheets
      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const spreadsheets = await googleSheetsService.listSpreadsheets();
      
      res.json(spreadsheets);
    } catch (error: any) {
      console.error('Error listing spreadsheets:', error);
      res.status(500).json({ error: 'Failed to list spreadsheets' });
    }
  });

  /**
   * Update a pending connection with spreadsheet details (secure)
   * SECURITY: Verifies requesting user owns the connection
   */
  app.patch('/api/connections/:id/complete', async (req, res) => {
    try {
      const { spreadsheetId, spreadsheetName } = req.body;
      const userId = await getDevelopmentUserId();
      
      if (!spreadsheetId || !spreadsheetName) {
        return res.status(400).json({ error: 'Missing spreadsheetId or spreadsheetName' });
      }

      // SECURITY CHECK: Verify ownership before update
      const { connection: existing, error } = await verifyConnectionOwnership(req.params.id, userId);
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }

      // Update the pending connection with spreadsheet info
      // Tokens remain unchanged (already stored from OAuth)
      const connection = await storage.updateConnection(req.params.id, {
        spreadsheetId,
        spreadsheetName,
      });

      if (!connection) {
        return res.status(404).json({ error: 'Connection not found after update' });
      }

      res.json({
        id: connection.id,
        spreadsheetId: connection.spreadsheetId,
        spreadsheetName: connection.spreadsheetName,
        hasTokens: !!(connection.grantId || connection.accessToken), // Check grantId first (new system), fallback to accessToken (legacy)
        createdAt: connection.createdAt,
      });
    } catch (error: any) {
      console.error('Error completing connection:', error);
      res.status(500).json({ error: 'Failed to complete connection' });
    }
  });

  /**
   * Get user's connections (WITHOUT exposing raw tokens)
   */
  app.get('/api/connections', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const connections = await storage.getUserConnections(userId);
      
      // Remove sensitive token data before sending to client
      const safeConnections = connections.map(conn => ({
        id: conn.id,
        spreadsheetId: conn.spreadsheetId,
        spreadsheetName: conn.spreadsheetName,
        hasTokens: !!(conn.grantId || conn.accessToken), // Check grantId first (new system), fallback to accessToken (legacy)
        createdAt: conn.createdAt,
      }));
      
      res.json(safeConnections);
    } catch (error: any) {
      console.error('Error fetching connections:', error);
      res.status(500).json({ error: 'Failed to fetch connections' });
    }
  });

  /**
   * Delete a connection
   * SECURITY: Verifies requesting user owns the connection
   */
  app.delete('/api/connections/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { error } = await verifyConnectionOwnership(req.params.id, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }

      await storage.deleteConnection(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting connection:', error);
      res.status(500).json({ error: 'Failed to delete connection' });
    }
  });

  // === Security Helpers: Verify Resource Ownership ===
  
  /**
   * Middleware to verify the requesting user owns a connection
   * Prevents unauthorized access to other users' data
   */
  async function verifyConnectionOwnership(
    connectionId: string,
    userId: string
  ): Promise<{ connection: any; error?: { status: number; message: string } }> {
    const connection = await storage.getConnection(connectionId);
    
    if (!connection) {
      return { connection: null, error: { status: 404, message: 'Connection not found' } };
    }
    
    if (connection.userId !== userId) {
      return { connection: null, error: { status: 403, message: 'Forbidden: You do not own this connection' } };
    }
    
    return { connection };
  }

  /**
   * Middleware to verify the requesting user owns a layer
   * Prevents unauthorized access to other users' layers
   */
  async function verifyLayerOwnership(
    layerId: string,
    userId: string
  ): Promise<{ layer: any; error?: { status: number; message: string } }> {
    const layer = await storage.getLayer(layerId);
    
    if (!layer) {
      return { layer: null, error: { status: 404, message: 'Layer not found' } };
    }
    
    if (layer.userId !== userId) {
      return { layer: null, error: { status: 403, message: 'Forbidden: You do not own this layer' } };
    }
    
    return { layer };
  }

  // === Backend Proxy Routes for Google Sheets (NO RAW TOKENS TO CLIENT) ===

  /**
   * Fetch spreadsheet metadata (backend proxy)
   * SECURITY: Verifies requesting user owns the connection
   */
  app.get('/api/connections/:connectionId/metadata', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { connection, error } = await verifyConnectionOwnership(req.params.connectionId, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const metadata = await googleSheetsService.getSpreadsheetMetadata(connection.spreadsheetId, req.params.connectionId);
      
      res.json(metadata);
    } catch (error: any) {
      console.error('Error fetching metadata:', error);
      res.status(500).json({ error: 'Failed to fetch spreadsheet metadata' });
    }
  });

  /**
   * Fetch sheet data (backend proxy)
   * SECURITY: Verifies requesting user owns the connection
   */
  app.get('/api/connections/:connectionId/sheets/:sheetName', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { connection, error } = await verifyConnectionOwnership(req.params.connectionId, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const sheetData = await googleSheetsService.fetchSheetData(
        connection.spreadsheetId, 
        decodeURIComponent(req.params.sheetName),
        req.params.connectionId
      );
      
      res.json(sheetData);
    } catch (error: any) {
      console.error('Error fetching sheet data:', error);
      res.status(500).json({ error: 'Failed to fetch sheet data' });
    }
  });

  /**
   * Fetch GeoJSON from sheet (backend proxy)
   * SECURITY: Verifies requesting user owns the connection
   */
  app.get('/api/connections/:connectionId/sheets/:sheetName/geojson', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { connection, error } = await verifyConnectionOwnership(req.params.connectionId, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      const { geometryField } = req.query;

      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const sheetData = await googleSheetsService.fetchSheetData(
        connection.spreadsheetId, 
        decodeURIComponent(req.params.sheetName),
        req.params.connectionId
      );
      const features = googleSheetsService.convertToGeoJSON(sheetData, geometryField as string | undefined);
      
      res.json({
        type: 'FeatureCollection',
        features,
      });
    } catch (error: any) {
      console.error('Error fetching GeoJSON:', error);
      res.status(500).json({ error: 'Failed to fetch GeoJSON data' });
    }
  });

  // === Demo Layer Route (Public) ===

  /**
   * Get demo layer data from public Google Sheet
   * No authentication required
   */
  app.get('/api/demo-layer', async (req, res) => {
    try {
      const publicSheetsService = new PublicSheetsService();
      
      // Fetch data from the public demo sheet
      const sheetData = await publicSheetsService.fetchPublicSheetData(
        DEMO_LAYER_CONFIG.spreadsheetId,
        DEMO_LAYER_CONFIG.sheetName
      );
      
      // Convert to GeoJSON
      const geojson = publicSheetsService.convertToGeoJSON(
        sheetData,
        DEMO_LAYER_CONFIG.geometryField
      );
      
      // Return as a complete layer object for the frontend
      res.json({
        id: 'demo-layer',
        layerName: 'Demo Sites',
        geometryField: DEMO_LAYER_CONFIG.geometryField,
        geojson,
        headers: sheetData.headers,
      });
    } catch (error: any) {
      console.error('Error fetching demo layer:', error);
      
      // Return structured error with appropriate HTTP status code
      const status = error.status || 500;
      const message = error.message || 'Failed to fetch demo layer';
      
      res.status(status).json({ 
        error: message,
        status,
        // Add user-friendly messages for common errors
        userMessage: status === 403 
          ? 'The demo sheet is no longer publicly accessible'
          : status === 404 
          ? 'The demo sheet could not be found'
          : status === 502
          ? 'Unable to load data from Google Sheets'
          : 'Could not load demo data'
      });
    }
  });

  // === Map Layer CRUD Routes ===

  /**
   * Get user's layers
   */
  app.get('/api/layers', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const layers = await storage.getUserLayers(userId);
      res.json(layers);
    } catch (error: any) {
      console.error('Error fetching layers:', error);
      res.status(500).json({ error: 'Failed to fetch layers' });
    }
  });

  /**
   * Get single layer
   * SECURITY: Verifies requesting user owns the layer
   */
  app.get('/api/layers/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { layer, error } = await verifyLayerOwnership(req.params.id, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      res.json(layer);
    } catch (error: any) {
      console.error('Error fetching layer:', error);
      res.status(500).json({ error: 'Failed to fetch layer' });
    }
  });

  /**
   * Create a new layer (FIXED: Validate geometryField is provided)
   */
  app.post('/api/layers', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      // Get user with organization_id
      const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
      if (users.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
      const user = users[0];
      
      if (!user.organizationId) {
        return res.status(400).json({ error: 'User has no organization assigned' });
      }
      
      // Validate geometry field is provided
      if (!req.body.geometryField || req.body.geometryField.trim() === '') {
        return res.status(400).json({ 
          error: 'Geometry field is required. Please select which column contains the geographic data.' 
        });
      }
      
      const validated = insertMapLayerSchema.parse({
        ...req.body,
        userId,
        organizationId: user.organizationId,
      });

      const layer = await storage.createLayer(validated);
      res.json(layer);
    } catch (error: any) {
      console.error('Error creating layer:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Failed to create layer' });
    }
  });

  /**
   * Update a layer
   * SECURITY: Verifies requesting user owns the layer
   */
  app.patch('/api/layers/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { error } = await verifyLayerOwnership(req.params.id, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      const layer = await storage.updateLayer(req.params.id, req.body);
      res.json(layer);
    } catch (error: any) {
      console.error('Error updating layer:', error);
      res.status(500).json({ error: 'Failed to update layer' });
    }
  });

  /**
   * Delete a layer
   * SECURITY: Verifies requesting user owns the layer
   */
  app.delete('/api/layers/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { error } = await verifyLayerOwnership(req.params.id, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      await storage.deleteLayer(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting layer:', error);
      res.status(500).json({ error: 'Failed to delete layer' });
    }
  });

  /**
   * Get layer data as GeoJSON (combines layer config with sheet data)
   * SECURITY: Verifies requesting user owns both layer and connection
   * PERMISSIONS: Filters data based on user's field-level permissions from Supabase
   */
  app.get('/api/layers/:id/geojson', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { layer, error: layerError } = await verifyLayerOwnership(req.params.id, userId);
      
      if (layerError) {
        return res.status(layerError.status).json({ error: layerError.message });
      }

      // Also verify connection ownership for defense in depth
      const { connection, error: connError } = await verifyConnectionOwnership(layer.connectionId, userId);
      if (connError) {
        return res.status(connError.status).json({ error: connError.message });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      // Fetch sheet data from Google Sheets
      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const sheetData = await googleSheetsService.fetchSheetData(connection.spreadsheetId, layer.sheetName, layer.connectionId);
      let features = googleSheetsService.convertToGeoJSON(sheetData, layer.geometryField || undefined);
      
      // Apply field-level permissions from Supabase (FAIL CLOSED)
      try {
        const supabaseUserId = await permissionService.getUserId(userId);
        
        // FAIL CLOSED: If we can't map user to Supabase, deny access
        if (!supabaseUserId) {
          console.error('Cannot map user to Supabase ID - denying access');
          return res.status(503).json({ 
            error: 'Permission system unavailable. Access denied to protect sensitive data.' 
          });
        }
        
        const permissionMap = await permissionService.getUserFieldPermissions(
          supabaseUserId,
          layer.connectionId,
          layer.sheetName
        );
        const userRole = (permissionMap as any)._userRole || 'viewer';
        features = permissionService.filterGeoJSONByPermissions(features, permissionMap, userRole);
        
      } catch (permError) {
        // FAIL CLOSED: If permission checking fails, return error instead of leaking data
        console.error('Permission check failed - denying access to protect data:', permError);
        return res.status(503).json({ 
          error: 'Permission verification unavailable. Access denied to protect sensitive data.' 
        });
      }
      
      res.json({
        type: 'FeatureCollection',
        features,
      });
    } catch (error: any) {
      console.error('Error fetching layer GeoJSON:', error);
      res.status(500).json({ error: 'Failed to fetch layer data' });
    }
  });

  /**
   * Get field-level permissions for a layer
   * Returns normalized permissions for UI consumption
   * SECURITY: Verifies requesting user owns the layer
   */
  app.get('/api/layers/:layerId/field-permissions', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { layer, error: layerError } = await verifyLayerOwnership(req.params.layerId, userId);
      
      if (layerError) {
        return res.status(layerError.status).json({ error: layerError.message });
      }

      // Get the Supabase user ID for permission lookup
      const supabaseUserId = await permissionService.getUserId(userId);
      
      if (!supabaseUserId) {
        console.error('Cannot map user to Supabase ID');
        return res.status(503).json({ 
          error: 'Permission system unavailable.' 
        });
      }

      // Optionally get all fields if query param is provided
      let allFields: string[] | undefined;
      if (req.query.allFields) {
        try {
          const allFieldsParam = req.query.allFields as string;
          allFields = JSON.parse(allFieldsParam);
          if (!Array.isArray(allFields)) {
            return res.status(400).json({ error: 'allFields must be a JSON array' });
          }
        } catch (parseError) {
          return res.status(400).json({ error: 'Invalid allFields parameter - must be valid JSON array' });
        }
      }

      // Get normalized permission summary
      const permissionSummary = await permissionService.getLayerFieldPermissionsSummary(
        supabaseUserId,
        layer.connectionId,
        layer.sheetName,
        allFields
      );

      res.json({
        layerId: req.params.layerId,
        sheetName: layer.sheetName,
        ...permissionSummary,
      });
    } catch (error: any) {
      console.error('Error fetching field permissions:', error);
      res.status(500).json({ error: 'Failed to fetch field permissions' });
    }
  });

  /**
   * Update a feature in Google Sheets
   * SECURITY: Admin-only, verifies layer and connection ownership
   */
  app.patch('/api/layers/:layerId/features/:rowIndex', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      // Check if user is admin
      const user = await storage.getUser(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ error: 'Only admins can edit data' });
      }

      const { layer, error: layerError } = await verifyLayerOwnership(req.params.layerId, userId);
      
      if (layerError) {
        return res.status(layerError.status).json({ error: layerError.message });
      }

      const { connection, error: connError } = await verifyConnectionOwnership(layer.connectionId, userId);
      if (connError) {
        return res.status(connError.status).json({ error: connError.message });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      // Get the row index (1-based, where row 1 is header, data starts at row 2)
      const rowIndex = parseInt(req.params.rowIndex, 10);
      if (isNaN(rowIndex) || rowIndex < 2) {
        return res.status(400).json({ error: 'Invalid row index' });
      }

      // Get updates from request body
      const updates = req.body;
      
      // Validate that we have something to update
      if (!updates || Object.keys(updates).length === 0) {
        return res.status(400).json({ error: 'No updates provided' });
      }

      // Fetch sheet data to get headers and validate fields
      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const sheetData = await googleSheetsService.fetchSheetData(
        connection.spreadsheetId, 
        layer.sheetName, 
        layer.connectionId
      );

      // Validate all update fields exist in headers
      const invalidFields = Object.keys(updates).filter(field => !sheetData.headers.includes(field));
      if (invalidFields.length > 0) {
        return res.status(400).json({ 
          error: `Invalid fields: ${invalidFields.join(', ')}` 
        });
      }

      // Don't allow editing geometry field for now (Phase 1 requirement)
      if (layer.geometryField && updates.hasOwnProperty(layer.geometryField)) {
        return res.status(400).json({ 
          error: `Cannot edit geometry field '${layer.geometryField}' through this endpoint` 
        });
      }

      // Basic validation: non-empty for required fields (all fields required for now)
      for (const [field, value] of Object.entries(updates)) {
        if (value === null || value === undefined || String(value).trim() === '') {
          return res.status(400).json({ 
            error: `Field '${field}' cannot be empty` 
          });
        }
      }

      // Fetch current row data to merge with updates
      const currentRowData = sheetData.rows[rowIndex - 2]; // -2 because array is 0-based and excludes header
      if (!currentRowData) {
        return res.status(404).json({ error: 'Row not found' });
      }

      // Merge current data with updates
      const mergedData = { ...currentRowData, ...updates };

      // Update the row in Google Sheets
      await googleSheetsService.updateSheetRow(
        connection.spreadsheetId,
        layer.sheetName,
        rowIndex,
        mergedData,
        sheetData.headers,
        layer.connectionId
      );

      // Create audit log entries for each changed field (per-field granularity)
      // Diff currentRowData vs updates to only log actual changes
      for (const [fieldName, newValue] of Object.entries(updates)) {
        const oldValue = currentRowData[fieldName];
        
        // Only log if value actually changed
        if (oldValue !== newValue) {
          try {
            await AuditLogService.logEdit({
              userId,
              layerId: req.params.layerId,
              recordId: String(rowIndex),
              fieldName,
              oldValue,
              newValue,
              action: 'update',
              req,
            });
          } catch (auditError) {
            // Log error but don't fail the main operation
            console.error('[AuditLog] Failed to log edit:', auditError);
          }
        }
      }

      res.json({ 
        success: true,
        message: 'Feature updated successfully' 
      });
    } catch (error: any) {
      console.error('Error updating feature:', error);
      res.status(500).json({ error: 'Failed to update feature' });
    }
  });

  // === Audit Log Routes ===

  /**
   * Get audit logs with pagination and filters
   * SECURITY: Admin-only access
   */
  app.get('/api/audit-logs', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      // Check if user is admin
      const user = await storage.getUser(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ error: 'Only admins can view audit logs' });
      }

      // Parse query parameters
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const filterUserId = req.query.userId as string | undefined;
      const filterLayerId = req.query.layerId as string | undefined;
      const filterFieldName = req.query.fieldName as string | undefined;
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;

      // Query audit logs with filters
      const logs = await AuditLogService.queryLogs({
        userId: filterUserId,
        layerId: filterLayerId,
        fieldName: filterFieldName,
        startDate,
        endDate,
        limit,
        offset,
      });

      res.json(logs);
    } catch (error: any) {
      console.error('Error fetching audit logs:', error);
      res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
  });

  // === Permission Routes ===

  /**
   * Get permissions for a connection
   */
  app.get('/api/permissions/:connectionId', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const permissions = await storage.getPermissions(userId, req.params.connectionId);
      res.json(permissions);
    } catch (error: any) {
      console.error('Error fetching permissions:', error);
      res.status(500).json({ error: 'Failed to fetch permissions' });
    }
  });

  // === Layer Filter Routes ===

  /**
   * Get all filters for a layer
   * SECURITY: Verifies requesting user owns the layer
   */
  app.get('/api/layers/:layerId/filters', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { error } = await verifyLayerOwnership(req.params.layerId, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      const filters = await storage.getLayerFilters(req.params.layerId);
      res.json(filters);
    } catch (error: any) {
      console.error('Error fetching layer filters:', error);
      res.status(500).json({ error: 'Failed to fetch filters' });
    }
  });

  /**
   * Create a new filter for a layer
   * SECURITY: Verifies requesting user owns the layer
   */
  app.post('/api/layers/:layerId/filters', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      const { error } = await verifyLayerOwnership(req.params.layerId, userId);
      
      if (error) {
        return res.status(error.status).json({ error: error.message });
      }
      
      const filter = await storage.createLayerFilter({
        ...req.body,
        layerId: req.params.layerId,
      });
      res.json(filter);
    } catch (error: any) {
      console.error('Error creating filter:', error);
      res.status(500).json({ error: 'Failed to create filter' });
    }
  });

  /**
   * Update a filter
   * SECURITY: Verifies requesting user owns the layer that owns the filter
   */
  app.patch('/api/filters/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      // Get filter to find its layer
      // Get all user layers to verify ownership
      const userLayers = await storage.getUserLayers(userId);
      let filterLayer = null;
      
      for (const layer of userLayers) {
        const layerFilters = await storage.getLayerFilters(layer.id);
        const filter = layerFilters.find(f => f.id === req.params.id);
        if (filter) {
          filterLayer = layer;
          break;
        }
      }
      
      if (!filterLayer) {
        return res.status(404).json({ error: 'Filter not found or access denied' });
      }
      
      const filter = await storage.updateLayerFilter(req.params.id, req.body);
      if (!filter) {
        return res.status(404).json({ error: 'Filter not found' });
      }
      res.json(filter);
    } catch (error: any) {
      console.error('Error updating filter:', error);
      res.status(500).json({ error: 'Failed to update filter' });
    }
  });

  /**
   * Delete a filter
   * SECURITY: Verifies requesting user owns the layer that owns the filter
   */
  app.delete('/api/filters/:id', async (req, res) => {
    try {
      const userId = await getDevelopmentUserId();
      
      // Verify ownership by checking all user's layers for this filter
      const userLayers = await storage.getUserLayers(userId);
      let hasAccess = false;
      
      for (const layer of userLayers) {
        const layerFilters = await storage.getLayerFilters(layer.id);
        if (layerFilters.some(f => f.id === req.params.id)) {
          hasAccess = true;
          break;
        }
      }
      
      if (!hasAccess) {
        return res.status(404).json({ error: 'Filter not found or access denied' });
      }
      
      await storage.deleteLayerFilter(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting filter:', error);
      res.status(500).json({ error: 'Failed to delete filter' });
    }
  });

  // ============================================
  // LAYER PERMISSIONS ENDPOINTS
  // ============================================

  /**
   * GET /api/layer-permissions/user/:userId
   * Get all layer permissions for a specific user with effective permissions
   * Returns: Array of { layerId, layerName, permissionLevel, inherited, override }
   * SECURITY: Requires auth, admin-only, same organization
   */
  app.get('/api/layer-permissions/user/:userId', requireAuth, async (req, res) => {
    try {
      const requestingUserId = req.user!.id;
      const targetUserId = req.params.userId;

      // Verify requesting user is admin
      const { data: requestingUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', requestingUserId)
        .single();

      if (!requestingUser || requestingUser.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      // Verify target user exists and is in same organization
      const { data: targetUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', targetUserId)
        .single();

      if (!targetUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      if (targetUser.organization_id !== requestingUser.organization_id) {
        return res.status(403).json({ error: 'Cannot access users from other organizations' });
      }

      // Get all user IDs in the organization from Supabase
      const organizationUserIds = await permissionService.getOrganizationUserIds(requestingUser.organization_id);
      
      // Get all layers owned by users in the organization
      const allLayers = await storage.getLayersByUserIds(organizationUserIds);

      // Get explicit permission overrides for target user
      const overrides = await storage.getLayerPermissionsByUser(targetUserId);

      // Get role default permission
      const defaultPermission = permissionService.getRoleDefaultLayerPermission(targetUser.role);

      // Build response with effective permissions
      const permissions = allLayers.map(layer => {
        const override = overrides.find(o => o.layerId === layer.id);
        
        return {
          layerId: layer.id,
          layerName: layer.layerName,
          permissionLevel: override ? override.permissionLevel : defaultPermission,
          isInherited: !override,
        };
      });

      res.json(permissions);
    } catch (error: any) {
      console.error('Error fetching user layer permissions:', error);
      res.status(500).json({ error: 'Failed to fetch layer permissions' });
    }
  });

  /**
   * POST /api/layer-permissions
   * Create or update a layer permission override
   * Body: { userId, layerId, permissionLevel }
   * SECURITY: Requires auth, admin-only, validates user/layer exist and are in same org
   */
  app.post('/api/layer-permissions', requireAuth, async (req, res) => {
    try {
      const requestingUserId = req.user!.id;

      // Validate request body
      const validatedData = insertLayerPermissionSchema.parse(req.body);

      // Verify requesting user is admin
      const { data: requestingUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', requestingUserId)
        .single();

      if (!requestingUser || requestingUser.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      // Verify target user exists and is in same organization
      const { data: targetUser } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', validatedData.userId)
        .single();

      if (!targetUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      if (targetUser.organization_id !== requestingUser.organization_id) {
        return res.status(403).json({ error: 'Cannot modify permissions for users in other organizations' });
      }

      // Verify layer exists and user has access
      const layer = await storage.getLayer(validatedData.layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Layer not found' });
      }

      // Verify layer owner is in same organization as requesting user
      const { data: layerOwner } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', layer.userId)
        .single();
        
      if (!layerOwner || layerOwner.organization_id !== requestingUser.organization_id) {
        return res.status(403).json({ error: 'Cannot modify permissions for layers in other organizations' });
      }

      // Upsert the permission (handles race conditions with DB-level upsert)
      const permission = await storage.upsertLayerPermission(validatedData);

      res.json(permission);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid request data', details: error.errors });
      }
      console.error('Error creating/updating layer permission:', error);
      res.status(500).json({ error: 'Failed to create/update layer permission' });
    }
  });

  /**
   * POST /api/layer-permissions/bulk
   * Bulk update layer permissions for a user
   * Body: { userId, permissionLevel, layerIds?: string[] }
   * If layerIds not provided, applies to all layers in the organization
   * SECURITY: Requires auth, admin-only, transactional
   */
  app.post('/api/layer-permissions/bulk', requireAuth, async (req, res) => {
    try {
      const requestingUserId = req.user!.id;

      // Validate request body
      const validatedData = bulkLayerPermissionSchema.parse(req.body);

      // Verify requesting user is admin
      const { data: requestingUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', requestingUserId)
        .single();

      if (!requestingUser || requestingUser.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      // Verify target user exists and is in same organization
      const { data: targetUser } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', validatedData.userId)
        .single();

      if (!targetUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      if (targetUser.organization_id !== requestingUser.organization_id) {
        return res.status(403).json({ error: 'Cannot modify permissions for users in other organizations' });
      }

      // Get layers to update
      let layersToUpdate = validatedData.layerIds;
      if (!layersToUpdate) {
        // Apply to all layers in the organization
        // Get all user IDs in the organization from Supabase
        const organizationUserIds = await permissionService.getOrganizationUserIds(requestingUser.organization_id);
        const allLayers = await storage.getLayersByUserIds(organizationUserIds);
        layersToUpdate = allLayers.map(l => l.id);
      }

      // Validate all layers exist and are in same organization
      for (const layerId of layersToUpdate) {
        const layer = await storage.getLayer(layerId);
        if (!layer) {
          return res.status(404).json({ error: `Layer ${layerId} not found` });
        }
        
        const { data: layerOwner } = await supabaseAdmin
          .from('users')
          .select('organization_id')
          .eq('id', layer.userId)
          .single();
          
        if (!layerOwner || layerOwner.organization_id !== requestingUser.organization_id) {
          return res.status(403).json({ error: 'Cannot modify permissions for layers in other organizations' });
        }
      }

      // Bulk upsert permissions (each upsert is atomic via onConflictDoUpdate)
      const results = await Promise.all(
        layersToUpdate.map(layerId =>
          storage.upsertLayerPermission({
            userId: validatedData.userId,
            layerId,
            permissionLevel: validatedData.permissionLevel,
          })
        )
      );

      res.json({ 
        success: true, 
        updated: results.length,
        permissions: results 
      });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid request data', details: error.errors });
      }
      console.error('Error bulk updating layer permissions:', error);
      res.status(500).json({ error: 'Failed to bulk update layer permissions' });
    }
  });

  /**
   * DELETE /api/layer-permissions/:id
   * Delete a single layer permission override
   * SECURITY: Requires auth, admin-only, validates permission user is in same org
   */
  app.delete('/api/layer-permissions/:id', requireAuth, async (req, res) => {
    try {
      const requestingUserId = req.user!.id;

      // Verify requesting user is admin
      const { data: requestingUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', requestingUserId)
        .single();

      if (!requestingUser || requestingUser.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      // Get all permissions across all organization users to find the target
      const orgUserIds = await permissionService.getOrganizationUserIds(requestingUser.organization_id);
      const allOrgPermissions = await Promise.all(
        orgUserIds.map(userId => storage.getLayerPermissionsByUser(userId))
      );
      
      // Flatten and find the permission to delete
      const flatPermissions = allOrgPermissions.flat();
      const permissionToDelete = flatPermissions.find(p => p.id === req.params.id);

      if (!permissionToDelete) {
        return res.status(404).json({ error: 'Permission not found or access denied' });
      }

      // At this point, we've confirmed the permission belongs to someone in our org
      await storage.deleteLayerPermission(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting layer permission:', error);
      res.status(500).json({ error: 'Failed to delete layer permission' });
    }
  });

  /**
   * DELETE /api/layer-permissions/user/:userId
   * Delete all layer permission overrides for a user (reset to role defaults)
   * SECURITY: Requires auth, admin-only, same organization
   */
  app.delete('/api/layer-permissions/user/:userId', requireAuth, async (req, res) => {
    try {
      const requestingUserId = req.user!.id;
      const targetUserId = req.params.userId;

      // Verify requesting user is admin
      const { data: requestingUser } = await supabaseAdmin
        .from('users')
        .select('role, organization_id')
        .eq('id', requestingUserId)
        .single();

      if (!requestingUser || requestingUser.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
      }

      // Verify target user exists and is in same organization
      const { data: targetUser } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', targetUserId)
        .single();

      if (!targetUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      if (targetUser.organization_id !== requestingUser.organization_id) {
        return res.status(403).json({ error: 'Cannot modify permissions for users in other organizations' });
      }

      await storage.deleteLayerPermissionsByUser(targetUserId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting user layer permissions:', error);
      res.status(500).json({ error: 'Failed to delete user layer permissions' });
    }
  });

  // ============================================
  // PUBLIC MAP SHARE ENDPOINTS
  // ============================================

  /**
   * POST /api/share/create
   * Create a new shareable map link
   * SECURITY: Requires auth, validates edit permission on layer, organization scoping
   */
  app.post('/api/share/create', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const validatedData = shareTokenSchema.parse(req.body);

      // Fetch layer to verify ownership and organization
      const layer = await storage.getLayer(validatedData.layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Layer not found' });
      }

      // Get user's organization
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id, role')
        .eq('id', userId)
        .single();

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Verify layer belongs to user's organization
      const layerOwner = await storage.getUser(layer.userId);
      if (!layerOwner || layerOwner.organization_id !== user.organization_id) {
        return res.status(403).json({ error: 'Cannot share layers from other organizations' });
      }

      // Check if user has edit permission on this layer
      const effectivePermission = await permissionService.getEffectiveLayerPermission(userId, validatedData.layerId);
      if (effectivePermission !== 'edit') {
        return res.status(403).json({ error: 'Edit permission required to share layers' });
      }

      // Generate cryptographically secure token (32 bytes = 64 hex characters)
      const shareToken = randomBytes(32).toString('hex');

      // Create the share
      const share = await storage.createShare({
        shareToken,
        layerId: validatedData.layerId,
        createdByUserId: userId,
        expiresAt: validatedData.expiresAt ? new Date(validatedData.expiresAt) : null,
        embedEnabled: validatedData.embedEnabled ?? true,
      });

      res.json(share);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid request data', details: error.errors });
      }
      console.error('Error creating share:', error);
      res.status(500).json({ error: 'Failed to create share' });
    }
  });

  /**
   * GET /api/share/:token
   * Fetch shared map data (public endpoint, no auth required)
   * SECURITY: Validates expiry, sanitizes response, increments view count
   */
  app.get('/api/share/:token', async (req, res) => {
    try {
      const { token } = req.params;

      // Fetch share by token
      const share = await storage.getShareByToken(token);
      if (!share) {
        return res.status(404).json({ error: 'Share not found' });
      }

      // Check if share has expired
      if (share.expiresAt && new Date(share.expiresAt) < new Date()) {
        return res.status(410).json({ error: 'Share has expired' });
      }

      // Fetch layer data
      const layer = await storage.getLayer(share.layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Layer not found' });
      }

      // Increment view count
      await storage.incrementShareViewCount(share.id);

      // Sanitize response (remove sensitive data)
      const sanitizedResponse = {
        shareToken: share.shareToken,
        layerId: share.layerId,
        layerName: layer.layerName,
        embedEnabled: share.embedEnabled,
        viewCount: share.viewCount + 1,
        createdAt: share.createdAt,
        expiresAt: share.expiresAt,
        // Layer configuration
        color: layer.color,
        geometryField: layer.geometryField,
        labelField: layer.labelField,
        symbology: layer.symbology,
        popupFields: layer.popupFields,
      };

      res.json(sanitizedResponse);
    } catch (error: any) {
      console.error('Error fetching shared map:', error);
      res.status(500).json({ error: 'Failed to fetch shared map' });
    }
  });

  /**
   * GET /api/share/:token/data
   * Fetch GeoJSON data for shared map (public endpoint, no auth required)
   * SECURITY: Validates expiry, returns full layer data (no field-level permissions for shares)
   */
  app.get('/api/share/:token/data', async (req, res) => {
    try {
      const { token } = req.params;

      // Fetch share by token
      const share = await storage.getShareByToken(token);
      if (!share) {
        return res.status(404).json({ error: 'Share not found' });
      }

      // Check if share has expired
      if (share.expiresAt && new Date(share.expiresAt) < new Date()) {
        return res.status(410).json({ error: 'Share has expired' });
      }

      // Fetch layer data
      const layer = await storage.getLayer(share.layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Layer not found' });
      }

      // Fetch connection
      const connection = await storage.getConnection(layer.connectionId);
      if (!connection) {
        return res.status(404).json({ error: 'Connection not found' });
      }

      // Resolve credentials via grant or legacy tokens
      const credentials = await googleSheetsService.resolveConnectionCredentials(connection, storage);

      // Fetch sheet data from Google Sheets
      googleSheetsService.setCredentials(credentials.accessToken, credentials.refreshToken || undefined);
      const sheetData = await googleSheetsService.fetchSheetData(
        connection.spreadsheetId, 
        layer.sheetName, 
        layer.connectionId
      );
      
      // Convert to GeoJSON (no field-level permissions for public shares)
      const features = googleSheetsService.convertToGeoJSON(sheetData, layer.geometryField || undefined);
      
      res.json({
        geojson: {
          type: 'FeatureCollection',
          features,
        },
      });
    } catch (error: any) {
      console.error('Error fetching shared map data:', error);
      res.status(500).json({ error: 'Failed to fetch shared map data' });
    }
  });

  /**
   * PATCH /api/share/:id
   * Update share settings (expiry, embed enabled)
   * SECURITY: Requires auth, validates creator/admin/owner permissions
   */
  app.patch('/api/share/:id', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { id } = req.params;
      
      // Validate update data
      const updateSchema = z.object({
        expiresAt: z.string().datetime().optional().nullable(),
        embedEnabled: z.boolean().optional(),
      });
      const validatedData = updateSchema.parse(req.body);

      // Fetch share and layer to verify permissions
      const share = await storage.getShareByToken(id); // Note: using ID as token lookup fallback
      if (!share) {
        // Try fetching by ID directly from DB
        const shares = await storage.listSharesByCreator(userId);
        const targetShare = shares.find(s => s.id === id);
        if (!targetShare) {
          return res.status(404).json({ error: 'Share not found' });
        }
      }

      const actualShare = share || (await storage.listSharesByCreator(userId)).find(s => s.id === id);
      if (!actualShare) {
        return res.status(404).json({ error: 'Share not found' });
      }

      // Fetch layer to get organization context
      const layer = await storage.getLayer(actualShare.layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Associated layer not found' });
      }

      // Get user info
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id, role')
        .eq('id', userId)
        .single();

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Verify layer belongs to same organization
      const layerOwner = await storage.getUser(layer.userId);
      if (!layerOwner || layerOwner.organization_id !== user.organization_id) {
        return res.status(403).json({ error: 'Cannot modify shares from other organizations' });
      }

      // Check permission: creator OR admin OR layer owner
      const isCreator = actualShare.createdByUserId === userId;
      const isAdmin = user.role === 'admin';
      const isLayerOwner = layer.userId === userId;

      if (!isCreator && !isAdmin && !isLayerOwner) {
        return res.status(403).json({ error: 'Insufficient permissions to modify this share' });
      }

      // Update the share
      const updatedShare = await storage.updateShare(id, {
        expiresAt: validatedData.expiresAt ? new Date(validatedData.expiresAt) : undefined,
        embedEnabled: validatedData.embedEnabled,
      });

      res.json(updatedShare);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid request data', details: error.errors });
      }
      console.error('Error updating share:', error);
      res.status(500).json({ error: 'Failed to update share' });
    }
  });

  /**
   * GET /api/share/organization
   * List all shares for the user's organization
   * SECURITY: Requires auth, organization scoping
   */
  app.get('/api/share/organization', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;

      // Get user organization
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', userId)
        .single();

      if (!user || !user.organization_id) {
        return res.status(404).json({ error: 'User organization not found' });
      }

      // Fetch all shares for the organization using optimized storage method
      const shares = await storage.listSharesByOrganization(user.organization_id);

      // Sort by createdAt descending (newest first)
      shares.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      res.json(shares);
    } catch (error: any) {
      console.error('Error fetching organization shares:', error);
      res.status(500).json({ error: 'Failed to fetch organization shares' });
    }
  });

  /**
   * GET /api/share/layer/:layerId
   * List all shares for a specific layer
   * SECURITY: Requires auth, validates user has access to the layer
   */
  app.get('/api/share/layer/:layerId', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { layerId } = req.params;

      // Verify layer exists and user has access
      const layer = await storage.getLayer(layerId);
      if (!layer) {
        return res.status(404).json({ error: 'Layer not found' });
      }

      // Get user organization
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('organization_id')
        .eq('id', userId)
        .single();

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Verify layer belongs to same organization
      const layerOwner = await storage.getUser(layer.userId);
      if (!layerOwner || layerOwner.organization_id !== user.organization_id) {
        return res.status(403).json({ error: 'Cannot access shares from other organizations' });
      }

      // Fetch all shares for this layer, sorted by createdAt descending (newest first)
      const shares = await storage.listSharesByLayer(layerId);
      const sortedShares = shares.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      res.json(sortedShares);
    } catch (error: any) {
      console.error('Error fetching layer shares:', error);
      res.status(500).json({ error: 'Failed to fetch layer shares' });
    }
  });

  /**
   * DELETE /api/share/:id
   * Revoke a share link
   * SECURITY: Requires auth, validates creator/admin/owner permissions, organization scoping
   */
  app.delete('/api/share/:id', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { id } = req.params;

      // Fetch all shares by creator to find the target share
      const creatorShares = await storage.listSharesByCreator(userId);
      let targetShare = creatorShares.find(s => s.id === id);

      // If not found as creator, check if user is admin or layer owner
      if (!targetShare) {
        // Get user info
        const { data: user } = await supabaseAdmin
          .from('users')
          .select('organization_id, role')
          .eq('id', userId)
          .single();

        if (!user) {
          return res.status(404).json({ error: 'User not found' });
        }

        // Get all layers in organization
        const orgUserIds = await permissionService.getOrganizationUserIds(user.organization_id);
        const orgLayers = await storage.getLayersByUserIds(orgUserIds);
        
        // Find shares for these layers
        const allOrgShares = await Promise.all(
          orgLayers.map(layer => storage.listSharesByLayer(layer.id))
        );
        const flatShares = allOrgShares.flat();
        targetShare = flatShares.find(s => s.id === id);

        if (!targetShare) {
          return res.status(404).json({ error: 'Share not found' });
        }

        // Verify permission: admin OR layer owner
        const layer = await storage.getLayer(targetShare.layerId);
        const isAdmin = user.role === 'admin';
        const isLayerOwner = layer && layer.userId === userId;

        if (!isAdmin && !isLayerOwner) {
          return res.status(403).json({ error: 'Insufficient permissions to delete this share' });
        }
      }

      // Delete the share
      await storage.deleteShare(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error deleting share:', error);
      res.status(500).json({ error: 'Failed to delete share' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
