import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';

export interface FeatureDefinition {
  key: string;
  name: string;
  description: string;
  tier: 'free' | 'basic' | 'pro' | 'enterprise';
  default_enabled: boolean;
}

/**
 * Hook to check if specific features are enabled
 * Returns a map of feature keys to their enabled status
 */
export function useFeatureFlags() {
  const { session } = useAuth();
  
  return useQuery({
    queryKey: ['/api/feature-flags'],
    enabled: !!session,
    staleTime: 5 * 60 * 1000, // 5 minutes
    select: (data: Record<string, boolean>) => ({
      features: data,
      isEnabled: (featureKey: string) => data[featureKey] === true,
      hasAnyFeature: (...featureKeys: string[]) => 
        featureKeys.some(key => data[key] === true),
      hasAllFeatures: (...featureKeys: string[]) => 
        featureKeys.every(key => data[key] === true),
    })
  });
}

/**
 * Hook to get all feature definitions (catalog)
 */
export function useFeatureDefinitions() {
  const { session } = useAuth();
  
  return useQuery<FeatureDefinition[]>({
    queryKey: ['/api/feature-flags/definitions'],
    enabled: !!session,
    staleTime: 60 * 60 * 1000, // 1 hour (definitions don't change often)
  });
}

/**
 * Hook to check a single feature flag
 */
export function useFeature(featureKey: string): boolean {
  const { data } = useFeatureFlags();
  return data?.isEnabled(featureKey) ?? false;
}
