import { useQuery } from '@tanstack/react-query';

export interface FieldPermissions {
  layerId: string;
  sheetName: string;
  userRole: 'admin' | 'editor' | 'viewer';
  byField: Record<string, 'edit' | 'view' | 'hidden'>;
  groups: {
    editable: string[];
    readOnly: string[];
    hidden: string[];
  };
}

/**
 * Hook to fetch field-level permissions for a layer
 * @param layerId - The layer ID to fetch permissions for
 * @param allFields - Optional array of all field names to classify
 * @param enabled - Whether to enable the query (default: true)
 */
export function useFieldPermissions(
  layerId: string | undefined,
  allFields?: string[],
  enabled: boolean = true
) {
  return useQuery<FieldPermissions>({
    queryKey: ['/api/layers', layerId, 'field-permissions', allFields],
    enabled: enabled && !!layerId,
    // Add allFields as query parameter if provided
    queryFn: async () => {
      const url = new URL(`/api/layers/${layerId}/field-permissions`, window.location.origin);
      if (allFields && allFields.length > 0) {
        url.searchParams.set('allFields', JSON.stringify(allFields));
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error('Failed to fetch field permissions');
      }
      return response.json();
    },
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes (permissions don't change often)
  });
}

/**
 * Helper to check if a field is hidden
 */
export function isFieldHidden(
  fieldName: string,
  permissions?: FieldPermissions
): boolean {
  if (!permissions) return false;
  
  // Check explicit permission
  if (permissions.byField[fieldName]) {
    return permissions.byField[fieldName] === 'hidden';
  }
  
  // Never hide by default
  return false;
}

/**
 * Helper to check if a field is editable
 */
export function isFieldEditable(
  fieldName: string,
  permissions?: FieldPermissions
): boolean {
  if (!permissions) {
    // Default to view-only if no permissions
    return false;
  }
  
  // Check explicit permission
  if (permissions.byField[fieldName]) {
    return permissions.byField[fieldName] === 'edit';
  }
  
  // Fallback to role default
  return permissions.userRole === 'admin' || permissions.userRole === 'editor';
}

/**
 * Helper to check if a field is read-only (viewable but not editable)
 */
export function isFieldReadOnly(
  fieldName: string,
  permissions?: FieldPermissions
): boolean {
  if (!permissions) return true;
  
  // Check explicit permission
  if (permissions.byField[fieldName]) {
    return permissions.byField[fieldName] === 'view';
  }
  
  // Fallback to role default
  return permissions.userRole === 'viewer';
}

/**
 * Helper to filter out hidden fields from an array
 */
export function filterHiddenFields(
  fields: string[],
  permissions?: FieldPermissions
): string[] {
  if (!permissions) return fields;
  
  return fields.filter(field => !isFieldHidden(field, permissions));
}

/**
 * Helper to get the effective permission for a field
 */
export function getFieldPermission(
  fieldName: string,
  permissions?: FieldPermissions
): 'edit' | 'view' | 'hidden' {
  if (!permissions) return 'view';
  
  // Check explicit permission
  if (permissions.byField[fieldName]) {
    return permissions.byField[fieldName];
  }
  
  // Fallback to role default
  if (permissions.userRole === 'admin' || permissions.userRole === 'editor') {
    return 'edit';
  }
  return 'view';
}
