import { Eye, EyeOff, ZoomIn, Table, Settings, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

interface LayerItemProps {
  id: string;
  name: string;
  visible: boolean;
  featureCount: number;
  color: string;
  onToggleVisibility: () => void;
  onZoom: () => void;
  onShowTable: () => void;
  onShowProperties: () => void;
  onRemove: () => void;
  isActive?: boolean;
}

export default function LayerItem({
  name,
  visible,
  featureCount,
  color,
  onToggleVisibility,
  onZoom,
  onShowTable,
  onShowProperties,
  onRemove,
  isActive = false,
}: LayerItemProps) {
  return (
    <div
      className={`p-3 rounded-md bg-card border transition-colors ${
        isActive ? 'border-primary' : 'border-card-border'
      }`}
      data-testid={`layer-${name}`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div
            className="w-4 h-4 rounded-sm flex-shrink-0"
            style={{ backgroundColor: color }}
          />
          <span className="text-sm font-medium truncate">{name}</span>
        </div>
        <Switch
          checked={visible}
          onCheckedChange={onToggleVisibility}
          data-testid={`toggle-visibility-${name}`}
        />
      </div>
      
      <div className="flex items-center gap-1 mb-2">
        <Badge variant="secondary" className="text-xs">
          {featureCount} features
        </Badge>
      </div>
      
      <div className="grid grid-cols-4 gap-1">
        <Button
          size="sm"
          variant="outline"
          onClick={onZoom}
          className="text-xs h-7"
          data-testid={`button-zoom-${name}`}
        >
          <ZoomIn className="h-3 w-3" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onShowTable}
          className="text-xs h-7"
          data-testid={`button-table-${name}`}
        >
          <Table className="h-3 w-3" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onShowProperties}
          className="text-xs h-7"
          data-testid={`button-properties-${name}`}
        >
          <Settings className="h-3 w-3" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onRemove}
          className="text-xs h-7"
          data-testid={`button-remove-${name}`}
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
