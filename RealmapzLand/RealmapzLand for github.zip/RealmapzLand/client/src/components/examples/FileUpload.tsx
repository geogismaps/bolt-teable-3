import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  return (
    <FileUpload
      onFileSelect={(file) => console.log('File selected:', file.name)}
      acceptedTypes=".geojson,.json,.shp"
      title="Upload GeoJSON/Shapefile"
      description="Drag and drop or click to select"
    />
  );
}
