import PermissionMatrix from '../PermissionMatrix';

export default function PermissionMatrixExample() {
  const samplePermissions = [
    {
      userId: '1',
      userName: 'Admin User',
      role: 'admin' as const,
      sheetAccess: ['Parcels', 'Owners', 'Documents'],
      columnPermissions: {
        'Parcel ID': 'edit' as const,
        'Owner Name': 'edit' as const,
        'Area': 'edit' as const,
        'Status': 'edit' as const,
        'Documents': 'edit' as const,
      },
    },
    {
      userId: '2',
      userName: 'Editor User',
      role: 'editor' as const,
      sheetAccess: ['Parcels', 'Owners'],
      columnPermissions: {
        'Parcel ID': 'view' as const,
        'Owner Name': 'edit' as const,
        'Area': 'edit' as const,
        'Status': 'edit' as const,
        'Documents': 'view' as const,
      },
    },
    {
      userId: '3',
      userName: 'Client User',
      role: 'client' as const,
      sheetAccess: ['Parcels'],
      columnPermissions: {
        'Parcel ID': 'view' as const,
        'Owner Name': 'view' as const,
        'Area': 'view' as const,
        'Status': 'hidden' as const,
        'Documents': 'hidden' as const,
      },
    },
  ];

  return (
    <PermissionMatrix
      permissions={samplePermissions}
      columns={['Parcel ID', 'Owner Name', 'Area', 'Status', 'Documents']}
    />
  );
}
