import MapView from '../MapView';
import type { FeatureCollection } from 'geojson';

export default function MapViewExample() {
  const sampleLayers = [
    {
      id: 'parcels',
      name: 'Land Parcels',
      visible: true,
      color: '#3b82f6',
      data: {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: { id: 'P001', owner: 'John Smith', area: '2.5 acres' },
            geometry: {
              type: 'Polygon',
              coordinates: [[
                [-74.006, 40.7128],
                [-74.005, 40.7128],
                [-74.005, 40.7138],
                [-74.006, 40.7138],
                [-74.006, 40.7128],
              ]],
            },
          },
          {
            type: 'Feature',
            properties: { id: 'P002', owner: 'Jane Doe', area: '1.8 acres' },
            geometry: {
              type: 'Polygon',
              coordinates: [[
                [-74.005, 40.7128],
                [-74.004, 40.7128],
                [-74.004, 40.7138],
                [-74.005, 40.7138],
                [-74.005, 40.7128],
              ]],
            },
          },
        ],
      } as FeatureCollection,
    },
    {
      id: 'boundaries',
      name: 'District Boundaries',
      visible: true,
      color: '#ef4444',
      data: {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: { district: 'North District' },
            geometry: {
              type: 'Polygon',
              coordinates: [[
                [-74.007, 40.7125],
                [-74.003, 40.7125],
                [-74.003, 40.7145],
                [-74.007, 40.7145],
                [-74.007, 40.7125],
              ]],
            },
          },
        ],
      } as FeatureCollection,
    },
  ];

  return (
    <MapView
      layers={sampleLayers}
      onFeatureClick={(feature) => console.log('Feature clicked:', feature)}
    />
  );
}
