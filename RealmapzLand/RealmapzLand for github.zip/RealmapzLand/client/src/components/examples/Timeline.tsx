import Timeline from '../Timeline';

export default function TimelineExample() {
  const sampleEvents = [
    {
      id: '1',
      date: new Date(2024, 0, 15),
      type: 'ownership' as const,
      title: 'Ownership Transfer',
      description: 'Property transferred from John Smith to Jane Doe',
      owner: 'Jane Doe',
    },
    {
      id: '2',
      date: new Date(2023, 8, 22),
      type: 'document' as const,
      title: 'Survey Report Filed',
      description: 'Official land survey completed and documented',
      documentId: 'doc-123',
    },
    {
      id: '3',
      date: new Date(2023, 3, 10),
      type: 'survey' as const,
      title: 'Property Survey',
      description: 'Boundary survey conducted by certified surveyor',
    },
    {
      id: '4',
      date: new Date(2022, 11, 5),
      type: 'ownership' as const,
      title: 'Original Purchase',
      description: 'Property purchased by John Smith',
      owner: 'John Smith',
    },
  ];

  return (
    <Timeline
      events={sampleEvents}
      onEventClick={(event) => console.log('Event clicked:', event)}
    />
  );
}
