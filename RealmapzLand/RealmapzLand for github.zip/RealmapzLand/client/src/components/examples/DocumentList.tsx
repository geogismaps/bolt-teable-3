import DocumentList from '../DocumentList';

export default function DocumentListExample() {
  const sampleDocuments = [
    {
      id: 'doc1',
      name: 'Property_Deed_2023.pdf',
      type: 'pdf' as const,
      size: '2.4 MB',
      uploadedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      uploadedBy: 'John Smith',
      parcelId: 'P001',
    },
    {
      id: 'doc2',
      name: 'Survey_Report_Final.pdf',
      type: 'pdf' as const,
      size: '5.1 MB',
      uploadedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      uploadedBy: 'Jane Doe',
      parcelId: 'P002',
    },
    {
      id: 'doc3',
      name: 'Aerial_Photo_2024.jpg',
      type: 'image' as const,
      size: '8.7 MB',
      uploadedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      uploadedBy: 'Admin',
    },
  ];

  return (
    <DocumentList
      documents={sampleDocuments}
      onView={(doc) => console.log('View document:', doc)}
      onDownload={(doc) => console.log('Download document:', doc)}
    />
  );
}
