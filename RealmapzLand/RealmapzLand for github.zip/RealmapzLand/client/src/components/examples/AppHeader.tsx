import AppHeader from '../AppHeader';

export default function AppHeaderExample() {
  return (
    <AppHeader
      userName="John Smith"
      userRole="admin"
      onLogout={() => console.log('Logout clicked')}
      onSettings={() => console.log('Settings clicked')}
    />
  );
}
