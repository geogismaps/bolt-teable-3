import LayerItem from '../LayerItem';

export default function LayerItemExample() {
  return (
    <div className="space-y-4">
      <LayerItem
        id="1"
        name="Land Parcels"
        visible={true}
        featureCount={125}
        color="#3b82f6"
        onToggleVisibility={() => console.log('Toggle visibility')}
        onZoom={() => console.log('Zoom to layer')}
        onShowTable={() => console.log('Show table')}
        onShowProperties={() => console.log('Show properties')}
        onRemove={() => console.log('Remove layer')}
        isActive={true}
      />
      <LayerItem
        id="2"
        name="District Boundaries"
        visible={false}
        featureCount={8}
        color="#ef4444"
        onToggleVisibility={() => console.log('Toggle visibility')}
        onZoom={() => console.log('Zoom to layer')}
        onShowTable={() => console.log('Show table')}
        onShowProperties={() => console.log('Show properties')}
        onRemove={() => console.log('Remove layer')}
      />
    </div>
  );
}
