import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Copy, Check, Share2, Eye } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface ShareMapModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  layerId: string;
  layerName: string;
}

interface ShareData {
  id: string;
  shareToken: string;
  layerId: string;
  createdByUserId: string;
  expiresAt: string | null; // ISO datetime string
  embedEnabled: boolean;
  viewCount: number;
  createdAt: string; // ISO datetime string
  updatedAt: string; // ISO datetime string
}

export default function ShareMapModal({ open, onOpenChange, layerId, layerName }: ShareMapModalProps) {
  const { toast } = useToast();
  const [expirationDays, setExpirationDays] = useState<string>('');
  const [embedEnabled, setEmbedEnabled] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  // Fetch existing shares for this layer
  const sharesQuery = useQuery<ShareData[]>({
    queryKey: ['/api/share/layer', layerId],
    queryFn: async () => {
      const response = await fetch(`/api/share/layer/${layerId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch shares');
      }
      return response.json();
    },
    enabled: open,
  });

  // Get the most recent active (unexpired) share
  const activeShare = sharesQuery.data
    ?.filter(share => {
      // Keep only unexpired shares
      if (!share.expiresAt) return true;
      return new Date(share.expiresAt) > new Date();
    })
    .sort((a, b) => {
      // Sort by createdAt descending (newest first)
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA;
    })[0]; // Take the newest one

  // Create new share
  const createShareMutation = useMutation({
    mutationFn: async () => {
      const expiresAt = expirationDays 
        ? new Date(Date.now() + parseInt(expirationDays) * 24 * 60 * 60 * 1000).toISOString()
        : null;

      return apiRequest('POST', '/api/share/create', {
        layerId,
        expiresAt,
        embedEnabled,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/share/layer', layerId] });
      toast({
        title: 'Share Created',
        description: 'Your shareable link has been generated',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create share',
        variant: 'destructive',
      });
    },
  });

  // Update share
  const updateShareMutation = useMutation({
    mutationFn: async (data: { embedEnabled: boolean }) => {
      if (!activeShare) return;
      return apiRequest('PATCH', `/api/share/${activeShare.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/share/layer', layerId] });
      toast({
        title: 'Share Updated',
        description: 'Share settings have been updated',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update share',
        variant: 'destructive',
      });
    },
  });

  // Revoke share
  const revokeShareMutation = useMutation({
    mutationFn: async () => {
      if (!activeShare) return;
      return apiRequest('DELETE', `/api/share/${activeShare.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/share/layer', layerId] });
      toast({
        title: 'Share Revoked',
        description: 'The share link has been revoked',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to revoke share',
        variant: 'destructive',
      });
    },
  });

  // Generate share link URL
  const shareUrl = activeShare 
    ? `${window.location.origin}/share/${activeShare.shareToken}`
    : '';

  // Generate embed code
  const embedCode = activeShare && activeShare.embedEnabled
    ? `<iframe src="${shareUrl}" width="100%" height="600" frameborder="0"></iframe>`
    : '';

  // Copy to clipboard
  const copyToClipboard = async (text: string, type: 'link' | 'embed') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'link') {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
      } else {
        setCopiedEmbed(true);
        setTimeout(() => setCopiedEmbed(false), 2000);
      }
      toast({
        title: 'Copied',
        description: `${type === 'link' ? 'Link' : 'Embed code'} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to copy to clipboard',
        variant: 'destructive',
      });
    }
  };

  // Reset copied states when modal closes
  useEffect(() => {
    if (!open) {
      setCopiedLink(false);
      setCopiedEmbed(false);
    }
  }, [open]);

  // Update embed enabled state when active share changes
  useEffect(() => {
    if (activeShare) {
      setEmbedEnabled(activeShare.embedEnabled);
    }
  }, [activeShare]);

  const isLoading = sharesQuery.isLoading || createShareMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" data-testid="dialog-share-map">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Share Map: {layerName}
          </DialogTitle>
          <DialogDescription>
            Create a shareable link to this map layer. Anyone with the link can view the data.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {activeShare ? (
            <>
              {/* Share Link */}
              <div className="space-y-2">
                <Label>Share Link</Label>
                <div className="flex gap-2">
                  <Input
                    value={shareUrl}
                    readOnly
                    className="flex-1"
                    data-testid="input-share-url"
                  />
                  <Button
                    onClick={() => copyToClipboard(shareUrl, 'link')}
                    variant="outline"
                    size="icon"
                    data-testid="button-copy-link"
                  >
                    {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {/* View Count */}
              <div className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="text-view-count">
                <Eye className="w-4 h-4" />
                <span>{activeShare.viewCount} views</span>
              </div>

              {/* Expiration */}
              {activeShare.expiresAt && (
                <div className="text-sm text-muted-foreground" data-testid="text-expires-at">
                  Expires: {new Date(activeShare.expiresAt).toLocaleDateString()}
                </div>
              )}

              {/* Embed Settings */}
              <div className="space-y-4 p-4 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="embed-enabled">Enable Embedding</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow this map to be embedded in other websites
                    </p>
                  </div>
                  <Switch
                    id="embed-enabled"
                    checked={embedEnabled}
                    onCheckedChange={(checked) => {
                      setEmbedEnabled(checked);
                      updateShareMutation.mutate({ embedEnabled: checked });
                    }}
                    data-testid="switch-embed-enabled"
                  />
                </div>

                {embedEnabled && (
                  <div className="space-y-2">
                    <Label>Embed Code</Label>
                    <div className="relative">
                      <pre className="p-3 bg-muted rounded text-xs overflow-x-auto" data-testid="code-embed">
                        {embedCode}
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(embedCode, 'embed')}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                        data-testid="button-copy-embed"
                      >
                        {copiedEmbed ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Revoke Button */}
              <Button
                onClick={() => {
                  if (confirm('Are you sure you want to revoke this share link? It will no longer be accessible.')) {
                    revokeShareMutation.mutate();
                  }
                }}
                variant="destructive"
                disabled={revokeShareMutation.isPending}
                data-testid="button-revoke-share"
              >
                Revoke Share Link
              </Button>
            </>
          ) : (
            <>
              {/* Create New Share */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="expiration-days">Expiration (Optional)</Label>
                  <Input
                    id="expiration-days"
                    type="number"
                    placeholder="Number of days (leave empty for no expiration)"
                    value={expirationDays}
                    onChange={(e) => setExpirationDays(e.target.value)}
                    min="1"
                    data-testid="input-expiration-days"
                  />
                  <p className="text-sm text-muted-foreground">
                    Leave empty for a permanent share link
                  </p>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label htmlFor="initial-embed">Enable Embedding</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow this map to be embedded in other websites
                    </p>
                  </div>
                  <Switch
                    id="initial-embed"
                    checked={embedEnabled}
                    onCheckedChange={setEmbedEnabled}
                    data-testid="switch-initial-embed"
                  />
                </div>

                <Button
                  onClick={() => createShareMutation.mutate()}
                  disabled={isLoading}
                  className="w-full"
                  data-testid="button-create-share"
                >
                  {isLoading ? 'Creating...' : 'Create Share Link'}
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
