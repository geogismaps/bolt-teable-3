import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileJson } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  acceptedTypes?: string;
  title?: string;
  description?: string;
}

export default function FileUpload({
  onFileSelect,
  acceptedTypes = '.geojson,.json,.shp',
  title = 'Upload GeoJSON/Shapefile',
  description = 'Drag and drop or click to select',
}: FileUploadProps) {
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles.length > 0) {
        onFileSelect(acceptedFiles[0]);
      }
    },
    [onFileSelect]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/json': ['.json', '.geojson'],
      'application/octet-stream': ['.shp'],
    },
    multiple: false,
  });

  return (
    <Card
      {...getRootProps()}
      className={`p-8 border-2 border-dashed cursor-pointer transition-colors ${
        isDragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/20'
      }`}
      data-testid="file-upload"
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-3 text-center">
        {isDragActive ? (
          <FileJson className="h-12 w-12 text-primary" />
        ) : (
          <Upload className="h-12 w-12 text-muted-foreground" />
        )}
        <div>
          <p className="text-sm font-medium">{title}</p>
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
          <p className="text-xs text-muted-foreground mt-2">
            Supported: {acceptedTypes}
          </p>
        </div>
      </div>
    </Card>
  );
}
