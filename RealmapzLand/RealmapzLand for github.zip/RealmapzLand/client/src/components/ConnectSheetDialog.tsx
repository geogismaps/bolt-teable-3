import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, FileSpreadsheet, ExternalLink, Search } from 'lucide-react';

interface ConnectSheetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pendingConnectionId?: string | null;
  onConnectionComplete?: () => void;
}

interface Spreadsheet {
  id: string;
  name: string;
  modifiedTime: string;
  webViewLink: string;
  thumbnailLink?: string;
  iconLink?: string;
}

export default function ConnectSheetDialog({ open, onOpenChange, pendingConnectionId, onConnectionComplete }: ConnectSheetDialogProps) {
  const [selectedSpreadsheetId, setSelectedSpreadsheetId] = useState('');
  const [customName, setCustomName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showManualInput, setShowManualInput] = useState(false);
  const [manualSpreadsheetUrl, setManualSpreadsheetUrl] = useState('');

  // Fetch spreadsheets list when dialog opens with pendingConnectionId
  const { data: spreadsheets = [], isLoading: loadingSpreadsheets, error: spreadsheetsError } = useQuery<Spreadsheet[]>({
    queryKey: ['/api/connections', pendingConnectionId, 'spreadsheets'],
    enabled: !!pendingConnectionId && open,
    queryFn: async () => {
      console.log('Fetching spreadsheets for connection:', pendingConnectionId);
      const response = await fetch(`/api/connections/${pendingConnectionId}/spreadsheets`);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Failed to fetch spreadsheets:', response.status, errorText);
        throw new Error('Failed to fetch spreadsheets');
      }
      const data = await response.json();
      console.log('Spreadsheets loaded:', data.length, 'items');
      return data;
    },
  });
  
  // Log state for debugging
  useEffect(() => {
    if (open) {
      console.log('ConnectSheetDialog opened:', {
        pendingConnectionId,
        spreadsheetsCount: spreadsheets.length,
        loading: loadingSpreadsheets,
        error: spreadsheetsError,
        showManualInput
      });
    }
  }, [open, pendingConnectionId, spreadsheets.length, loadingSpreadsheets, spreadsheetsError, showManualInput]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setSelectedSpreadsheetId('');
      setCustomName('');
      setShowManualInput(false);
      setManualSpreadsheetUrl('');
      setSearchQuery('');
    }
  }, [open]);

  // Extract spreadsheet ID from URL
  const extractSpreadsheetId = (url: string): string | null => {
    const urlMatch = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (urlMatch) {
      return urlMatch[1];
    }
    if (url.match(/^[a-zA-Z0-9-_]+$/)) {
      return url;
    }
    return null;
  };

  // Filter spreadsheets based on search query
  const filteredSpreadsheets = spreadsheets.filter(sheet =>
    sheet.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Complete pending connection mutation
  const completeConnection = useMutation({
    mutationFn: async () => {
      let spreadsheetId: string | null;
      let spreadsheetName: string;

      if (showManualInput) {
        spreadsheetId = extractSpreadsheetId(manualSpreadsheetUrl);
        if (!spreadsheetId) {
          throw new Error('Invalid spreadsheet URL or ID');
        }
        spreadsheetName = customName || `Spreadsheet ${spreadsheetId.substring(0, 8)}`;
      } else {
        if (!selectedSpreadsheetId) {
          throw new Error('Please select a spreadsheet');
        }
        const selected = spreadsheets.find(s => s.id === selectedSpreadsheetId);
        spreadsheetId = selectedSpreadsheetId;
        spreadsheetName = customName || selected?.name || `Spreadsheet ${spreadsheetId.substring(0, 8)}`;
      }

      if (!pendingConnectionId) {
        throw new Error('No pending connection. Please authenticate first.');
      }

      return apiRequest('PATCH', `/api/connections/${pendingConnectionId}/complete`, {
        spreadsheetId,
        spreadsheetName,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/connections'] });
      onOpenChange(false);
      // Trigger callback to open Add Layer modal
      onConnectionComplete?.();
    },
    onError: (error: any) => {
      alert(`Failed to connect spreadsheet: ${error.message}`);
    },
  });

  const handleSubmit = () => {
    completeConnection.mutate();
  };

  const selectedSpreadsheet = spreadsheets.find(s => s.id === selectedSpreadsheetId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <DialogTitle className="text-xl">Select a file</DialogTitle>
        </DialogHeader>

        {!pendingConnectionId ? (
          <div className="px-6 py-8">
            <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-md p-4">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                ⚠️ Please click "Connect Google Sheets" first to authenticate
              </p>
            </div>
          </div>
        ) : loadingSpreadsheets ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-3 text-muted-foreground">Loading your spreadsheets...</span>
          </div>
        ) : showManualInput ? (
          <div className="px-6 py-6">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="manualUrl">Spreadsheet URL or ID</Label>
                <Input
                  id="manualUrl"
                  value={manualSpreadsheetUrl}
                  onChange={(e) => setManualSpreadsheetUrl(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  data-testid="input-manual-spreadsheet-url"
                />
                <p className="text-xs text-muted-foreground">
                  Paste the full URL from your browser or just the spreadsheet ID
                </p>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="customName">Display Name (optional)</Label>
                <Input
                  id="customName"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="My Land Parcels"
                  data-testid="input-custom-name"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => setShowManualInput(false)}
                className="w-full"
              >
                ← Back to Picker
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-[600px]">
            <Tabs defaultValue="spreadsheets" className="flex-1 flex flex-col">
              <div className="px-6 pt-4">
                <TabsList className="grid w-full grid-cols-2 max-w-[400px]">
                  <TabsTrigger value="spreadsheets">Spreadsheets</TabsTrigger>
                  <TabsTrigger value="drive" disabled>Google Drive</TabsTrigger>
                </TabsList>

                {/* Search Bar */}
                <div className="mt-4 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search spreadsheets"
                    className="pl-10"
                    data-testid="input-search-spreadsheets"
                  />
                </div>
              </div>

              <TabsContent value="spreadsheets" className="flex-1 mt-4 px-6">
                {filteredSpreadsheets.length === 0 ? (
                  <div className="text-center py-12">
                    <FileSpreadsheet className="h-16 w-16 mx-auto mb-4 opacity-30" />
                    <p className="text-muted-foreground mb-4">
                      {searchQuery ? 'No spreadsheets match your search' : 'No spreadsheets found in your Google Drive'}
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => setShowManualInput(true)}
                      size="sm"
                    >
                      Enter spreadsheet URL manually
                    </Button>
                  </div>
                ) : (
                  <>
                    <p className="text-sm text-muted-foreground mb-4">Files</p>
                    <ScrollArea className="h-[400px]">
                      <div className="grid grid-cols-4 gap-3 pb-4">
                        {filteredSpreadsheets.map((sheet) => (
                          <div
                            key={sheet.id}
                            onClick={() => setSelectedSpreadsheetId(sheet.id)}
                            className={`
                              relative rounded-lg border-2 p-3 cursor-pointer transition-all
                              hover:shadow-md
                              ${selectedSpreadsheetId === sheet.id
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20'
                                : 'border-border hover:border-blue-300'
                              }
                            `}
                            data-testid={`spreadsheet-card-${sheet.id}`}
                          >
                            {/* Thumbnail */}
                            <div className="aspect-[4/3] mb-2 bg-gray-100 dark:bg-gray-800 rounded overflow-hidden flex items-center justify-center">
                              {sheet.thumbnailLink ? (
                                <img
                                  src={sheet.thumbnailLink}
                                  alt={sheet.name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    // Fallback to icon if thumbnail fails
                                    e.currentTarget.style.display = 'none';
                                  }}
                                />
                              ) : (
                                <FileSpreadsheet className="h-12 w-12 text-green-600" />
                              )}
                            </div>

                            {/* Sheet Info */}
                            <div className="flex items-start gap-2">
                              <FileSpreadsheet className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate" title={sheet.name}>
                                  {sheet.name}
                                </p>
                              </div>
                            </div>

                            {/* External Link */}
                            {sheet.webViewLink && (
                              <a
                                href={sheet.webViewLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="absolute top-2 right-2 p-1 rounded bg-white dark:bg-gray-800 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700"
                              >
                                <ExternalLink className="w-3 h-3 text-gray-600 dark:text-gray-400" />
                              </a>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>

                    <div className="mt-4 text-center">
                      <Button
                        variant="ghost"
                        onClick={() => setShowManualInput(true)}
                        size="sm"
                      >
                        Can't find your spreadsheet? Enter URL manually
                      </Button>
                    </div>
                  </>
                )}
              </TabsContent>
            </Tabs>

            {/* Optional Custom Name */}
            {selectedSpreadsheet && !showManualInput && (
              <div className="px-6 pt-4 border-t">
                <div className="grid gap-2">
                  <Label htmlFor="customName" className="text-sm">
                    Custom name (optional)
                  </Label>
                  <Input
                    id="customName"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder={selectedSpreadsheet.name}
                    data-testid="input-custom-name"
                    size-sm
                  />
                </div>
              </div>
            )}
          </div>
        )}

        <DialogFooter className="px-6 py-4 border-t bg-gray-50 dark:bg-gray-900/50">
          <div className="flex items-center justify-between w-full">
            <div className="flex-1">
              {selectedSpreadsheet && !showManualInput && (
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">{selectedSpreadsheet.name}</span> selected
                </p>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={
                  !pendingConnectionId || 
                  completeConnection.isPending ||
                  (!showManualInput && !selectedSpreadsheetId) ||
                  (showManualInput && !manualSpreadsheetUrl.trim())
                }
                data-testid="button-connect-spreadsheet"
                className={selectedSpreadsheetId ? 'animate-pulse' : ''}
              >
                {completeConnection.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {completeConnection.isPending ? 'Connecting...' : 'Select'}
              </Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
