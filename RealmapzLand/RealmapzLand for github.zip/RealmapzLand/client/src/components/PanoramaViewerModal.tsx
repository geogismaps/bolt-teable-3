import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, X, AlertCircle } from "lucide-react";
import { getViewerUrl } from "@/lib/contentTypeDetection";

interface PanoramaViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  panoramaUrl: string;
  title?: string;
}

export function PanoramaViewerModal({ isOpen, onClose, panoramaUrl, title }: PanoramaViewerModalProps) {
  const [viewerError, setViewerError] = useState(false);
  const panoramaContainerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);

  const viewUrl = getViewerUrl(panoramaUrl, 'panorama');

  // Initialize Pannellum viewer
  useEffect(() => {
    if (!isOpen || !panoramaContainerRef.current) {
      // Clean up previous viewer
      if (viewerRef.current) {
        try {
          viewerRef.current.destroy();
        } catch (e) {
          console.warn("Error destroying Pannellum viewer:", e);
        }
        viewerRef.current = null;
      }
      setViewerError(false);
      return;
    }

    const initPannellum = async () => {
      try {
        // Dynamically import pannellum
        const pannellum = (window as any).pannellum;
        
        if (!pannellum) {
          throw new Error("Pannellum library not loaded");
        }
        
        // Destroy any existing viewer
        if (viewerRef.current) {
          try {
            viewerRef.current.destroy();
          } catch (e) {
            console.warn("Error destroying previous viewer:", e);
          }
        }

        // Create new viewer
        viewerRef.current = pannellum.viewer(panoramaContainerRef.current!, {
          type: "equirectangular",
          panorama: viewUrl,
          autoLoad: true,
          showControls: true,
          showFullscreenCtrl: true,
          showZoomCtrl: true,
          mouseZoom: true,
          draggable: true,
          keyboardZoom: true,
          compass: false,
          hotSpotDebug: false,
        });

        setViewerError(false);
      } catch (error) {
        console.error("Failed to initialize Pannellum viewer:", error);
        setViewerError(true);
      }
    };

    initPannellum();

    return () => {
      if (viewerRef.current) {
        try {
          viewerRef.current.destroy();
        } catch (e) {
          console.warn("Error destroying viewer on cleanup:", e);
        }
        viewerRef.current = null;
      }
    };
  }, [isOpen, viewUrl]);

  const handleOpenInNewTab = () => {
    window.open(panoramaUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] p-0">
        <DialogHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle data-testid="text-panorama-viewer-title">
              {title || "360° Panorama Viewer"}
            </DialogTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleOpenInNewTab}
                data-testid="button-open-panorama-new-tab"
                title="Open in new tab"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={onClose}
                data-testid="button-close-panorama-viewer"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* 360 Panorama Container */}
        <div className="relative h-[70vh] bg-muted">
          {viewerError ? (
            <div className="flex flex-col items-center justify-center h-full gap-4">
              <AlertCircle className="w-12 h-12 text-muted-foreground" />
              <p className="text-muted-foreground">Failed to load 360° panorama</p>
              <Button 
                onClick={handleOpenInNewTab}
                data-testid="button-open-failed-panorama"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in New Tab
              </Button>
            </div>
          ) : (
            <div 
              ref={panoramaContainerRef} 
              className="w-full h-full"
              data-testid="container-panorama-viewer"
            />
          )}
        </div>

        {/* Footer with controls hint */}
        <div className="p-3 border-t bg-muted/30 text-xs text-muted-foreground text-center">
          Click and drag to look around • Scroll to zoom • F for fullscreen
        </div>
      </DialogContent>
    </Dialog>
  );
}
