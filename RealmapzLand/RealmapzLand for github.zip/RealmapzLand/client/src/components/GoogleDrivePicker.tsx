import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

declare global {
  interface Window {
    gapi: any;
    google: any;
  }
}

interface PickerResult {
  id: string;
  name: string;
  mimeType: string;
}

interface GoogleDrivePickerProps {
  onSheetsPicked: (sheets: PickerResult[]) => void;
  disabled?: boolean;
  autoOpen?: boolean;
  accessToken?: string;
  onAutoOpenHandled?: () => void;
}

export function GoogleDrivePicker({ 
  onSheetsPicked, 
  disabled, 
  autoOpen, 
  accessToken,
  onAutoOpenHandled 
}: GoogleDrivePickerProps) {
  const [pickerApiLoaded, setPickerApiLoaded] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!window.gapi) {
      console.error('Google API not loaded');
      return;
    }

    window.gapi.load('picker', () => {
      setPickerApiLoaded(true);
    });
  }, []);

  // Auto-open picker after OAuth success
  useEffect(() => {
    if (autoOpen && accessToken && pickerApiLoaded && !loading) {
      console.log('Auto-opening Google Drive Picker with access token');
      showPicker(accessToken);
      onAutoOpenHandled?.();
    }
  }, [autoOpen, accessToken, pickerApiLoaded, loading]);

  const openPicker = async () => {
    if (!pickerApiLoaded) {
      console.error('Picker API not loaded yet');
      return;
    }

    // If we already have a valid accessToken, just open the picker directly!
    if (accessToken) {
      console.log('Using existing access token to open picker');
      showPicker(accessToken);
      return;
    }

    // Otherwise, start OAuth flow
    setLoading(true);

    try {
      const response = await fetch('/api/auth/google');
      const data = await response.json();

      if (!data.authUrl) {
        throw new Error('Failed to get auth URL');
      }

      const authWindow = window.open(data.authUrl, '_blank', 'width=600,height=600');
      
      const checkAuth = setInterval(async () => {
        try {
          if (authWindow?.closed) {
            clearInterval(checkAuth);
            setLoading(false);
            
            const statusResponse = await fetch('/api/oauth/grants');
            const statusData = await statusResponse.json();
            
            if (statusData.hasGrant && statusData.accessToken) {
              showPicker(statusData.accessToken);
            }
          }
        } catch (error) {
          console.error('Error checking auth status:', error);
        }
      }, 500);
    } catch (error) {
      console.error('Error initiating OAuth:', error);
      setLoading(false);
    }
  };

  const showPicker = (accessToken: string) => {
    const view = new window.google.picker.DocsView(window.google.picker.ViewId.SPREADSHEETS)
      .setIncludeFolders(true)
      .setSelectFolderEnabled(false);

    const picker = new window.google.picker.PickerBuilder()
      .addView(view)
      .setOAuthToken(accessToken)
      .setDeveloperKey(import.meta.env.VITE_GOOGLE_API_KEY || '')
      .setCallback(pickerCallback)
      .enableFeature(window.google.picker.Feature.MULTISELECT_ENABLED)
      .build();

    picker.setVisible(true);
    setLoading(false);
  };

  const pickerCallback = (data: any) => {
    if (data.action === window.google.picker.Action.PICKED) {
      const selectedDocs: PickerResult[] = data.docs.map((doc: any) => ({
        id: doc.id,
        name: doc.name,
        mimeType: doc.mimeType,
      }));

      const sheets = selectedDocs.filter(doc => 
        doc.mimeType === 'application/vnd.google-apps.spreadsheet'
      );

      if (sheets.length > 0) {
        onSheetsPicked(sheets);
      }
    }
  };

  return (
    <Button
      onClick={openPicker}
      disabled={disabled || !pickerApiLoaded || loading}
      data-testid="button-open-drive-picker"
    >
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Authenticating...
        </>
      ) : (
        'Add from Google Drive'
      )}
    </Button>
  );
}
