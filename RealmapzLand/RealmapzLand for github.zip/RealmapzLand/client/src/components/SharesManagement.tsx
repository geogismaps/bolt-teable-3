import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Share2, Trash2, Eye, Calendar, Copy, ExternalLink, Edit } from "lucide-react";
import { format } from "date-fns";
import EditShareModal from "@/components/EditShareModal";

interface ShareData {
  id: string;
  shareToken: string;
  layerId: string;
  layerName: string;
  createdByUserId: string;
  expiresAt: string | null;
  embedEnabled: boolean;
  viewCount: number;
  createdAt: string;
  updatedAt: string;
}

export default function SharesManagement() {
  const { toast } = useToast();
  const [selectedShares, setSelectedShares] = useState<Set<string>>(new Set());
  const [editingShare, setEditingShare] = useState<ShareData | null>(null);

  // Fetch all shares for the organization
  const sharesQuery = useQuery<ShareData[]>({
    queryKey: ['/api/share/organization'],
    queryFn: async () => {
      const response = await fetch('/api/share/organization');
      if (!response.ok) throw new Error('Failed to fetch shares');
      return response.json();
    },
  });

  // Revoke share mutation
  const revokeShareMutation = useMutation({
    mutationFn: async (shareId: string) => {
      const response = await apiRequest('DELETE', `/api/share/${shareId}`);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to revoke share');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/share/organization'] });
      toast({
        title: 'Share revoked',
        description: 'The share link has been revoked successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const handleCopyLink = (token: string) => {
    const shareUrl = `${window.location.origin}/share/${token}`;
    navigator.clipboard.writeText(shareUrl);
    toast({
      title: 'Link copied',
      description: 'Share link copied to clipboard',
    });
  };

  const handleRevoke = (shareId: string, layerName: string) => {
    if (confirm(`Revoke share for "${layerName}"?`)) {
      revokeShareMutation.mutate(shareId);
    }
  };

  const handleBulkRevoke = () => {
    if (selectedShares.size === 0) return;
    if (confirm(`Revoke ${selectedShares.size} selected ${selectedShares.size === 1 ? 'share' : 'shares'}?`)) {
      selectedShares.forEach(shareId => {
        revokeShareMutation.mutate(shareId);
      });
      setSelectedShares(new Set());
    }
  };

  const toggleShareSelection = (shareId: string) => {
    const newSelection = new Set(selectedShares);
    if (newSelection.has(shareId)) {
      newSelection.delete(shareId);
    } else {
      newSelection.add(shareId);
    }
    setSelectedShares(newSelection);
  };

  const toggleSelectAll = () => {
    if (selectedShares.size === shares.length) {
      setSelectedShares(new Set());
    } else {
      setSelectedShares(new Set(shares.map(s => s.id)));
    }
  };

  if (sharesQuery.isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">Loading shares...</p>
        </CardContent>
      </Card>
    );
  }

  if (sharesQuery.isError) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-destructive">Failed to load shares</p>
        </CardContent>
      </Card>
    );
  }

  const shares = sharesQuery.data || [];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Share2 className="w-5 h-5" />
          <CardTitle>Share Management</CardTitle>
        </div>
        <CardDescription className="flex items-center justify-between">
          <span>Manage shared map links for your organization ({shares.length} {shares.length === 1 ? 'share' : 'shares'})</span>
          {shares.length > 0 && selectedShares.size > 0 && (
            <Button
              size="sm"
              variant="destructive"
              onClick={handleBulkRevoke}
              disabled={revokeShareMutation.isPending}
              data-testid="button-bulk-revoke"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Revoke Selected ({selectedShares.size})
            </Button>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {shares.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No shared maps yet. Share a layer from the map page to create a public link.
          </p>
        ) : (
          <div className="space-y-4">
            {shares.length > 1 && (
              <div className="flex items-center gap-2 pb-2 border-b">
                <Checkbox
                  checked={selectedShares.size === shares.length && shares.length > 0}
                  onCheckedChange={toggleSelectAll}
                  data-testid="checkbox-select-all"
                />
                <span className="text-sm text-muted-foreground">
                  Select All ({selectedShares.size} selected)
                </span>
              </div>
            )}
            {shares.map((share) => {
              const isExpired = share.expiresAt && new Date(share.expiresAt) < new Date();
              const shareUrl = `${window.location.origin}/share/${share.shareToken}`;

              return (
                <div
                  key={share.id}
                  className="border rounded-lg p-4 space-y-3"
                  data-testid={`share-item-${share.id}`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <Checkbox
                        checked={selectedShares.has(share.id)}
                        onCheckedChange={() => toggleShareSelection(share.id)}
                        className="mt-1"
                        data-testid={`checkbox-select-${share.id}`}
                      />
                      <div className="flex-1">
                        <h4 className="font-medium" data-testid={`share-layer-name-${share.id}`}>
                          {share.layerName}
                        </h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          Created {format(new Date(share.createdAt), 'MMM d, yyyy')}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCopyLink(share.shareToken)}
                        data-testid={`button-copy-${share.id}`}
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Link
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(shareUrl, '_blank')}
                        data-testid={`button-open-${share.id}`}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditingShare(share)}
                        data-testid={`button-edit-${share.id}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleRevoke(share.id, share.layerName)}
                        disabled={revokeShareMutation.isPending}
                        data-testid={`button-revoke-${share.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {share.viewCount} {share.viewCount === 1 ? 'view' : 'views'}
                    </Badge>
                    
                    {share.embedEnabled && (
                      <Badge variant="secondary">Embed Enabled</Badge>
                    )}
                    
                    {share.expiresAt && (
                      <Badge
                        variant={isExpired ? "destructive" : "secondary"}
                        className="flex items-center gap-1"
                      >
                        <Calendar className="w-3 h-3" />
                        {isExpired ? 'Expired' : `Expires ${format(new Date(share.expiresAt), 'MMM d')}`}
                      </Badge>
                    )}
                    
                    {!share.expiresAt && (
                      <Badge variant="secondary">No Expiration</Badge>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>

      {/* Edit Share Modal */}
      {editingShare && (
        <EditShareModal
          open={!!editingShare}
          onOpenChange={(open) => !open && setEditingShare(null)}
          share={editingShare}
        />
      )}
    </Card>
  );
}
