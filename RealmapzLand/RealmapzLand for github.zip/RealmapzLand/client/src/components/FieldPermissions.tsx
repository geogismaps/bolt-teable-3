import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Eye, Edit3, EyeOff, Save, RotateCcw } from "lucide-react";

interface User {
  id: string;
  email: string;
  full_name: string | null;
  role: 'admin' | 'editor' | 'viewer';
}

interface FieldPermission {
  id: string;
  user_id: string;
  connection_id: string;
  sheet_name: string;
  column_name: string;
  permission_level: 'view' | 'edit' | 'hidden';
}

interface FieldPermissionsProps {
  organizationId: string;
}

interface PermissionState {
  [key: string]: 'view' | 'edit' | 'hidden' | 'default';
}

export function FieldPermissions({ organizationId }: FieldPermissionsProps) {
  const { toast } = useToast();
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [selectedConnectionId, setSelectedConnectionId] = useState<string>('');
  const [selectedSheetName, setSelectedSheetName] = useState<string>('');
  const [permissionState, setPermissionState] = useState<PermissionState>({});
  const [hasChanges, setHasChanges] = useState(false);

  // Reset sheet selection when connection changes
  useEffect(() => {
    setSelectedSheetName('');
  }, [selectedConnectionId]);

  // Fetch users
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['/api/supabase/organizations', organizationId, 'users'],
    enabled: !!organizationId,
  });

  // Fetch Google Sheet connections
  const { data: allConnections = [] } = useQuery<any[]>({
    queryKey: ['/api/connections'],
  });

  // Deduplicate connections: Keep only the most recent connection per unique spreadsheet
  const connections = allConnections.reduce((acc: any[], conn: any) => {
    const existing = acc.find((c: any) => c.spreadsheetId === conn.spreadsheetId);
    if (!existing) {
      acc.push(conn);
    } else {
      // Keep the most recent connection (highest timestamp)
      const existingDate = new Date(existing.createdAt || 0).getTime();
      const currentDate = new Date(conn.createdAt || 0).getTime();
      if (currentDate > existingDate) {
        const index = acc.indexOf(existing);
        acc[index] = conn;
      }
    }
    return acc;
  }, []);

  // Fetch spreadsheet metadata to get available sheets
  const { data: metadata } = useQuery<any>({
    queryKey: ['/api/connections', selectedConnectionId, 'metadata'],
    enabled: !!selectedConnectionId,
  });

  // Extract sheet names from metadata
  const availableSheets = metadata?.sheets
    ?.map((sheet: any) => sheet.properties?.title)
    .filter((title: any) => title && typeof title === 'string') || [];

  // Fetch sheet data to get actual field names from headers
  const { data: sheetData } = useQuery<any>({
    queryKey: ['/api/connections', selectedConnectionId, 'sheets', selectedSheetName],
    queryFn: async () => {
      const response = await fetch(
        `/api/connections/${selectedConnectionId}/sheets/${encodeURIComponent(selectedSheetName)}`
      );
      if (!response.ok) {
        throw new Error('Failed to fetch sheet data');
      }
      return response.json();
    },
    enabled: !!selectedConnectionId && !!selectedSheetName,
  });

  // Get connection ID for the selected connection
  const selectedConn = connections.find(c => c.id === selectedConnectionId);
  const connectionId = selectedConn?.id;

  // Fetch existing permissions for selected user
  const { data: existingPermissions = [] } = useQuery<FieldPermission[]>({
    queryKey: ['/api/supabase/permissions', selectedUserId, connectionId, selectedSheetName],
    enabled: !!selectedUserId && !!connectionId && !!selectedSheetName,
  });

  // Extract field names from sheet data (first row headers)
  // Only show fields if all three selections are made AND we have data
  const fieldNames = (selectedUserId && selectedConnectionId && selectedSheetName && sheetData?.headers) 
    ? sheetData.headers 
    : [];

  // Initialize permission state when permissions or fields change
  useEffect(() => {
    const newState: PermissionState = {};
    
    fieldNames.forEach((fieldName: string) => {
      const existingPerm = existingPermissions.find(p => p.column_name === fieldName);
      newState[fieldName] = existingPerm ? existingPerm.permission_level : 'default';
    });
    
    setPermissionState(newState);
    setHasChanges(false);
  }, [existingPermissions, fieldNames]);

  // Bulk set permissions mutation
  const bulkSetPermissionsMutation = useMutation({
    mutationFn: async (permissions: { fieldName: string; permissionLevel: 'view' | 'edit' | 'hidden' }[]) => {
      const selectedConn = connections.find(c => c.id === selectedConnectionId);
      if (!selectedConn) {
        throw new Error('Connection not found');
      }
      
      const response = await apiRequest('POST', `/api/supabase/permissions/bulk`, {
        userId: selectedUserId,
        connectionId: selectedConn.id,
        sheetName: selectedSheetName,
        permissions,
      });
      return response.json();
    },
    onSuccess: () => {
      const selectedConn = connections.find(c => c.id === selectedConnectionId);
      queryClient.invalidateQueries({ 
        queryKey: ['/api/supabase/permissions', selectedUserId, selectedConn?.id, selectedSheetName] 
      });
      toast({
        title: "Permissions saved",
        description: "Field permissions have been updated successfully.",
      });
      setHasChanges(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error saving permissions",
        description: error.message || "Failed to save permissions. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete permission mutation
  const deletePermissionMutation = useMutation({
    mutationFn: async (permissionId: string) => {
      const response = await apiRequest('DELETE', `/api/supabase/permissions/${permissionId}`);
      return response.json();
    },
    onSuccess: () => {
      const selectedConn = connections.find(c => c.id === selectedConnectionId);
      queryClient.invalidateQueries({ 
        queryKey: ['/api/supabase/permissions', selectedUserId, selectedConn?.id, selectedSheetName] 
      });
      toast({
        title: "Permission reset",
        description: "Field permission has been reset to role default.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error resetting permission",
        description: error.message || "Failed to reset permission. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePermissionChange = (fieldName: string, level: 'view' | 'edit' | 'hidden' | 'default') => {
    setPermissionState(prev => ({
      ...prev,
      [fieldName]: level,
    }));
    setHasChanges(true);
  };

  const handleSavePermissions = () => {
    const permissionsToSave = Object.entries(permissionState)
      .filter(([_, level]) => level !== 'default')
      .map(([fieldName, level]) => ({
        fieldName,
        permissionLevel: level as 'view' | 'edit' | 'hidden',
      }));

    bulkSetPermissionsMutation.mutate(permissionsToSave);
  };

  const handleResetPermission = (fieldName: string) => {
    const existingPerm = existingPermissions.find(p => p.field_name === fieldName);
    if (existingPerm) {
      deletePermissionMutation.mutate(existingPerm.id);
    }
  };

  const handleBulkSet = (level: 'view' | 'edit' | 'hidden') => {
    const newState: PermissionState = {};
    fieldNames.forEach((fieldName: string) => {
      newState[fieldName] = level;
    });
    setPermissionState(newState);
    setHasChanges(true);
  };

  const selectedUser = users.find(u => u.id === selectedUserId);
  const selectedConnection = connections.find(c => c.id === selectedConnectionId);

  const getPermissionIcon = (level: 'view' | 'edit' | 'hidden' | 'default') => {
    switch (level) {
      case 'edit':
        return <Edit3 className="h-3 w-3" />;
      case 'view':
        return <Eye className="h-3 w-3" />;
      case 'hidden':
        return <EyeOff className="h-3 w-3" />;
      default:
        return null;
    }
  };

  const getDefaultPermissionForRole = (role: User['role']) => {
    switch (role) {
      case 'admin':
      case 'editor':
        return 'edit';
      case 'viewer':
        return 'view';
      default:
        return 'view';
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold">Field-Level Permissions</h2>
        <p className="text-sm text-muted-foreground">
          Control which fields users can view, edit, or hide
        </p>
      </div>

      {/* Selection Controls */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="user-select">Select User</Label>
          <Select value={selectedUserId} onValueChange={setSelectedUserId}>
            <SelectTrigger id="user-select" data-testid="select-permission-user">
              <SelectValue placeholder="Choose a user..." />
            </SelectTrigger>
            <SelectContent>
              {users.map(user => (
                <SelectItem key={user.id} value={user.id}>
                  {user.full_name || user.email} ({user.role})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="connection-select">Select Google Sheet</Label>
          <Select 
            value={selectedConnectionId} 
            onValueChange={setSelectedConnectionId}
            disabled={!selectedUserId}
          >
            <SelectTrigger id="connection-select" data-testid="select-permission-connection">
              <SelectValue placeholder="Choose a sheet..." />
            </SelectTrigger>
            <SelectContent>
              {connections
                .filter(conn => conn.id && conn.id.trim() !== '')
                .map(conn => (
                  <SelectItem key={conn.id} value={conn.id}>
                    {conn.spreadsheetName || conn.spreadsheet_name}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="sheet-select">Select Sheet Tab</Label>
          <Select 
            value={selectedSheetName} 
            onValueChange={setSelectedSheetName}
            disabled={!selectedConnectionId}
          >
            <SelectTrigger id="sheet-select" data-testid="select-permission-sheet">
              <SelectValue placeholder="Choose a tab..." />
            </SelectTrigger>
            <SelectContent>
              {availableSheets.map((sheetName: string) => (
                <SelectItem key={sheetName} value={sheetName}>
                  {sheetName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Permissions Matrix */}
      {selectedUserId && selectedConnectionId && selectedSheetName && (
        <>
          {/* Bulk Actions */}
          <div className="flex items-center gap-2 justify-between border-b pb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Bulk Set:</span>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => handleBulkSet('edit')}
                data-testid="button-bulk-edit"
              >
                <Edit3 className="h-3 w-3 mr-1" />
                All Edit
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => handleBulkSet('view')}
                data-testid="button-bulk-view"
              >
                <Eye className="h-3 w-3 mr-1" />
                All View
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => handleBulkSet('hidden')}
                data-testid="button-bulk-hidden"
              >
                <EyeOff className="h-3 w-3 mr-1" />
                All Hidden
              </Button>
            </div>
            {hasChanges && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Unsaved changes</span>
                <Button 
                  size="sm"
                  onClick={handleSavePermissions}
                  disabled={bulkSetPermissionsMutation.isPending}
                  data-testid="button-save-permissions"
                >
                  <Save className="h-3 w-3 mr-1" />
                  Save All
                </Button>
              </div>
            )}
          </div>

          {fieldNames.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No fields found. Make sure the sheet has data.
            </div>
          ) : (
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Field Name</TableHead>
                    <TableHead>Permission Level</TableHead>
                    <TableHead>Default for Role</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fieldNames.map((fieldName: string) => {
                    const currentLevel = permissionState[fieldName] || 'default';
                    const defaultLevel = selectedUser ? getDefaultPermissionForRole(selectedUser.role) : 'view';
                    const isCustom = currentLevel !== 'default';
                    
                    return (
                      <TableRow key={fieldName} data-testid={`row-field-${fieldName}`}>
                        <TableCell className="font-medium">{fieldName}</TableCell>
                        <TableCell>
                          <Select
                            value={currentLevel}
                            onValueChange={(value) => handlePermissionChange(fieldName, value as any)}
                          >
                            <SelectTrigger className="w-[140px]" data-testid={`select-permission-${fieldName}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="default">
                                Default ({defaultLevel})
                              </SelectItem>
                              <SelectItem value="edit">
                                <div className="flex items-center gap-2">
                                  <Edit3 className="h-3 w-3" />
                                  Edit
                                </div>
                              </SelectItem>
                              <SelectItem value="view">
                                <div className="flex items-center gap-2">
                                  <Eye className="h-3 w-3" />
                                  View
                                </div>
                              </SelectItem>
                              <SelectItem value="hidden">
                                <div className="flex items-center gap-2">
                                  <EyeOff className="h-3 w-3" />
                                  Hidden
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getPermissionIcon(defaultLevel as any)}
                            <span className="ml-1">{defaultLevel}</span>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          {isCustom && (
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleResetPermission(fieldName)}
                              disabled={deletePermissionMutation.isPending}
                              data-testid={`button-reset-${fieldName}`}
                            >
                              <RotateCcw className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      {(!selectedUserId || !selectedConnectionId || !selectedSheetName) && (
        <div className="text-center py-12 text-muted-foreground border rounded-md bg-muted/20">
          <p>Select a user, Google Sheet, and sheet tab to manage field permissions</p>
        </div>
      )}
    </div>
  );
}
