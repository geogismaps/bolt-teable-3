import { cn } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface PageSectionProps {
  title?: string;
  description?: string;
  icon?: LucideIcon;
  children: React.ReactNode;
  className?: string;
  contentClassName?: string;
  asCard?: boolean;
}

/**
 * PageSection - Reusable section container with optional card wrapping
 * 
 * Design Spec:
 * - Section title: text-lg font-semibold
 * - Description: text-sm text-muted-foreground
 * - Spacing: space-y-4 for related content
 * 
 * Usage:
 * <PageSection title="User Management" description="Add and manage users" asCard>
 *   <UserList />
 * </PageSection>
 */
export function PageSection({
  title,
  description,
  icon: Icon,
  children,
  className,
  contentClassName,
  asCard = false,
}: PageSectionProps) {
  if (asCard) {
    return (
      <Card className={className}>
        {(title || description) && (
          <CardHeader>
            {title && (
              <div className="flex items-center gap-2">
                {Icon && <Icon className="h-5 w-5 text-muted-foreground" />}
                <CardTitle>{title}</CardTitle>
              </div>
            )}
            {description && <CardDescription>{description}</CardDescription>}
          </CardHeader>
        )}
        <CardContent className={cn(contentClassName)}>
          {children}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn("space-y-4", className)}>
      {(title || description) && (
        <div>
          {title && (
            <div className="flex items-center gap-2">
              {Icon && <Icon className="h-5 w-5 text-muted-foreground" />}
              <h2 className="text-lg font-semibold">{title}</h2>
            </div>
          )}
          {description && (
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          )}
        </div>
      )}
      <div className={contentClassName}>
        {children}
      </div>
    </div>
  );
}
