import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  description?: string;
  icon?: LucideIcon;
  iconClassName?: string;
  actions?: React.ReactNode;
  className?: string;
  testId?: string;
}

/**
 * PageHeader - Consistent page header with icon, title, description, and optional actions
 * 
 * Design Spec:
 * - Title: text-3xl font-bold tracking-tight
 * - Description: text-muted-foreground
 * - Icon: h-6 w-6 in primary color
 * - Spacing: mb-6 from content below
 * 
 * Usage:
 * <PageHeader 
 *   icon={Shield} 
 *   title="Permissions" 
 *   description="Manage access control"
 *   actions={<Button>Add User</Button>}
 * />
 */
export function PageHeader({
  title,
  description,
  icon: Icon,
  iconClassName,
  actions,
  className,
  testId,
}: PageHeaderProps) {
  return (
    <div className={cn("flex items-start justify-between gap-4", className)}>
      <div className="flex items-start gap-3 flex-1">
        {Icon && (
          <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
            <Icon className={cn("h-6 w-6 text-primary", iconClassName)} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <h1 className="text-3xl font-bold tracking-tight" data-testid={testId}>
            {title}
          </h1>
          {description && (
            <p className="text-muted-foreground mt-1">
              {description}
            </p>
          )}
        </div>
      </div>
      {actions && (
        <div className="flex-shrink-0">
          {actions}
        </div>
      )}
    </div>
  );
}
