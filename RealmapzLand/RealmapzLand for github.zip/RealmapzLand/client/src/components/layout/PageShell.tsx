import { cn } from "@/lib/utils";

interface PageShellProps {
  children: React.ReactNode;
  className?: string;
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "4xl" | "6xl" | "7xl" | "full";
}

/**
 * PageShell - Standard page container with consistent padding and max-width
 * 
 * Usage:
 * - Dashboard pages: maxWidth="7xl" (default)
 * - Form pages: maxWidth="4xl"
 * - Document viewers: maxWidth="full"
 */
export function PageShell({ 
  children, 
  className,
  maxWidth = "7xl" 
}: PageShellProps) {
  const maxWidthClasses = {
    sm: "max-w-sm",
    md: "max-w-md",
    lg: "max-w-lg",
    xl: "max-w-xl",
    "2xl": "max-w-2xl",
    "4xl": "max-w-4xl",
    "6xl": "max-w-6xl",
    "7xl": "max-w-7xl",
    full: "max-w-full",
  };

  return (
    <div className="h-screen w-full overflow-auto bg-background">
      <div className={cn(
        "container mx-auto p-6 space-y-6",
        maxWidthClasses[maxWidth],
        className
      )}>
        {children}
      </div>
    </div>
  );
}
