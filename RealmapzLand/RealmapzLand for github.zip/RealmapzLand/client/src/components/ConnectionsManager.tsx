import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { GoogleDrivePicker } from "./GoogleDrivePicker";
import { useAuth } from "@/contexts/AuthContext";
import { Database, Trash2, Copy, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { useLocation } from "wouter";

interface Connection {
  id: string;
  userId: string;
  spreadsheetId: string;
  spreadsheetName: string;
  grantId: string | null;
  createdAt: string;
}

interface OAuthGrantStatus {
  hasGrant: boolean;
  grantExpiry: string | null;
  isExpired: boolean;
  accessToken?: string;
}

interface PickerResult {
  id: string;
  name: string;
  mimeType: string;
}

export default function ConnectionsManager() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [autoOpenPicker, setAutoOpenPicker] = useState(false);

  const isEditor = user?.user_metadata?.role === 'admin' || user?.user_metadata?.role === 'editor';

  // Detect OAuth success and auto-open picker
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const authSuccess = params.get('auth');
    const grantId = params.get('grantId');

    if (authSuccess === 'success' && grantId) {
      // Show success toast
      toast({
        title: 'Connected to Google',
        description: 'You can now select Google Sheets to add to your workspace.',
      });

      // Clean up URL
      params.delete('auth');
      params.delete('grantId');
      const newSearch = params.toString();
      const newUrl = window.location.pathname + (newSearch ? '?' + newSearch : '');
      window.history.replaceState({}, '', newUrl);

      // Trigger picker to open
      setAutoOpenPicker(true);
    }
  }, [toast]);

  const { data: grantStatus, isLoading: grantLoading } = useQuery<OAuthGrantStatus>({
    queryKey: ['/api/oauth/grants'],
    refetchInterval: 300000,
  });

  const { data: connections, isLoading: connectionsLoading, error: connectionsError } = useQuery<Connection[]>({
    queryKey: ['/api/connections'],
    staleTime: 60000,
  });

  const batchAddMutation = useMutation({
    mutationFn: async (sheets: PickerResult[]) => {
      const response = await apiRequest('POST', '/api/connections/batch-add', { spreadsheets: sheets });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/connections'] });
      toast({
        title: 'Connections added',
        description: `Successfully added ${data.added} connection(s). ${data.skipped} duplicate(s) skipped.`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error adding connections',
        description: error.message,
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (connectionId: string) => {
      const response = await apiRequest('DELETE', `/api/connections/${connectionId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/connections'] });
      toast({
        title: 'Connection deleted',
        description: 'The connection has been removed successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error deleting connection',
        description: error.message,
      });
    },
  });

  const handleSheetsPicked = (sheets: PickerResult[]) => {
    batchAddMutation.mutate(sheets);
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleReconnect = async () => {
    try {
      const response = await fetch('/api/auth/google');
      const data = await response.json();
      
      if (data.authUrl) {
        window.open(data.authUrl, '_blank', 'width=600,height=600');
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to initiate reconnection',
      });
    }
  };

  const renderOAuthStatus = () => {
    if (grantLoading) {
      return <Badge variant="secondary"><Loader2 className="w-3 h-3 animate-spin mr-1" />Loading...</Badge>;
    }

    if (!grantStatus?.hasGrant) {
      return (
        <>
          <Badge variant="destructive" className="mr-2">
            <AlertCircle className="w-3 h-3 mr-1" />
            Not Connected
          </Badge>
          <Button size="sm" variant="outline" onClick={handleReconnect} data-testid="button-reconnect-oauth">
            Reconnect
          </Button>
        </>
      );
    }

    if (grantStatus.isExpired) {
      return (
        <>
          <Badge variant="destructive" className="mr-2">
            <AlertCircle className="w-3 h-3 mr-1" />
            Expired
          </Badge>
          <Button size="sm" variant="outline" onClick={handleReconnect} data-testid="button-reconnect-oauth">
            Reconnect
          </Button>
        </>
      );
    }

    return (
      <Badge variant="default">
        <CheckCircle2 className="w-3 h-3 mr-1" />
        Connected
      </Badge>
    );
  };

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <Database className="w-16 h-16 text-muted-foreground mb-4" />
      <h3 className="text-lg font-semibold mb-2">No Google Sheets Connected</h3>
      <p className="text-sm text-muted-foreground mb-6 max-w-md">
        Connect your Google Sheets to visualize spatial data on maps and manage permissions.
        You can select multiple sheets at once.
      </p>
      {grantStatus?.hasGrant && (
        <GoogleDrivePicker
          onSheetsPicked={handleSheetsPicked}
          disabled={batchAddMutation.isPending || !grantStatus.hasGrant}
          autoOpen={autoOpenPicker}
          accessToken={grantStatus?.accessToken}
          onAutoOpenHandled={() => setAutoOpenPicker(false)}
        />
      )}
    </div>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Google Sheets Connections
            </CardTitle>
            <CardDescription>
              Manage your connected Google Sheets for map layers and permissions
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {renderOAuthStatus()}
            {grantStatus?.hasGrant && connections && connections.length > 0 && (
              <GoogleDrivePicker
                onSheetsPicked={handleSheetsPicked}
                disabled={batchAddMutation.isPending || !grantStatus.hasGrant}
                autoOpen={autoOpenPicker}
                accessToken={grantStatus?.accessToken}
                onAutoOpenHandled={() => setAutoOpenPicker(false)}
              />
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {!grantLoading && !grantStatus?.hasGrant && (
          <Alert className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You need to authenticate with Google to manage connections.
              {isEditor && ' Click "Reconnect" above to authorize access to your Google Sheets.'}
            </AlertDescription>
          </Alert>
        )}

        {connectionsError && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Failed to load connections. Please try refreshing the page.
            </AlertDescription>
          </Alert>
        )}

        {connectionsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : !connections || connections.length === 0 ? (
          renderEmptyState()
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Spreadsheet Name</TableHead>
                  <TableHead>Spreadsheet ID</TableHead>
                  <TableHead>Connected</TableHead>
                  {isEditor && <TableHead className="text-right">Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {connections.map((connection) => (
                  <TableRow key={connection.id} data-testid={`row-connection-${connection.id}`}>
                    <TableCell className="font-medium">{connection.spreadsheetName}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {connection.spreadsheetId.slice(0, 20)}...
                        </code>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleCopyId(connection.spreadsheetId)}
                          data-testid={`button-copy-${connection.id}`}
                        >
                          {copiedId === connection.spreadsheetId ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {format(new Date(connection.createdAt), 'MMM d, yyyy')}
                    </TableCell>
                    {isEditor && (
                      <TableCell className="text-right">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(connection.id)}
                          disabled={deleteMutation.isPending}
                          data-testid={`button-delete-${connection.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
