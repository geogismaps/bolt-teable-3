import { MapPin, FileText, Shield } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: '/', label: 'Map View', icon: MapPin },
    { path: '/documents', label: 'Documents', icon: FileText },
    { path: '/permissions', label: 'Permissions', icon: Shield },
  ];

  return (
    <nav className="flex gap-2 p-4 border-b bg-card/50">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.path;

        return (
          <Link key={item.path} href={item.path}>
            <Button
              variant={isActive ? 'default' : 'ghost'}
              className="gap-2"
              data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Button>
          </Link>
        );
      })}
    </nav>
  );
}
