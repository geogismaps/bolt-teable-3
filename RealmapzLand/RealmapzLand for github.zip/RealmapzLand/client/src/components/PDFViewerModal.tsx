import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, X } from "lucide-react";
import { getViewerUrl } from "@/lib/contentTypeDetection";

interface PDFViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  pdfUrl: string;
  title?: string;
}

export function PDFViewerModal({ isOpen, onClose, pdfUrl, title }: PDFViewerModalProps) {
  const embedUrl = getViewerUrl(pdfUrl, 'pdf');

  const handleOpenInNewTab = () => {
    window.open(pdfUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] p-0">
        <DialogHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle data-testid="text-pdf-viewer-title">
              {title || "PDF Viewer"}
            </DialogTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleOpenInNewTab}
                data-testid="button-open-pdf-new-tab"
                title="Open in new tab"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={onClose}
                data-testid="button-close-pdf-viewer"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* PDF Embed */}
        <div className="relative h-[75vh] bg-muted">
          <iframe
            src={embedUrl}
            className="w-full h-full border-0"
            title={title || "PDF Document"}
            data-testid="iframe-pdf-viewer"
          />
        </div>

        {/* Footer with hint */}
        <div className="p-3 border-t bg-muted/30 text-xs text-muted-foreground text-center">
          Click the external link icon to open in a new tab
        </div>
      </DialogContent>
    </Dialog>
  );
}
