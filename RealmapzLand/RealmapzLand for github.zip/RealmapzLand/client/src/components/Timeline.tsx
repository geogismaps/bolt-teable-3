import { Circle, FileText, Users, MapPin } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

interface TimelineEvent {
  id: string;
  date: Date;
  type: 'ownership' | 'document' | 'survey' | 'other';
  title: string;
  description: string;
  owner?: string;
  documentId?: string;
}

interface TimelineProps {
  events: TimelineEvent[];
  onEventClick?: (event: TimelineEvent) => void;
}

const iconMap = {
  ownership: Users,
  document: FileText,
  survey: MapPin,
  other: Circle,
};

const colorMap = {
  ownership: 'text-chart-2',
  document: 'text-chart-1',
  survey: 'text-chart-3',
  other: 'text-muted-foreground',
};

export default function Timeline({ events, onEventClick }: TimelineProps) {
  return (
    <div className="relative">
      <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />
      
      <div className="space-y-6">
        {events.map((event, index) => {
          const Icon = iconMap[event.type];
          const colorClass = colorMap[event.type];
          
          return (
            <div key={event.id} className="relative flex gap-4" data-testid={`timeline-event-${event.id}`}>
              <div className="relative flex-shrink-0">
                <div className={`w-12 h-12 rounded-full bg-card border-2 border-primary flex items-center justify-center ${colorClass}`}>
                  <Icon className="h-5 w-5" />
                </div>
                {index < events.length - 1 && (
                  <div className="absolute top-12 left-1/2 -ml-px h-6 w-0.5 bg-border" />
                )}
              </div>
              
              <Card
                className="flex-1 p-4 hover-elevate active-elevate-2 cursor-pointer"
                onClick={() => onEventClick?.(event)}
              >
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold mb-1">{event.title}</h3>
                    <p className="text-xs text-muted-foreground">{event.description}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {format(event.date, 'MMM d, yyyy')}
                  </Badge>
                </div>
                
                {event.owner && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Owner: <span className="font-medium">{event.owner}</span>
                  </p>
                )}
              </Card>
            </div>
          );
        })}
      </div>
    </div>
  );
}
