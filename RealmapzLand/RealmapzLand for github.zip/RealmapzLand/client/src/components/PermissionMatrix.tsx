import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useEffect, useState } from 'react';
import type { ColDef } from 'ag-grid-community';
import { Badge } from '@/components/ui/badge';

interface Permission {
  userId: string;
  userName: string;
  role: 'admin' | 'editor' | 'client';
  sheetAccess: string[];
  columnPermissions: Record<string, 'view' | 'edit' | 'hidden'>;
}

interface PermissionMatrixProps {
  permissions: Permission[];
  columns: string[];
}

export default function PermissionMatrix({ permissions, columns }: PermissionMatrixProps) {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'));
    };
    checkTheme();
    
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    
    return () => observer.disconnect();
  }, []);

  const roleColors: Record<string, 'destructive' | 'default' | 'secondary'> = {
    admin: 'destructive',
    editor: 'default',
    client: 'secondary',
  };

  const columnDefs: ColDef[] = [
    {
      field: 'userName',
      headerName: 'User',
      pinned: 'left',
      width: 180,
      cellRenderer: (params: any) => {
        const role = params.data.role;
        return (
          <div className="flex items-center gap-2 h-full">
            <span className="font-medium">{params.value}</span>
            <Badge variant={roleColors[role] || 'default'} className="text-xs">
              {role}
            </Badge>
          </div>
        );
      },
    },
    ...columns.map(col => ({
      field: `columnPermissions.${col}`,
      headerName: col,
      width: 120,
      cellRenderer: (params: any) => {
        const permission = params.data.columnPermissions[col];
        const colors = {
          edit: 'bg-chart-2 text-white',
          view: 'bg-chart-1 text-white',
          hidden: 'bg-muted text-muted-foreground',
        };
        return (
          <div className="flex items-center h-full">
            <Badge className={`text-xs ${colors[permission as keyof typeof colors]}`}>
              {permission}
            </Badge>
          </div>
        );
      },
    })),
  ];

  return (
    <div
      className={isDark ? 'ag-theme-alpine-dark' : 'ag-theme-alpine'}
      style={{ height: '400px', width: '100%' }}
      data-testid="permission-matrix"
    >
      <AgGridReact
        rowData={permissions}
        columnDefs={columnDefs}
        domLayout="normal"
        rowHeight={50}
        headerHeight={40}
      />
    </div>
  );
}
