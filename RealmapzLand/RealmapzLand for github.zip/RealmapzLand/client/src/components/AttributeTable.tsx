import { useState, useMemo, useCallback, useRef, useEffect, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { AgGridReact } from 'ag-grid-react';
import { AllCommunityModule, ModuleRegistry } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { Button } from '@/components/ui/button';
import { X, Maximize2, Minimize2, ExternalLink, RefreshCw, Fullscreen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { ColDef, CellValueChangedEvent, ICellRendererParams, GridApi, ColumnState } from 'ag-grid-community';
import { detectContentType, getThumbnailUrl, type ContentType } from '@/lib/contentTypeDetection';
import { ImageViewerModal } from './ImageViewerModal';
import { PDFViewerModal } from './PDFViewerModal';
import { PanoramaViewerModal } from './PanoramaViewerModal';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { useFieldPermissions, isFieldHidden, isFieldEditable } from '@/hooks/useFieldPermissions';

// Register AG Grid modules (required for AG Grid v31+)
ModuleRegistry.registerModules([AllCommunityModule]);

// Helper function to detect if a value is a URL
const isUrl = (value: any): boolean => {
  if (!value || typeof value !== 'string') return false;
  const trimmed = value.trim();
  
  // Quick pre-check for common URL patterns
  if (!trimmed.startsWith('http://') && 
      !trimmed.startsWith('https://') && 
      !trimmed.includes('drive.google.com')) {
    return false;
  }
  
  // Use URL parsing for robust validation
  try {
    const parsedUrl = new URL(trimmed);
    // Whitelist trusted protocols
    return parsedUrl.protocol === 'http:' || parsedUrl.protocol === 'https:';
  } catch {
    // If URL parsing fails, it's not a valid URL
    return false;
  }
};

// Custom cell renderer for link columns
const LinkCellRenderer = (props: ICellRendererParams & { onLinkOpen?: (url: string, fieldName: string) => void }) => {
  const { value, colDef, onLinkOpen } = props;
  
  if (!value || !isUrl(value) || !colDef) {
    return <span>{value}</span>;
  }

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onLinkOpen && colDef?.field) {
      onLinkOpen(value, colDef.field);
    }
  };

  return (
    <div 
      className="flex items-center gap-1 cursor-pointer text-blue-600 hover:text-blue-800 hover:underline"
      onClick={handleClick}
      data-testid={`link-cell-${colDef?.field || 'unknown'}`}
    >
      <ExternalLink className="w-3 h-3" />
      <span className="truncate">View Link</span>
    </div>
  );
};

// Custom cell renderer for content columns (PDF, image, panorama)
const ContentCellRenderer = (props: ICellRendererParams & { 
  onContentOpen?: (url: string, fieldName: string, contentType: ContentType) => void 
}) => {
  const { value, colDef, onContentOpen } = props;
  
  if (!value || !isUrl(String(value)) || !colDef) {
    return <span>{value}</span>;
  }

  const contentType = detectContentType(String(value), colDef.field);
  
  // Only show content renderer for PDFs, images, and panoramas
  if (contentType === 'link') {
    return <span>{value}</span>;
  }

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onContentOpen && colDef?.field) {
      onContentOpen(String(value), colDef.field, contentType);
    }
  };

  const thumbnailUrl = getThumbnailUrl(String(value), 80);

  // Different icons/labels for different content types
  const getLabel = () => {
    switch (contentType) {
      case 'pdf': return 'View PDF';
      case 'panorama': return 'View 360°';
      case 'image': return 'View Image';
      default: return 'View';
    }
  };

  return (
    <div 
      className="flex items-center gap-2 cursor-pointer hover:opacity-80"
      onClick={handleClick}
      data-testid={`content-cell-${colDef?.field || 'unknown'}`}
    >
      {contentType === 'image' || contentType === 'panorama' ? (
        <img 
          src={thumbnailUrl}
          alt="Thumbnail"
          className="w-12 h-12 object-cover rounded border border-gray-300"
          onError={(e) => {
            // Fallback to placeholder on error
            (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="48" height="48"%3E%3Crect fill="%23ddd" width="48" height="48"/%3E%3C/svg%3E';
          }}
        />
      ) : (
        // PDF icon
        <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded border border-red-300">
          <span className="text-red-600 text-xs font-bold">PDF</span>
        </div>
      )}
      <span className="text-xs text-blue-600 truncate">{getLabel()}</span>
    </div>
  );
};

interface AttributeTableProps {
  layerId: string;
  layerName: string;
  geometryField?: string;
  features: any[];
  onClose: () => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
  onDataUpdated?: () => void;
  onLinkOpen?: (url: string, fieldName: string) => void;
  manualRefresh?: () => void;
  lastSynced?: number;
  isRefreshing?: boolean;
  readOnly?: boolean;
}

export default function AttributeTable({
  layerId,
  layerName,
  geometryField,
  features,
  onClose,
  isExpanded,
  onToggleExpand,
  onDataUpdated,
  onLinkOpen,
  manualRefresh,
  lastSynced,
  isRefreshing = false,
  readOnly = false
}: AttributeTableProps) {
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isMounted, setIsMounted] = useState(false);
  const [isDialogReady, setIsDialogReady] = useState(false);
  
  // Grid API ref for state persistence
  const gridApiRef = useRef<GridApi | null>(null);
  // Container refs for portal-based rendering
  const dockedContainerRef = useRef<HTMLDivElement | null>(null);
  const dialogContainerRef = useRef<HTMLDivElement | null>(null);
  // Saved grid state for restore after portal switch
  const savedGridStateRef = useRef<{
    columnState?: ColumnState[];
    filterModel?: any;
  } | null>(null);
  
  // Viewer states
  const [pdfViewerOpen, setPDFViewerOpen] = useState(false);
  const [imageViewerOpen, setImageViewerOpen] = useState(false);
  const [panoramaViewerOpen, setPanoramaViewerOpen] = useState(false);
  const [selectedUrl, setSelectedUrl] = useState<string>('');
  const [selectedField, setSelectedField] = useState<string>('');
  
  // Get all field names for permission lookup
  const allFields = useMemo(() => {
    if (!features.length) return [];
    const fields = new Set<string>();
    features.forEach(feature => {
      if (feature.properties) {
        Object.keys(feature.properties).forEach(key => fields.add(key));
      }
    });
    return Array.from(fields);
  }, [features]);
  
  // Fetch field permissions
  const { data: permissions } = useFieldPermissions(layerId, allFields);
  
  // Memoize content click handler to stabilize columnDefs
  const handleContentOpen = useCallback((url: string, fieldName: string, contentType: ContentType) => {
    setSelectedUrl(url);
    setSelectedField(fieldName);
    
    // Open appropriate viewer based on content type
    switch (contentType) {
      case 'pdf':
        setPDFViewerOpen(true);
        break;
      case 'panorama':
        setPanoramaViewerOpen(true);
        break;
      case 'image':
        setImageViewerOpen(true);
        break;
    }
  }, []);
  
  // Capture grid state before toggling
  const captureGridState = useCallback(() => {
    if (gridApiRef.current) {
      savedGridStateRef.current = {
        columnState: gridApiRef.current.getColumnState(),
        filterModel: gridApiRef.current.getFilterModel(),
      };
    }
  }, []);

  // Restore grid state after grid is ready
  const restoreGridState = useCallback(() => {
    if (gridApiRef.current && savedGridStateRef.current) {
      if (savedGridStateRef.current.columnState) {
        gridApiRef.current.applyColumnState({
          state: savedGridStateRef.current.columnState,
          applyOrder: true,
        });
      }
      if (savedGridStateRef.current.filterModel) {
        gridApiRef.current.setFilterModel(savedGridStateRef.current.filterModel);
      }
    }
  }, []);

  // Unified handler for toggling full-screen mode
  // This ensures all dialog close paths (overlay click, ESC, close button) are handled consistently
  const handleFullScreenChange = useCallback((newState: boolean) => {
    captureGridState();
    setIsFullScreen(newState);
  }, [captureGridState]);

  // Set mounted flag once refs are populated
  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Track when dialog container is ready (after ref is set)
  useLayoutEffect(() => {
    if (isFullScreen && dialogContainerRef.current) {
      setIsDialogReady(true);
    } else if (!isFullScreen) {
      setIsDialogReady(false);
    }
  }, [isFullScreen]);

  // Restore state after mode changes
  useEffect(() => {
    if (gridApiRef.current && savedGridStateRef.current) {
      // Small delay to ensure grid is fully rendered after portal switch
      const timer = setTimeout(() => {
        restoreGridState();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isFullScreen, restoreGridState]);
  
  // Format last synced timestamp
  const formatLastSynced = (timestamp?: number) => {
    if (!timestamp) return 'Never';
    const date = new Date(timestamp);
    const now = new Date();
    const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffSeconds < 10) return 'Just now';
    if (diffSeconds < 60) return `${diffSeconds}s ago`;
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)}m ago`;
    return date.toLocaleTimeString();
  };

  // Handle cell value changes
  const handleCellValueChanged = async (event: CellValueChangedEvent) => {
    // Prevent any editing when in read-only mode
    if (readOnly) {
      return;
    }
    
    const { data, colDef, newValue, oldValue } = event;
    
    // Don't update if value hasn't changed
    if (newValue === oldValue) {
      return;
    }

    // Get the field name and row index
    const fieldName = colDef.field;
    const rowIndex = data.__rowIndex;

    if (!fieldName || !rowIndex) {
      toast({
        title: 'Error',
        description: 'Cannot identify field or row',
        variant: 'destructive'
      });
      return;
    }

    // Validate non-empty
    if (!newValue || String(newValue).trim() === '') {
      toast({
        title: 'Validation Error',
        description: `Field '${fieldName}' cannot be empty`,
        variant: 'destructive'
      });
      // Revert the change
      event.node.setDataValue(fieldName, oldValue);
      return;
    }

    setIsUpdating(true);

    try {
      const response = await fetch(`/api/layers/${layerId}/features/${rowIndex}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ [fieldName]: newValue })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update');
      }

      toast({
        title: 'Success',
        description: `Updated ${fieldName} successfully`,
      });

      // Notify parent to refresh data
      if (onDataUpdated) {
        onDataUpdated();
      }
    } catch (error: any) {
      console.error('Error updating feature:', error);
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update feature',
        variant: 'destructive'
      });
      // Revert the change
      event.node.setDataValue(fieldName, oldValue);
    } finally {
      setIsUpdating(false);
    }
  };

  // Detect image and link columns and create column definitions
  const columnDefs = useMemo<ColDef[]>(() => {
    if (!features.length) return [];

    const allKeys = new Set<string>();
    features.forEach(feature => {
      if (feature.properties) {
        Object.keys(feature.properties).forEach(key => allKeys.add(key));
      }
    });

    // Detect content columns (PDFs, images, panoramas) and link columns
    const contentColumns = new Set<string>();
    const linkColumns = new Set<string>();
    
    Array.from(allKeys).forEach(key => {
      // Check if at least one feature has a URL value for this column
      const hasUrl = features.some(feature => {
        const value = feature.properties?.[key];
        return isUrl(value);
      });
      
      if (hasUrl) {
        // Check the content type of the first URL we find
        const sampleValue = features.find(f => isUrl(f.properties?.[key]))?.properties?.[key];
        if (sampleValue) {
          const contentType = detectContentType(String(sampleValue), key);
          if (contentType === 'pdf' || contentType === 'image' || contentType === 'panorama') {
            contentColumns.add(key);
          } else {
            linkColumns.add(key);
          }
        }
      }
    });

    // Convert to AG Grid column definitions, filtering out hidden fields
    const cols: ColDef[] = Array.from(allKeys)
      .filter(key => !isFieldHidden(key, permissions)) // Filter hidden fields
      .map(key => {
        const isContentColumn = contentColumns.has(key);
        const isLinkColumn = linkColumns.has(key);
        const isGeometryColumn = key === geometryField;
        const fieldEditable = isFieldEditable(key, permissions);

        return {
          field: key,
          headerName: key,
          sortable: true,
          filter: true,
          floatingFilter: true, // Enable floating filters
          resizable: true,
          minWidth: isContentColumn ? 180 : (isLinkColumn ? 150 : 100),
          flex: 1,
          // Field is editable if: not read-only AND not a content/link/geometry column AND has edit permission
          editable: !readOnly && !isContentColumn && !isLinkColumn && !isGeometryColumn && fieldEditable,
          // Use custom renderer for content and link columns
          cellRenderer: isContentColumn ? ContentCellRenderer : (isLinkColumn ? LinkCellRenderer : undefined),
          cellRendererParams: isContentColumn 
            ? { onContentOpen: handleContentOpen } 
            : (isLinkColumn ? { onLinkOpen } : undefined),
          // Style for geometry, read-only layer, or read-only fields
          cellStyle: (params) => {
            const style: Record<string, string> = {};
            if (isGeometryColumn) {
              style.backgroundColor = '#f0f0f0';
              style.cursor = 'not-allowed';
            } else if (readOnly || (!fieldEditable && !isContentColumn && !isLinkColumn)) {
              style.backgroundColor = '#f9f9f9';
              style.cursor = 'not-allowed';
            }
            return style;
          },
        };
      });

    // Add hidden __rowIndex column (for internal use)
    cols.push({
      field: '__rowIndex',
      hide: true,
      suppressColumnsToolPanel: true,
      lockVisible: true,
    } as ColDef);

    return cols;
  }, [features, geometryField, onLinkOpen, handleContentOpen, permissions]);

  // Extract row data from features and add row index
  const rowData = useMemo(() => {
    return features.map((feature, index) => ({
      ...(feature.properties || {}),
      __rowIndex: index + 2, // +2 because row 1 is header, data starts at row 2
    }));
  }, [features]);

  // Single AG Grid instance - rendered once and moved via portal
  const gridElement = (
    <div className="ag-theme-alpine" style={{ height: '100%', width: '100%' }}>
      <AgGridReact
        columnDefs={columnDefs}
        rowData={rowData}
        defaultColDef={{
          sortable: true,
          filter: true,
          floatingFilter: true,
          resizable: true,
        }}
        animateRows={true}
        rowSelection="single"
        domLayout="normal"
        onCellValueChanged={handleCellValueChanged}
        readOnlyEdit={isUpdating}
        onGridReady={(params) => {
          gridApiRef.current = params.api;
          // Restore state after grid is ready (for portal switches)
          restoreGridState();
        }}
        data-testid="attribute-table-grid"
      />
    </div>
  );

  // Shared toolbar component
  const renderToolbar = (inDialog: boolean = false) => (
    <div 
      className="flex items-center justify-between px-3 py-2 border-b"
      style={{ backgroundColor: '#34495e', borderColor: '#445566' }}
    >
      <div className="flex items-center gap-2">
        <h3 className="text-sm font-semibold text-white">
          Attribute Table: {layerName}
        </h3>
        <span className="text-xs text-gray-300">
          ({features.length} {features.length === 1 ? 'feature' : 'features'})
        </span>
        {lastSynced && (
          <span className="text-xs text-gray-400" data-testid="text-last-synced">
            Last synced: {formatLastSynced(lastSynced)}
          </span>
        )}
      </div>
      
      <div className="flex items-center gap-1">
        {manualRefresh && (
          <Button
            size="sm"
            variant="ghost"
            onClick={manualRefresh}
            disabled={isRefreshing}
            data-testid="button-manual-refresh"
            className="text-white hover:bg-white/10 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        )}
        {!inDialog && (
          <>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => handleFullScreenChange(true)}
              data-testid="button-fullscreen-table"
              className="text-white hover:bg-white/10"
              title="Open in full screen"
            >
              <Fullscreen className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={onToggleExpand}
              data-testid="button-toggle-expand-table"
              className="text-white hover:bg-white/10"
            >
              {isExpanded ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </Button>
          </>
        )}
        <Button
          size="sm"
          variant="ghost"
          onClick={inDialog ? () => handleFullScreenChange(false) : onClose}
          data-testid={inDialog ? "button-close-fullscreen" : "button-close-table"}
          className="text-white hover:bg-white/10"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Docked Table View */}
      <div className="flex flex-col h-full bg-background border-t">
        {renderToolbar(false)}
        <div className="flex-1" ref={dockedContainerRef}>
          {/* Grid portals into here when NOT full-screen */}
        </div>
      </div>

      {/* Full-Screen Dialog */}
      {isFullScreen && (
        <Dialog open={isFullScreen} onOpenChange={handleFullScreenChange}>
          <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] p-0 gap-0">
            <DialogTitle className="sr-only">Attribute Table - {layerName}</DialogTitle>
            <div className="flex flex-col h-full">
              {renderToolbar(true)}
              <div className="flex-1 overflow-hidden" ref={dialogContainerRef}>
                {/* Grid portals into here when full-screen */}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Portal the grid into the appropriate container once refs are ready */}
      {isMounted && (
        isFullScreen ? 
          (isDialogReady && dialogContainerRef.current && createPortal(gridElement, dialogContainerRef.current)) :
          (dockedContainerRef.current && createPortal(gridElement, dockedContainerRef.current))
      )}

      {/* Viewer Modals */}
      <PDFViewerModal
        isOpen={pdfViewerOpen}
        onClose={() => setPDFViewerOpen(false)}
        pdfUrl={selectedUrl}
        title={selectedField}
      />

      <ImageViewerModal
        isOpen={imageViewerOpen}
        onClose={() => setImageViewerOpen(false)}
        imageUrl={selectedUrl}
        title={selectedField}
      />

      <PanoramaViewerModal
        isOpen={panoramaViewerOpen}
        onClose={() => setPanoramaViewerOpen(false)}
        panoramaUrl={selectedUrl}
        title={selectedField}
      />
    </>
  );
}
