import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, X, AlertCircle } from "lucide-react";
import { getViewerUrl } from "@/lib/contentTypeDetection";

interface ImageViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  title?: string;
}

export function ImageViewerModal({ 
  isOpen, 
  onClose, 
  imageUrl, 
  title = "Image Viewer"
}: ImageViewerModalProps) {
  const [imageError, setImageError] = useState(false);

  const viewUrl = getViewerUrl(imageUrl, 'image');

  // Reset error state when modal opens or URL changes
  useEffect(() => {
    if (isOpen) {
      setImageError(false);
    }
  }, [isOpen, imageUrl]);

  const handleOpenInNewTab = () => {
    window.open(imageUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] p-0">
        <DialogHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle data-testid="text-image-viewer-title">
              {title}
            </DialogTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleOpenInNewTab}
                data-testid="button-open-image-new-tab"
                title="Open in new tab"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={onClose}
                data-testid="button-close-image-viewer"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* Image Display */}
        <div className="relative h-[70vh] bg-muted">
          {imageError ? (
            <div className="flex flex-col items-center justify-center h-full gap-4">
              <AlertCircle className="w-12 h-12 text-muted-foreground" />
              <p className="text-muted-foreground">Failed to load image</p>
              <Button 
                onClick={handleOpenInNewTab}
                data-testid="button-open-failed-image"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in New Tab
              </Button>
            </div>
          ) : (
            <img
              src={viewUrl}
              alt="Preview"
              className="w-full h-full object-contain"
              onError={() => setImageError(true)}
              data-testid="img-preview"
            />
          )}
        </div>

        {/* Footer with URL */}
        <div className="p-3 border-t bg-muted/30">
          <p className="text-xs text-muted-foreground truncate" data-testid="text-image-url">
            {imageUrl}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
