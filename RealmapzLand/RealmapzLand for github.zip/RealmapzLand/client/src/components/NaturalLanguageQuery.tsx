import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sparkles, X, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

// TypeScript declaration for Puter.js (loaded via CDN)
declare global {
  interface Window {
    puter: {
      ai: {
        chat: (
          prompt: string,
          options?: { model?: string; stream?: boolean }
        ) => Promise<{ message: { content: string } }>;
      };
    };
  }
}

interface FilterRule {
  id: string;
  layerId: string;
  fieldName: string;
  operator: string;
  value: string;
  source?: 'manual' | 'nl';
}

interface FieldMetadata {
  name: string;
  sampleValue: string;
}

interface NaturalLanguageQueryProps {
  layerId: string;
  layerName: string;
  availableFields: string[]; // Required: field names for validation
  fieldMetadata: FieldMetadata[]; // Field names with sample values for AI context
  onFiltersGenerated: (filters: FilterRule[]) => void;
  onClear: () => void;
  hasActiveNLFilters: boolean;
}

export default function NaturalLanguageQuery({
  layerId,
  layerName,
  availableFields,
  fieldMetadata,
  onFiltersGenerated,
  onClear,
  hasActiveNLFilters,
}: NaturalLanguageQueryProps) {
  const [query, setQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) {
      setError('Please enter a query');
      return;
    }

    if (availableFields.length === 0) {
      setError('No fields available in this layer');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // Build the AI prompt with layer schema context including sample values
      const fieldsWithSamples = fieldMetadata
        .map(f => `  - ${f.name}: "${f.sampleValue}"`)
        .join('\n');

      const prompt = `You are a map filter assistant. Convert the user's natural language query into structured filter rules.

Available fields in the "${layerName}" layer (with sample values):
${fieldsWithSamples}

User query: "${query}"

Rules:
1. Only use fields that exist in the available fields list above
2. Use the sample values to understand field types and format your filter values accordingly
3. Return ONLY valid JSON array, no markdown, no explanation
4. Each filter must have: fieldName (exact match from available fields), operator, value
5. Supported operators: equals, contains, greater_than, less_than, not_equals
6. If the query cannot be satisfied with available fields, return an empty array []

Return format:
[
  {
    "fieldName": "field_name",
    "operator": "equals",
    "value": "value"
  }
]

Examples:
Query: "show me vacant sites" → [{"fieldName": "status", "operator": "equals", "value": "vacant"}]
Query: "east facing parcels" → [{"fieldName": "orientation", "operator": "equals", "value": "east"}]
Query: "area greater than 5000" → [{"fieldName": "area_sqft", "operator": "greater_than", "value": "5000"}]

Now convert the user query above into filter rules JSON:`;

      // Call Puter.js AI (using GPT-5-nano for speed and efficiency)
      const response = await window.puter.ai.chat(prompt, {
        model: 'gpt-5-nano',
      });

      // Parse the AI response
      let aiContent = response.message.content.trim();
      
      // Remove markdown code blocks if present
      aiContent = aiContent.replace(/```json\n?/g, '').replace(/```\n?/g, '');
      
      // Parse JSON
      const parsedFilters = JSON.parse(aiContent);

      if (!Array.isArray(parsedFilters)) {
        throw new Error('Invalid response format from AI');
      }

      // Validate and add IDs to filters
      const validatedFilters: FilterRule[] = parsedFilters.map((filter: any, index: number) => {
        if (!filter.fieldName || !filter.operator || filter.value === undefined) {
          throw new Error('Invalid filter structure in AI response');
        }
        
        // Check if field exists
        if (!availableFields.includes(filter.fieldName)) {
          throw new Error(`Field "${filter.fieldName}" not found in layer`);
        }

        return {
          id: `nl-${Date.now()}-${index}`,
          layerId,
          fieldName: filter.fieldName,
          operator: filter.operator,
          value: String(filter.value),
          source: 'nl' as const, // Mark as AI-generated for UX distinction
        };
      });

      if (validatedFilters.length === 0) {
        setError('No matching filters found for your query. Try being more specific.');
        return;
      }

      // Apply the filters
      onFiltersGenerated(validatedFilters);
      setQuery(''); // Clear input after successful processing
      
    } catch (err: any) {
      console.error('Natural language query error:', err);
      
      if (err.message?.includes('JSON')) {
        setError('Failed to understand the query. Please try rephrasing it.');
      } else if (err.message?.includes('puter')) {
        setError('AI service unavailable. Please try again later.');
      } else {
        setError(err.message || 'Failed to process query. Please try again.');
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearFilters = () => {
    setQuery('');
    setError(null);
    onClear();
  };

  return (
    <div className="space-y-3" data-testid="natural-language-query">
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold">Ask AI</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-2">
        <div className="flex gap-2">
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setError(null);
            }}
            placeholder="Ask anything: show me vacant sites, east facing parcels..."
            disabled={isProcessing || availableFields.length === 0}
            data-testid="input-nl-query"
            className="flex-1"
          />
          <Button
            type="submit"
            size="sm"
            disabled={isProcessing || !query.trim() || availableFields.length === 0}
            data-testid="button-submit-nl-query"
          >
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Thinking...
              </>
            ) : (
              'Ask'
            )}
          </Button>
        </div>

        {hasActiveNLFilters && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleClearFilters}
            className="w-full"
            data-testid="button-clear-nl-filters"
          >
            <X className="h-4 w-4 mr-2" />
            Clear AI Filters
          </Button>
        )}
      </form>

      {error && (
        <Alert variant="destructive" data-testid="alert-nl-error">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {availableFields.length === 0 && (
        <Alert data-testid="alert-no-fields">
          <AlertDescription className="text-sm text-muted-foreground">
            Select a layer with data to use natural language queries
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
