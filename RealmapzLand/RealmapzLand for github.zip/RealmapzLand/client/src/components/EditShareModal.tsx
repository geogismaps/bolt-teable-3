import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

interface ShareData {
  id: string;
  shareToken: string;
  layerId: string;
  layerName: string;
  expiresAt: string | null;
  embedEnabled: boolean;
}

interface EditShareModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  share: ShareData;
}

export default function EditShareModal({ open, onOpenChange, share }: EditShareModalProps) {
  const { toast } = useToast();
  const [expiresAt, setExpiresAt] = useState<string>(
    share.expiresAt ? new Date(share.expiresAt).toISOString().slice(0, 16) : ""
  );
  const [embedEnabled, setEmbedEnabled] = useState(share.embedEnabled);

  const updateShareMutation = useMutation({
    mutationFn: async () => {
      const updates: { expiresAt?: string | null; embedEnabled?: boolean } = {};
      
      if (expiresAt) {
        updates.expiresAt = new Date(expiresAt).toISOString();
      } else {
        updates.expiresAt = null;
      }
      
      if (embedEnabled !== share.embedEnabled) {
        updates.embedEnabled = embedEnabled;
      }

      const response = await apiRequest('PATCH', `/api/share/${share.id}`, updates);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update share');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/share/organization'] });
      toast({
        title: 'Share updated',
        description: 'Share settings have been updated successfully',
      });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateShareMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="modal-edit-share">
        <DialogHeader>
          <DialogTitle>Edit Share</DialogTitle>
          <DialogDescription>
            Update share settings for "{share.layerName}"
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="expiresAt">Expiration Date (optional)</Label>
            <Input
              id="expiresAt"
              type="datetime-local"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              data-testid="input-expires-at"
            />
            <p className="text-sm text-muted-foreground">
              Leave empty for no expiration
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="embedEnabled">Allow Embedding</Label>
              <p className="text-sm text-muted-foreground">
                Enable this share to be embedded in other websites
              </p>
            </div>
            <Switch
              id="embedEnabled"
              checked={embedEnabled}
              onCheckedChange={setEmbedEnabled}
              data-testid="switch-embed-enabled"
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel-edit"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={updateShareMutation.isPending}
              data-testid="button-save-edit"
            >
              {updateShareMutation.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
