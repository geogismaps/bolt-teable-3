import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, X } from "lucide-react";

interface LinkViewerModalProps {
  open: boolean;
  onClose: () => void;
  url: string | null;
  title?: string;
}

export function LinkViewerModal({ open, onClose, url, title }: LinkViewerModalProps) {
  if (!url) return null;

  // Convert Google Drive share links to embed links
  const getEmbedUrl = (originalUrl: string): string => {
    // Handle Google Drive links
    if (originalUrl.includes('drive.google.com')) {
      // Extract file ID from various Google Drive URL formats
      
      // Format 1: /file/d/<id> (standard share link)
      let fileIdMatch = originalUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
      if (fileIdMatch) {
        const fileId = fileIdMatch[1];
        return `https://drive.google.com/file/d/${fileId}/preview`;
      }
      
      // Format 2: open?id=<id> (older format)
      fileIdMatch = originalUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
      if (fileIdMatch) {
        const fileId = fileIdMatch[1];
        return `https://drive.google.com/file/d/${fileId}/preview`;
      }
      
      // Format 3: uc?id=<id> (download format)
      fileIdMatch = originalUrl.match(/uc\?id=([a-zA-Z0-9_-]+)/);
      if (fileIdMatch) {
        const fileId = fileIdMatch[1];
        return `https://drive.google.com/file/d/${fileId}/preview`;
      }
    }
    
    // For other URLs, return as-is
    return originalUrl;
  };

  const embedUrl = getEmbedUrl(url);
  const isGoogleDrive = url.includes('drive.google.com');

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent 
        className="max-w-5xl h-[90vh] flex flex-col"
        data-testid="link-viewer-modal"
      >
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>{title || "Document Viewer"}</DialogTitle>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => window.open(url, '_blank', 'noopener,noreferrer')}
                data-testid="button-open-new-tab"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in New Tab
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 w-full overflow-hidden rounded border">
          {isGoogleDrive ? (
            <iframe
              src={embedUrl}
              className="w-full h-full"
              allow="autoplay"
              data-testid="iframe-viewer"
            />
          ) : (
            // For non-Google Drive links, try to embed or show message
            <div className="w-full h-full flex flex-col items-center justify-center gap-4 p-8">
              <p className="text-sm text-muted-foreground text-center">
                This link cannot be previewed directly. Click the button below to open it in a new tab.
              </p>
              <Button
                onClick={() => window.open(url, '_blank', 'noopener,noreferrer')}
                data-testid="button-open-link"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open Link
              </Button>
              <div className="mt-4 p-4 bg-muted rounded max-w-2xl">
                <p className="text-xs font-mono break-all">{url}</p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
