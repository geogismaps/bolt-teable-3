import { FileText, Download, ExternalLink, Clock } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'image';
  size: string;
  uploadedAt: Date;
  uploadedBy: string;
  parcelId?: string;
}

interface DocumentListProps {
  documents: Document[];
  onView: (doc: Document) => void;
  onDownload: (doc: Document) => void;
}

export default function DocumentList({ documents, onView, onDownload }: DocumentListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {documents.map((doc) => (
        <Card
          key={doc.id}
          className="p-4 hover-elevate active-elevate-2 cursor-pointer"
          onClick={() => onView(doc)}
          data-testid={`document-${doc.id}`}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-md bg-primary/10">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold truncate mb-1">{doc.name}</h3>
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                <Clock className="h-3 w-3" />
                <span>{formatDistanceToNow(doc.uploadedAt, { addSuffix: true })}</span>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className="text-xs">
                  {doc.size}
                </Badge>
                {doc.parcelId && (
                  <Badge variant="outline" className="text-xs">
                    Parcel #{doc.parcelId}
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground">By {doc.uploadedBy}</p>
            </div>
          </div>
          
          <div className="flex gap-2 mt-3">
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onView(doc);
              }}
              data-testid={`button-view-${doc.id}`}
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              View
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                onDownload(doc);
              }}
              data-testid={`button-download-${doc.id}`}
            >
              <Download className="h-3 w-3" />
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
