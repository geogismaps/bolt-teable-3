import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

interface AddLayerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface SheetConnection {
  id: string;
  spreadsheetId: string;
  spreadsheetName: string;
  hasTokens: boolean;
  createdAt: Date;
}

interface SheetMetadata {
  properties: {
    title: string;
  };
  sheets: Array<{
    properties: {
      title: string;
      sheetId: number;
    };
  }>;
}

interface SheetData {
  sheetName: string;
  headers: string[];
  rows: Record<string, any>[];
  geometryField?: string;
}

export default function AddLayerModal({ open, onOpenChange }: AddLayerModalProps) {
  const [selectedConnection, setSelectedConnection] = useState<string | undefined>(undefined);
  const [selectedSheet, setSelectedSheet] = useState<string | undefined>(undefined);
  const [layerName, setLayerName] = useState<string>('');
  const [geometryField, setGeometryField] = useState<string | undefined>(undefined);
  const [layerColor, setLayerColor] = useState<string>('#3498db');
  const [sheetHeaders, setSheetHeaders] = useState<string[]>([]);

  // Fetch connections
  const { data: allConnections = [] } = useQuery<SheetConnection[]>({
    queryKey: ['/api/connections'],
  });

  // Filter out pending connections AND deduplicate by spreadsheetId (keep most recent)
  const connections = (() => {
    // First filter out pending connections
    const validConnections = allConnections.filter(c => 
      c.spreadsheetId && c.spreadsheetId.trim() !== '' && c.spreadsheetName !== 'Pending Connection'
    );
    
    // Then deduplicate by spreadsheetId, keeping only the most recent connection
    const uniqueMap = new Map<string, SheetConnection>();
    
    validConnections.forEach(conn => {
      const existing = uniqueMap.get(conn.spreadsheetId);
      if (!existing || new Date(conn.createdAt) > new Date(existing.createdAt)) {
        uniqueMap.set(conn.spreadsheetId, conn);
      }
    });
    
    return Array.from(uniqueMap.values());
  })();

  // Fetch available sheets when connection is selected
  const [availableSheets, setAvailableSheets] = useState<string[]>([]);
  const [loadingSheets, setLoadingSheets] = useState(false);

  // Auto-fill layer name from spreadsheet name when connection changes
  useEffect(() => {
    if (selectedConnection && !layerName) {
      const connection = allConnections.find(c => c.id === selectedConnection);
      if (connection && connection.spreadsheetName) {
        setLayerName(connection.spreadsheetName);
      }
    }
  }, [selectedConnection, allConnections, layerName]);

  // Reset dependent state when connection changes
  const [sheetsError, setSheetsError] = useState<string | null>(null);
  
  useEffect(() => {
    if (selectedConnection) {
      // CRITICAL: Reset ALL dependent state immediately when switching connections
      // This prevents stale sheet names from being used with the new connection
      setSelectedSheet(undefined);
      setAvailableSheets([]);  // Clear sheet list to hide stale options
      setSheetHeaders([]);
      setGeometryField(undefined);
      setSheetsError(null);
      
      const connection = allConnections.find(c => c.id === selectedConnection);
      if (connection) {
        if (!connection.hasTokens) {
          setSheetsError('This connection needs to be re-authenticated. Please reconnect in Settings → Connections.');
        } else {
          setLoadingSheets(true);
          fetch(`/api/connections/${connection.id}/metadata`)
            .then(res => {
              if (!res.ok) {
                throw new Error('Failed to load sheets. Please try reconnecting in Settings.');
              }
              return res.json();
            })
            .then((data: SheetMetadata) => {
              const sheetNames = data.sheets?.map(s => s.properties.title) || [];
              setAvailableSheets(sheetNames);
              
              // Auto-select first sheet if only one sheet exists
              if (sheetNames.length === 1) {
                setSelectedSheet(sheetNames[0]);
              }
            })
            .catch(err => {
              console.error('Error fetching sheets:', err);
              setSheetsError(err.message || 'Failed to load sheets');
            })
            .finally(() => setLoadingSheets(false));
        }
      }
    } else {
      setAvailableSheets([]);
      setSelectedSheet(undefined);
      setSheetHeaders([]);
      setGeometryField(undefined);
      setSheetsError(null);
    }
  }, [selectedConnection, allConnections]);

  // Fetch sheet data to get headers when sheet is selected
  useEffect(() => {
    if (selectedConnection && selectedSheet) {
      const connection = allConnections.find(c => c.id === selectedConnection);
      if (connection && connection.hasTokens) {
        fetch(`/api/connections/${connection.id}/sheets/${encodeURIComponent(selectedSheet)}`)
          .then(res => res.json())
          .then((data: SheetData) => {
            setSheetHeaders(data.headers || []);
            // Auto-set geometry field if detected
            if (data.geometryField) {
              setGeometryField(data.geometryField);
            }
          })
          .catch(err => console.error('Error fetching sheet data:', err));
      }
    }
  }, [selectedConnection, selectedSheet]);

  // Create layer mutation
  const createLayer = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/layers', {
        connectionId: selectedConnection,
        sheetName: selectedSheet,
        layerName: layerName || selectedSheet,
        geometryField: geometryField,
        color: layerColor,
        visible: true,
        symbologyType: 'single',
        labelsEnabled: false,
        popupsEnabled: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layers'] });
      onOpenChange(false);
      // Reset form
      setSelectedConnection(undefined);
      setSelectedSheet(undefined);
      setLayerName('');
      setGeometryField(undefined);
      setLayerColor('#3498db');
      setSheetHeaders([]);
    },
  });

  const handleSubmit = () => {
    if (!selectedConnection || !selectedSheet || !geometryField) {
      alert('Please select a connection, sheet, and geometry field');
      return;
    }
    createLayer.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Layer</DialogTitle>
          <DialogDescription>
            Select a Google Sheet to add as a map layer
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          {/* Connection Selection */}
          <div className="grid gap-2">
            <Label htmlFor="connection">Google Sheet Connection</Label>
            <Select value={selectedConnection || ""} onValueChange={setSelectedConnection}>
              <SelectTrigger id="connection" data-testid="select-connection">
                <SelectValue placeholder="Select a connected spreadsheet..." />
              </SelectTrigger>
              <SelectContent>
                {connections.length === 0 ? (
                  <div className="px-2 py-6 text-center text-sm text-muted-foreground">
                    No connected spreadsheets found.<br />
                    Go to Settings → Connections to connect Google Sheets.
                  </div>
                ) : (
                  connections
                    .filter(conn => conn.id && conn.id.trim() !== '')
                    .map(conn => (
                      <SelectItem key={conn.id} value={conn.id}>
                        {conn.spreadsheetName}
                      </SelectItem>
                    ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Error message for sheets */}
          {selectedConnection && sheetsError && (
            <div className="grid gap-2">
              <Label>Sheet Name</Label>
              <div className="px-3 py-2 bg-destructive/10 border border-destructive/20 rounded-md text-sm text-destructive">
                {sheetsError}
              </div>
            </div>
          )}
          
          {/* Loading indicator for sheets */}
          {selectedConnection && loadingSheets && (
            <div className="grid gap-2">
              <Label>Sheet Name</Label>
              <div className="px-3 py-2 flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading sheets...
              </div>
            </div>
          )}
          
          {/* Sheet Selection - Only show if multiple sheets exist */}
          {selectedConnection && !loadingSheets && availableSheets.length > 1 && (
            <div className="grid gap-2">
              <Label htmlFor="sheet">Sheet Name</Label>
              <Select 
                value={selectedSheet || ""} 
                onValueChange={setSelectedSheet}
              >
                <SelectTrigger id="sheet" data-testid="select-sheet">
                  <SelectValue placeholder="Select a sheet tab..." />
                </SelectTrigger>
                <SelectContent>
                  {availableSheets
                    .filter(sheetName => sheetName && sheetName.trim() !== '')
                    .map(sheetName => (
                      <SelectItem key={sheetName} value={sheetName}>
                        {sheetName}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                This spreadsheet has {availableSheets.length} sheets. Select which sheet tab to use as a map layer.
              </p>
            </div>
          )}
          
          {/* Auto-selected sheet indicator - Show when only one sheet exists */}
          {selectedConnection && !loadingSheets && availableSheets.length === 1 && selectedSheet && (
            <div className="grid gap-2">
              <Label>Sheet Name</Label>
              <div className="px-3 py-2 bg-muted rounded-md text-sm">
                {selectedSheet} <span className="text-muted-foreground">(auto-selected)</span>
              </div>
            </div>
          )}

          {/* Layer Name */}
          {selectedSheet && (
            <div className="grid gap-2">
              <Label htmlFor="layerName">Layer Name</Label>
              <Input
                id="layerName"
                value={layerName}
                onChange={(e) => setLayerName(e.target.value)}
                placeholder="Enter layer name"
                data-testid="input-layer-name"
              />
            </div>
          )}

          {/* Geometry Field */}
          {sheetHeaders.length > 0 && (
            <div className="grid gap-2">
              <Label htmlFor="geometryField">Geometry Field</Label>
              <Select value={geometryField || ""} onValueChange={setGeometryField}>
                <SelectTrigger id="geometryField" data-testid="select-geometry-field">
                  <SelectValue placeholder="Select column with geometry..." />
                </SelectTrigger>
                <SelectContent>
                  {sheetHeaders
                    .filter(header => header && header.trim() !== '')
                    .map(header => (
                      <SelectItem key={header} value={header}>
                        {header}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Column containing WKT or GeoJSON geometry data
              </p>
            </div>
          )}

          {/* Layer Color */}
          {geometryField && (
            <div className="grid gap-2">
              <Label htmlFor="color">Layer Color</Label>
              <div className="flex gap-2 items-center">
                <input
                  type="color"
                  id="color"
                  value={layerColor}
                  onChange={(e) => setLayerColor(e.target.value)}
                  className="h-10 w-20 rounded border cursor-pointer"
                  data-testid="input-layer-color"
                />
                <span className="text-sm text-muted-foreground">{layerColor}</span>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!selectedConnection || !selectedSheet || !geometryField || createLayer.isPending}
            data-testid="button-create-layer"
          >
            {createLayer.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add Layer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
