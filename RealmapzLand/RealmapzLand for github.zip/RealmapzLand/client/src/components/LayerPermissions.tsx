import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Edit, Loader2, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

interface LayerPermissionsProps {
  organizationId: string;
}

type PermissionLevel = 'hidden' | 'view' | 'edit';

interface User {
  id: string;
  email: string;
  full_name: string;
  role: string;
}

interface Layer {
  id: string;
  name: string;
  tableName: string;
}

interface LayerPermission {
  layerId: string;
  layerName: string;
  permissionLevel: PermissionLevel;
  isInherited: boolean;
}

export function LayerPermissions({ organizationId }: LayerPermissionsProps) {
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const { toast } = useToast();

  // Fetch all users in the organization
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/supabase/organizations', organizationId, 'users'],
    enabled: !!organizationId,
  });

  // Fetch layer permissions for selected user
  const { data: permissions = [], isLoading: permissionsLoading, refetch: refetchPermissions } = useQuery<LayerPermission[]>({
    queryKey: ['/api/layer-permissions/user', selectedUserId],
    enabled: !!selectedUserId,
  });

  // Update single layer permission
  const updatePermissionMutation = useMutation({
    mutationFn: async ({ layerId, permissionLevel }: { layerId: string; permissionLevel: PermissionLevel }) => {
      return apiRequest('POST', `/api/layer-permissions`, {
        userId: selectedUserId,
        layerId,
        permissionLevel,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layer-permissions/user', selectedUserId] });
      toast({ title: "Permission updated" });
    },
    onError: () => {
      toast({ title: "Failed to update permission", variant: "destructive" });
    },
  });

  // Bulk update all layers
  const bulkUpdateMutation = useMutation({
    mutationFn: async (permissionLevel: PermissionLevel) => {
      return apiRequest('POST', `/api/layer-permissions/bulk`, {
        userId: selectedUserId,
        permissionLevel,
        // layerIds: undefined means apply to all layers
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layer-permissions/user', selectedUserId] });
      toast({ title: "All permissions updated" });
    },
    onError: () => {
      toast({ title: "Failed to update permissions", variant: "destructive" });
    },
  });

  // Reset to role defaults
  const resetMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('DELETE', `/api/layer-permissions/user/${selectedUserId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layer-permissions/user', selectedUserId] });
      toast({ title: "Reset to role defaults" });
    },
    onError: () => {
      toast({ title: "Failed to reset permissions", variant: "destructive" });
    },
  });

  const selectedUser = users.find(u => u.id === selectedUserId);
  const isLoading = updatePermissionMutation.isPending || bulkUpdateMutation.isPending || resetMutation.isPending;

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-primary text-primary-foreground';
      case 'editor': return 'bg-muted text-muted-foreground';
      case 'viewer': return 'bg-muted/50 text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPermissionIcon = (level: PermissionLevel) => {
    switch (level) {
      case 'hidden': return <EyeOff className="h-4 w-4" />;
      case 'view': return <Eye className="h-4 w-4" />;
      case 'edit': return <Edit className="h-4 w-4" />;
    }
  };

  const getPermissionColor = (level: PermissionLevel) => {
    switch (level) {
      case 'hidden': return 'text-muted-foreground';
      case 'view': return 'text-blue-500';
      case 'edit': return 'text-green-500';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div className="flex-1 max-w-md">
          <Select value={selectedUserId} onValueChange={setSelectedUserId} disabled={usersLoading}>
            <SelectTrigger data-testid="select-user">
              <SelectValue placeholder="Select a user..." />
            </SelectTrigger>
            <SelectContent>
              {users.map(user => (
                <SelectItem key={user.id} value={user.id} data-testid={`user-option-${user.id}`}>
                  <div className="flex items-center gap-2">
                    <span>{user.full_name || user.email}</span>
                    <Badge className={cn("text-xs", getRoleBadgeColor(user.role))}>
                      {user.role}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedUser && (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => resetMutation.mutate()}
              disabled={isLoading || permissions.every(p => p.isInherited)}
              data-testid="button-reset-defaults"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset to Defaults
            </Button>
          </div>
        )}
      </div>

      {selectedUser && (
        <>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-muted-foreground">Bulk Actions:</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => bulkUpdateMutation.mutate('hidden')}
              disabled={isLoading}
              data-testid="button-bulk-hidden"
            >
              <EyeOff className="h-4 w-4 mr-2" />
              Set All to Hidden
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => bulkUpdateMutation.mutate('view')}
              disabled={isLoading}
              data-testid="button-bulk-view"
            >
              <Eye className="h-4 w-4 mr-2" />
              Set All to View
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => bulkUpdateMutation.mutate('edit')}
              disabled={isLoading}
              data-testid="button-bulk-edit"
            >
              <Edit className="h-4 w-4 mr-2" />
              Set All to Edit
            </Button>
          </div>

          {permissionsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : permissions.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No layers found. Connect a Google Sheet to create layers.
              </CardContent>
            </Card>
          ) : (
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Layer Name</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Permission</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permissions.map(permission => (
                    <TableRow key={permission.layerId} data-testid={`layer-row-${permission.layerId}`}>
                      <TableCell className="font-medium">{permission.layerName}</TableCell>
                      <TableCell>
                        {permission.isInherited ? (
                          <Badge variant="outline" className="text-xs">
                            From Role ({selectedUser.role})
                          </Badge>
                        ) : (
                          <Badge className="text-xs bg-primary/10 text-primary">
                            Custom Override
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className={cn("flex items-center gap-2 font-medium", getPermissionColor(permission.permissionLevel))}>
                          {getPermissionIcon(permission.permissionLevel)}
                          <span className="capitalize">{permission.permissionLevel}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant={permission.permissionLevel === 'hidden' ? 'default' : 'ghost'}
                            size="sm"
                            onClick={() => updatePermissionMutation.mutate({
                              layerId: permission.layerId,
                              permissionLevel: 'hidden'
                            })}
                            disabled={isLoading || permission.permissionLevel === 'hidden'}
                            data-testid={`button-hidden-${permission.layerId}`}
                          >
                            <EyeOff className="h-4 w-4" />
                          </Button>
                          <Button
                            variant={permission.permissionLevel === 'view' ? 'default' : 'ghost'}
                            size="sm"
                            onClick={() => updatePermissionMutation.mutate({
                              layerId: permission.layerId,
                              permissionLevel: 'view'
                            })}
                            disabled={isLoading || permission.permissionLevel === 'view'}
                            data-testid={`button-view-${permission.layerId}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant={permission.permissionLevel === 'edit' ? 'default' : 'ghost'}
                            size="sm"
                            onClick={() => updatePermissionMutation.mutate({
                              layerId: permission.layerId,
                              permissionLevel: 'edit'
                            })}
                            disabled={isLoading || permission.permissionLevel === 'edit'}
                            data-testid={`button-edit-${permission.layerId}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
