import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useFieldPermissions, filterHiddenFields } from '@/hooks/useFieldPermissions';
import type { MapLayer, LayerFilter } from '@shared/schema';
import { Plus, Trash2, Share2 } from 'lucide-react';

interface LayerPropertiesModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  layer: MapLayer | null;
  layerData: any; // GeoJSON feature collection
  onShareLayer?: (layer: MapLayer) => void; // Optional share handler
}

// Color ramps for graduated symbology
const COLOR_RAMPS = {
  blues: ['#f7fbff', '#deebf7', '#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#084594'],
  greens: ['#f7fcf5', '#e5f5e0', '#c7e9c0', '#a1d99b', '#74c476', '#41ab5d', '#238b45', '#005a32'],
  reds: ['#fff5f0', '#fee0d2', '#fcbba1', '#fc9272', '#fb6a4a', '#ef3b2c', '#cb181d', '#99000d'],
  oranges: ['#fff5eb', '#fee6ce', '#fdd0a2', '#fdae6b', '#fd8d3c', '#f16913', '#d94801', '#8c2d04'],
  purples: ['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'],
  'red-yellow-green': ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63', '#1a9850'],
  'spectral': ['#9e0142', '#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#e6f598', '#abdda4', '#66c2a5', '#3288bd', '#5e4fa2'],
};

export default function LayerPropertiesModal({ open, onOpenChange, layer, layerData, onShareLayer }: LayerPropertiesModalProps) {
  const [activeTab, setActiveTab] = useState('symbology');
  
  // Symbology state
  const [symbologyType, setSymbologyType] = useState(layer?.symbologyType || 'single');
  const [fillColor, setFillColor] = useState(layer?.color || '#3498db');
  const [borderColor, setBorderColor] = useState('#2980b9');
  const [fillOpacity, setFillOpacity] = useState(0.5);
  const [borderWidth, setBorderWidth] = useState(2);
  
  // Graduated symbology state
  const [gradField, setGradField] = useState('');
  const [gradMethod, setGradMethod] = useState<'equal' | 'quantile' | 'natural'>('quantile');
  const [gradClasses, setGradClasses] = useState(5);
  const [gradColorRamp, setGradColorRamp] = useState('blues');
  
  // Categorized symbology state
  const [catField, setCatField] = useState('');
  const [catColors, setCatColors] = useState<Record<string, string>>({});

  // Label state
  const [labelsEnabled, setLabelsEnabled] = useState(false);
  const [labelField, setLabelField] = useState('');
  const [labelFontSize, setLabelFontSize] = useState(12);
  const [labelColor, setLabelColor] = useState('#000000');
  const [labelShowBackground, setLabelShowBackground] = useState(true);
  const [labelBackgroundColor, setLabelBackgroundColor] = useState('#ffffff');

  // Popup state
  const [popupsEnabled, setPopupsEnabled] = useState(false);
  const [popupFields, setPopupFields] = useState<string[]>([]);
  const [popupTemplate, setPopupTemplate] = useState<'default' | 'table' | 'card'>('default');
  const [popupMaxWidth, setPopupMaxWidth] = useState(300);
  const [popupMaxFieldLength, setPopupMaxFieldLength] = useState(50);

  // Extract numeric fields from layer data for graduated symbology
  const [numericFields, setNumericFields] = useState<string[]>([]);
  const [categoricalFields, setCategoricalFields] = useState<string[]>([]);

  useEffect(() => {
    if (layerData?.features?.length > 0) {
      const sampleProps = layerData.features[0].properties || {};
      const numeric: string[] = [];
      const categorical: string[] = [];
      
      Object.entries(sampleProps).forEach(([key, value]) => {
        if (typeof value === 'number' || !isNaN(Number(value))) {
          numeric.push(key);
        }
        categorical.push(key);
      });
      
      setNumericFields(numeric);
      setCategoricalFields(categorical);
    }
  }, [layerData]);

  // Fetch field permissions for this layer
  const { data: fieldPermissions } = useFieldPermissions(
    layer?.id || '',
    categoricalFields,
    !!layer?.id && categoricalFields.length > 0
  );

  // Apply field permissions - exclude hidden fields from all configurations
  const visibleCategoricalFields = useMemo(() => {
    return filterHiddenFields(categoricalFields, fieldPermissions);
  }, [categoricalFields, fieldPermissions]);

  // Clean up hidden fields from state when permissions change
  useEffect(() => {
    if (!fieldPermissions) return;

    // Reset catField if it's now hidden
    if (catField && !visibleCategoricalFields.includes(catField)) {
      setCatField('');
      setCatColors({});
    }

    // Reset labelField if it's now hidden
    if (labelField && !visibleCategoricalFields.includes(labelField)) {
      setLabelField('');
    }

    // Filter out hidden fields from popupFields
    if (popupFields.length > 0) {
      const filteredPopupFields = popupFields.filter(field =>
        visibleCategoricalFields.includes(field)
      );
      if (filteredPopupFields.length !== popupFields.length) {
        setPopupFields(filteredPopupFields);
      }
    }
  }, [visibleCategoricalFields, catField, labelField, popupFields]);

  // FIXED: Reset ALL state when layer changes or modal opens
  useEffect(() => {
    if (!layer || !open) return;

    // Reset to defaults first
    setSymbologyType(layer.symbologyType || 'single');
    setFillColor(layer.color || '#3498db');
    setBorderColor('#2980b9');
    setFillOpacity(0.5);
    setBorderWidth(2);
    setGradField('');
    setGradMethod('quantile');
    setGradClasses(5);
    setGradColorRamp('blues');
    setCatField('');
    setCatColors({});
    
    // Reset label defaults
    setLabelsEnabled(layer.labelsEnabled || false);
    setLabelField('');
    setLabelFontSize(12);
    setLabelColor('#000000');
    setLabelShowBackground(true);
    setLabelBackgroundColor('#ffffff');
    
    // Reset popup defaults
    setPopupsEnabled(layer.popupsEnabled || false);
    setPopupFields([]);
    setPopupTemplate('default');
    setPopupMaxWidth(300);
    setPopupMaxFieldLength(50);

    // Then apply stored config if exists
    if (layer.symbologyConfig) {
      const config = layer.symbologyConfig as any;
      if (config.fillColor) setFillColor(config.fillColor);
      if (config.borderColor) setBorderColor(config.borderColor);
      if (config.fillOpacity !== undefined) setFillOpacity(config.fillOpacity);
      if (config.borderWidth !== undefined) setBorderWidth(config.borderWidth);
      if (config.gradField) setGradField(config.gradField);
      if (config.gradMethod) setGradMethod(config.gradMethod);
      if (config.gradClasses) setGradClasses(config.gradClasses);
      if (config.gradColorRamp) setGradColorRamp(config.gradColorRamp);
      if (config.catField) setCatField(config.catField);
      if (config.catColors) setCatColors(config.catColors);
    }
    
    // Apply stored label config if exists
    if (layer.labelConfig) {
      const config = layer.labelConfig as any;
      if (config.labelField) setLabelField(config.labelField);
      if (config.fontSize !== undefined) setLabelFontSize(config.fontSize);
      if (config.color) setLabelColor(config.color);
      if (config.showBackground !== undefined) setLabelShowBackground(config.showBackground);
      if (config.backgroundColor) setLabelBackgroundColor(config.backgroundColor);
    }
    
    // Apply stored popup config if exists
    if (layer.popupConfig) {
      const config = layer.popupConfig as any;
      if (config.fields) setPopupFields(config.fields);
      if (config.template) setPopupTemplate(config.template);
      if (config.maxWidth !== undefined) setPopupMaxWidth(config.maxWidth);
      if (config.maxFieldLength !== undefined) setPopupMaxFieldLength(config.maxFieldLength);
    }
  }, [layer, open]);

  // Classification algorithms (FIXED: Handle sparse datasets)
  const classifyValues = (values: number[], method: 'equal' | 'quantile' | 'natural', numClasses: number): number[] => {
    const sorted = [...values].sort((a, b) => a - b);
    const breaks: number[] = [];
    
    // GUARD: Handle sparse datasets (when features < classes)
    if (sorted.length < numClasses) {
      // Return breaks between each unique value
      for (let i = 1; i < sorted.length; i++) {
        breaks.push((sorted[i - 1] + sorted[i]) / 2);
      }
      return breaks;
    }
    
    if (method === 'equal') {
      // Equal Interval
      const min = sorted[0];
      const max = sorted[sorted.length - 1];
      const interval = (max - min) / numClasses;
      for (let i = 1; i < numClasses; i++) {
        breaks.push(min + interval * i);
      }
    } else if (method === 'quantile') {
      // Quantile (equal count)
      for (let i = 1; i < numClasses; i++) {
        const index = Math.floor((sorted.length * i) / numClasses);
        breaks.push(sorted[index]);
      }
    } else if (method === 'natural') {
      // Natural Breaks (Jenks) - simplified implementation
      const numPerClass = Math.floor(sorted.length / numClasses);
      // Guard against zero division
      if (numPerClass === 0) {
        return classifyValues(values, 'quantile', numClasses);
      }
      for (let i = 1; i < numClasses; i++) {
        breaks.push(sorted[i * numPerClass]);
      }
    }
    
    return breaks;
  };

  // Get unique values for categorized symbology
  const getUniqueValues = (field: string): string[] => {
    if (!layerData?.features) return [];
    const values = new Set<string>();
    layerData.features.forEach((f: any) => {
      if (f.properties?.[field] !== undefined) {
        values.add(String(f.properties[field]));
      }
    });
    return Array.from(values).sort();
  };

  // Generate default colors for categories
  const generateCategoryColors = (values: string[]) => {
    const colors: Record<string, string> = {};
    const palette = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#34495e', '#e67e22'];
    values.forEach((val, idx) => {
      colors[val] = palette[idx % palette.length];
    });
    setCatColors(colors);
  };

  // Save symbology, label, and popup configuration
  const updateSymbology = useMutation({
    mutationFn: async () => {
      if (!layer) return;
      
      const symbologyConfig = {
        fillColor,
        borderColor,
        fillOpacity,
        borderWidth,
        gradField,
        gradMethod,
        gradClasses,
        gradColorRamp,
        catField,
        catColors,
      };

      const labelConfig = {
        labelField,
        fontSize: labelFontSize,
        color: labelColor,
        showBackground: labelShowBackground,
        backgroundColor: labelBackgroundColor,
      };

      const popupConfig = {
        fields: popupFields,
        template: popupTemplate,
        maxWidth: popupMaxWidth,
        maxFieldLength: popupMaxFieldLength,
      };

      return apiRequest('PATCH', `/api/layers/${layer.id}`, {
        symbologyType,
        symbologyConfig,
        labelsEnabled,
        labelConfig,
        popupsEnabled,
        popupConfig,
        color: fillColor, // Update main color for layer list
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layers'] });
      onOpenChange(false);
    },
  });

  if (!layer) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Layer Properties: {layer.layerName}</DialogTitle>
          <DialogDescription>
            Configure symbology, labels, and popup settings for this layer
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="symbology" data-testid="tab-symbology">Symbology</TabsTrigger>
            <TabsTrigger value="labels" data-testid="tab-labels">Labels</TabsTrigger>
            <TabsTrigger value="popups" data-testid="tab-popups">iTool / Popups</TabsTrigger>
          </TabsList>

          <TabsContent value="symbology" className="space-y-4 mt-4">
            {/* Symbology Type Selection */}
            <div className="grid gap-2">
              <Label>Symbology Type</Label>
              <Select value={symbologyType} onValueChange={setSymbologyType}>
                <SelectTrigger data-testid="select-symbology-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single Symbol</SelectItem>
                  <SelectItem value="graduated">Graduated (Choropleth)</SelectItem>
                  <SelectItem value="categorized">Categorized (Unique Values)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Single Symbol Controls */}
            {symbologyType === 'single' && (
              <div className="space-y-4 p-4 border rounded-md">
                <h3 className="font-semibold">Single Symbol Settings</h3>
                
                <div className="grid gap-2">
                  <Label htmlFor="fill-color">Fill Color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="fill-color"
                      type="color"
                      value={fillColor}
                      onChange={(e) => setFillColor(e.target.value)}
                      className="w-20 h-9 cursor-pointer"
                      data-testid="input-fill-color"
                    />
                    <Input
                      type="text"
                      value={fillColor}
                      onChange={(e) => setFillColor(e.target.value)}
                      className="flex-1"
                      placeholder="#3498db"
                    />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="border-color">Border Color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="border-color"
                      type="color"
                      value={borderColor}
                      onChange={(e) => setBorderColor(e.target.value)}
                      className="w-20 h-9 cursor-pointer"
                      data-testid="input-border-color"
                    />
                    <Input
                      type="text"
                      value={borderColor}
                      onChange={(e) => setBorderColor(e.target.value)}
                      className="flex-1"
                      placeholder="#2980b9"
                    />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label>Fill Opacity: {fillOpacity.toFixed(2)}</Label>
                  <Slider
                    value={[fillOpacity]}
                    onValueChange={(vals) => setFillOpacity(vals[0])}
                    min={0}
                    max={1}
                    step={0.05}
                    data-testid="slider-fill-opacity"
                  />
                </div>

                <div className="grid gap-2">
                  <Label>Border Width: {borderWidth}px</Label>
                  <Slider
                    value={[borderWidth]}
                    onValueChange={(vals) => setBorderWidth(vals[0])}
                    min={0}
                    max={5}
                    step={0.5}
                    data-testid="slider-border-width"
                  />
                </div>
              </div>
            )}

            {/* Graduated Symbol Controls */}
            {symbologyType === 'graduated' && (
              <div className="space-y-4 p-4 border rounded-md">
                <h3 className="font-semibold">Graduated Symbology (Choropleth)</h3>
                
                <div className="grid gap-2">
                  <Label>Value Field</Label>
                  <Select value={gradField} onValueChange={setGradField}>
                    <SelectTrigger data-testid="select-grad-field">
                      <SelectValue placeholder="Select numeric field..." />
                    </SelectTrigger>
                    <SelectContent>
                      {numericFields
                        .filter(field => field && field.trim() !== '')
                        .map(field => (
                          <SelectItem key={field} value={field}>{field}</SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label>Classification Method</Label>
                  <Select value={gradMethod} onValueChange={(val: any) => setGradMethod(val)}>
                    <SelectTrigger data-testid="select-grad-method">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equal">Equal Interval</SelectItem>
                      <SelectItem value="quantile">Quantile (Equal Count)</SelectItem>
                      <SelectItem value="natural">Natural Breaks (Jenks)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label>Number of Classes: {gradClasses}</Label>
                  <Slider
                    value={[gradClasses]}
                    onValueChange={(vals) => setGradClasses(vals[0])}
                    min={3}
                    max={9}
                    step={1}
                    data-testid="slider-grad-classes"
                  />
                </div>

                <div className="grid gap-2">
                  <Label>Color Ramp</Label>
                  <Select value={gradColorRamp} onValueChange={setGradColorRamp}>
                    <SelectTrigger data-testid="select-color-ramp">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(COLOR_RAMPS).map(ramp => (
                        <SelectItem key={ramp} value={ramp}>
                          {ramp.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {gradField && layerData && (
                  <div className="p-3 bg-muted rounded-md">
                    <h4 className="text-sm font-semibold mb-2">Preview Legend</h4>
                    {(() => {
                      const values = layerData.features
                        .map((f: any) => Number(f.properties?.[gradField]))
                        .filter((v: number) => !isNaN(v));
                      
                      if (values.length === 0) return <p className="text-sm text-muted-foreground">No valid numeric values</p>;
                      
                      const breaks = classifyValues(values, gradMethod, gradClasses);
                      const colors = COLOR_RAMPS[gradColorRamp as keyof typeof COLOR_RAMPS].slice(0, gradClasses);
                      
                      return (
                        <div className="space-y-1">
                          {colors.map((color, idx) => {
                            const min = idx === 0 ? Math.min(...values) : breaks[idx - 1];
                            const max = idx === colors.length - 1 ? Math.max(...values) : breaks[idx];
                            return (
                              <div key={idx} className="flex items-center gap-2 text-xs">
                                <div className="w-6 h-6 rounded border" style={{ backgroundColor: color }} />
                                <span>{min.toFixed(2)} - {max.toFixed(2)}</span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}

            {/* Categorized Symbol Controls */}
            {symbologyType === 'categorized' && (
              <div className="space-y-4 p-4 border rounded-md">
                <h3 className="font-semibold">Categorized Symbology (Unique Values)</h3>
                
                <div className="grid gap-2">
                  <Label>Category Field</Label>
                  <Select 
                    value={catField} 
                    onValueChange={(field) => {
                      setCatField(field);
                      const values = getUniqueValues(field);
                      generateCategoryColors(values);
                    }}
                  >
                    <SelectTrigger data-testid="select-cat-field">
                      <SelectValue placeholder="Select field..." />
                    </SelectTrigger>
                    <SelectContent>
                      {visibleCategoricalFields
                        .filter(field => field && field.trim() !== '')
                        .map(field => (
                          <SelectItem key={field} value={field}>{field}</SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                {catField && Object.keys(catColors).length > 0 && (
                  <div className="space-y-2">
                    <Label>Category Colors</Label>
                    <div className="max-h-64 overflow-y-auto space-y-2 p-3 bg-muted rounded-md">
                      {Object.entries(catColors).map(([value, color]) => (
                        <div key={value} className="flex items-center gap-2">
                          <Input
                            type="color"
                            value={color}
                            onChange={(e) => setCatColors({ ...catColors, [value]: e.target.value })}
                            className="w-16 h-8 cursor-pointer"
                          />
                          <span className="text-sm flex-1">{value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="labels" className="space-y-4 mt-4">
            <div className="space-y-4 p-4 border rounded-md">
              <h3 className="font-semibold">Feature Labels</h3>
              
              {/* Enable Labels Toggle */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="labels-enabled">Enable Labels</Label>
                  <p className="text-xs text-muted-foreground">Show feature labels on the map</p>
                </div>
                <Switch
                  id="labels-enabled"
                  checked={labelsEnabled}
                  onCheckedChange={setLabelsEnabled}
                  data-testid="switch-labels-enabled"
                />
              </div>

              {labelsEnabled && (
                <>
                  {/* Label Field Selection */}
                  <div className="grid gap-2">
                    <Label>Label Field</Label>
                    <Select value={labelField} onValueChange={setLabelField}>
                      <SelectTrigger data-testid="select-label-field">
                        <SelectValue placeholder="Select field to display..." />
                      </SelectTrigger>
                      <SelectContent>
                        {visibleCategoricalFields
                          .filter(field => field && field.trim() !== '')
                          .map(field => (
                            <SelectItem key={field} value={field}>{field}</SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Font Size Slider */}
                  <div className="grid gap-2">
                    <Label>Font Size: {labelFontSize}px</Label>
                    <Slider
                      value={[labelFontSize]}
                      onValueChange={(vals) => setLabelFontSize(vals[0])}
                      min={10}
                      max={18}
                      step={1}
                      data-testid="slider-label-font-size"
                    />
                  </div>

                  {/* Font Color */}
                  <div className="grid gap-2">
                    <Label htmlFor="label-color">Font Color</Label>
                    <div className="flex gap-2">
                      <Input
                        id="label-color"
                        type="color"
                        value={labelColor}
                        onChange={(e) => setLabelColor(e.target.value)}
                        className="w-20 h-9 cursor-pointer"
                        data-testid="input-label-color"
                      />
                      <Input
                        type="text"
                        value={labelColor}
                        onChange={(e) => setLabelColor(e.target.value)}
                        className="flex-1"
                        placeholder="#000000"
                      />
                    </div>
                  </div>

                  {/* Show Background Toggle */}
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="label-background">Show Background</Label>
                      <p className="text-xs text-muted-foreground">Display background behind text</p>
                    </div>
                    <Switch
                      id="label-background"
                      checked={labelShowBackground}
                      onCheckedChange={setLabelShowBackground}
                      data-testid="switch-label-background"
                    />
                  </div>

                  {/* Background Color */}
                  {labelShowBackground && (
                    <div className="grid gap-2">
                      <Label htmlFor="label-bg-color">Background Color</Label>
                      <div className="flex gap-2">
                        <Input
                          id="label-bg-color"
                          type="color"
                          value={labelBackgroundColor}
                          onChange={(e) => setLabelBackgroundColor(e.target.value)}
                          className="w-20 h-9 cursor-pointer"
                          data-testid="input-label-bg-color"
                        />
                        <Input
                          type="text"
                          value={labelBackgroundColor}
                          onChange={(e) => setLabelBackgroundColor(e.target.value)}
                          className="flex-1"
                          placeholder="#ffffff"
                        />
                      </div>
                    </div>
                  )}

                  {/* Preview */}
                  {labelField && (
                    <div className="p-3 bg-muted rounded-md">
                      <h4 className="text-sm font-semibold mb-2">Preview</h4>
                      <div 
                        className="inline-block px-2 py-1 rounded"
                        style={{
                          fontSize: `${labelFontSize}px`,
                          color: labelColor,
                          backgroundColor: labelShowBackground ? labelBackgroundColor : 'transparent',
                          border: labelShowBackground ? 'none' : `1px solid ${labelColor}`,
                        }}
                      >
                        Sample Label
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </TabsContent>

          <TabsContent value="popups" className="space-y-4 mt-4">
            <div className="space-y-4 p-4 border rounded-md">
              <h3 className="font-semibold">iTool / Popup Configuration</h3>
              
              {/* Enable Popups Toggle */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="popups-enabled">Enable Popups</Label>
                  <p className="text-xs text-muted-foreground">Show popup on feature click</p>
                </div>
                <Switch
                  id="popups-enabled"
                  checked={popupsEnabled}
                  onCheckedChange={setPopupsEnabled}
                  data-testid="switch-popups-enabled"
                />
              </div>

              {popupsEnabled && (
                <>
                  {/* Field Selection */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Fields to Display</Label>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setPopupFields([...visibleCategoricalFields])}
                          data-testid="button-select-all-fields"
                        >
                          Select All
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setPopupFields([])}
                          data-testid="button-deselect-all-fields"
                        >
                          Deselect All
                        </Button>
                      </div>
                    </div>

                    <div className="max-h-48 overflow-y-auto border rounded-md p-3 space-y-2">
                      {visibleCategoricalFields.map(field => (
                        <div key={field} className="flex items-center space-x-2">
                          <Checkbox
                            id={`popup-field-${field}`}
                            checked={popupFields.includes(field)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setPopupFields([...popupFields, field]);
                              } else {
                                setPopupFields(popupFields.filter(f => f !== field));
                              }
                            }}
                            data-testid={`checkbox-popup-field-${field}`}
                          />
                          <label
                            htmlFor={`popup-field-${field}`}
                            className="text-sm font-medium leading-none cursor-pointer"
                          >
                            {field}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Template Selection */}
                  <div className="grid gap-2">
                    <Label>Popup Template</Label>
                    <Select value={popupTemplate} onValueChange={(val: any) => setPopupTemplate(val)}>
                      <SelectTrigger data-testid="select-popup-template">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default (Key: Value)</SelectItem>
                        <SelectItem value="table">Table Format</SelectItem>
                        <SelectItem value="card">Card Format</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Advanced Settings */}
                  <div className="space-y-4 pt-4 border-t">
                    <h4 className="font-semibold text-sm">Advanced Settings</h4>

                    {/* Max Width */}
                    <div className="grid gap-2">
                      <Label>Max Width: {popupMaxWidth}px</Label>
                      <Slider
                        value={[popupMaxWidth]}
                        onValueChange={(vals) => setPopupMaxWidth(vals[0])}
                        min={200}
                        max={600}
                        step={50}
                        data-testid="slider-popup-max-width"
                      />
                    </div>

                    {/* Max Field Length */}
                    <div className="grid gap-2">
                      <Label>Max Field Length: {popupMaxFieldLength} chars</Label>
                      <Slider
                        value={[popupMaxFieldLength]}
                        onValueChange={(vals) => setPopupMaxFieldLength(vals[0])}
                        min={20}
                        max={200}
                        step={10}
                        data-testid="slider-popup-max-field-length"
                      />
                      <p className="text-xs text-muted-foreground">
                        Field values longer than this will be truncated
                      </p>
                    </div>
                  </div>

                  {/* Preview */}
                  {popupFields.length > 0 && (
                    <div className="p-3 bg-muted rounded-md">
                      <h4 className="text-sm font-semibold mb-2">Preview</h4>
                      <div 
                        className="bg-background border rounded p-2 text-sm"
                        style={{ maxWidth: `${popupMaxWidth}px` }}
                      >
                        {popupTemplate === 'default' && (
                          <div className="space-y-1">
                            {popupFields.slice(0, 3).map(field => (
                              <div key={field}>
                                <strong>{field}:</strong> Sample value
                              </div>
                            ))}
                            {popupFields.length > 3 && <div className="text-muted-foreground">+ {popupFields.length - 3} more fields</div>}
                          </div>
                        )}
                        {popupTemplate === 'table' && (
                          <table className="w-full text-xs">
                            <tbody>
                              {popupFields.slice(0, 3).map(field => (
                                <tr key={field} className="border-b last:border-0">
                                  <td className="font-semibold py-1 pr-2">{field}</td>
                                  <td className="py-1">Sample value</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                        {popupTemplate === 'card' && (
                          <div className="space-y-2">
                            {popupFields.slice(0, 2).map(field => (
                              <div key={field} className="bg-muted p-2 rounded">
                                <div className="text-xs text-muted-foreground">{field}</div>
                                <div className="font-medium">Sample value</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between gap-2 mt-4">
          {/* Share button on the left */}
          {onShareLayer && layer && (
            <Button
              variant="secondary"
              onClick={() => onShareLayer(layer)}
              data-testid="button-share-layer"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share Layer
            </Button>
          )}
          {!onShareLayer && <div />} {/* Spacer when share button is not available */}
          
          {/* Cancel and Save buttons on the right */}
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel">
              Cancel
            </Button>
            <Button 
              onClick={() => updateSymbology.mutate()} 
              disabled={updateSymbology.isPending}
              data-testid="button-save-symbology"
            >
              {updateSymbology.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
