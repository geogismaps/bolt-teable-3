import { useState } from 'react';
import { AlertCircle, Copy, Check, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

export default function OAuthSetupBanner() {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);
  
  const redirectUri = `${window.location.origin}/api/auth/google/callback`;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(redirectUri);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <Collapsible open={expanded} onOpenChange={setExpanded}>
      <Alert variant="default" className="mb-4 border-yellow-500/50 bg-yellow-50 dark:bg-yellow-950/20">
        <AlertCircle className="h-4 w-4 text-yellow-600" />
        <AlertTitle className="text-yellow-900 dark:text-yellow-100">
          Google OAuth Setup Required
        </AlertTitle>
        <AlertDescription className="text-yellow-800 dark:text-yellow-200">
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="p-0 h-auto font-normal text-yellow-900 dark:text-yellow-100 hover:underline"
            >
              {expanded ? 'Hide' : 'Show'} setup instructions
            </Button>
          </CollapsibleTrigger>
        </AlertDescription>

        <CollapsibleContent className="mt-3 space-y-3">
          <div className="text-sm text-yellow-900 dark:text-yellow-100">
            <p className="mb-2 font-semibold">Follow these steps:</p>
            <ol className="list-decimal list-inside space-y-2 ml-2">
              <li>
                Go to{' '}
                <a
                  href="https://console.cloud.google.com/apis/credentials"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                >
                  Google Cloud Console
                  <ExternalLink className="h-3 w-3" />
                </a>
              </li>
              <li>Select your OAuth 2.0 Client ID</li>
              <li>
                Under "Authorized redirect URIs", click "ADD URI"
              </li>
              <li>
                Paste this exact URL:
                <div className="mt-2 flex items-center gap-2 bg-white dark:bg-gray-900 p-2 rounded border border-yellow-300 dark:border-yellow-700">
                  <code className="flex-1 text-xs text-gray-900 dark:text-gray-100 break-all font-mono">
                    {redirectUri}
                  </code>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyToClipboard}
                    className="shrink-0"
                    data-testid="button-copy-redirect-uri"
                  >
                    {copied ? (
                      <Check className="h-3 w-3 text-green-600" />
                    ) : (
                      <Copy className="h-3 w-3" />
                    )}
                  </Button>
                </div>
              </li>
              <li>Click "Save" in Google Cloud Console</li>
              <li>Return here and click "Connect Google Sheets"</li>
            </ol>
          </div>
        </CollapsibleContent>
      </Alert>
    </Collapsible>
  );
}
