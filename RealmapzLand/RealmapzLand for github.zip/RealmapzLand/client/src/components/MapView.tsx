import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import { useEffect, useState } from 'react';
import 'leaflet/dist/leaflet.css';
import type { FeatureCollection } from 'geojson';
import L from 'leaflet';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface Layer {
  id: string;
  name: string;
  visible: boolean;
  data: FeatureCollection;
  color?: string;
}

interface MapViewProps {
  layers: Layer[];
  onFeatureClick?: (feature: any) => void;
}

function MapController({ layers }: { layers: Layer[] }) {
  const map = useMap();
  
  useEffect(() => {
    const visibleLayers = layers.filter(l => l.visible && l.data.features.length > 0);
    if (visibleLayers.length > 0) {
      const allFeatures = visibleLayers.flatMap(l => l.data.features);
      if (allFeatures.length > 0) {
        const geojsonLayer = L.geoJSON(allFeatures as any);
        map.fitBounds(geojsonLayer.getBounds(), { padding: [50, 50] });
      }
    }
  }, [layers, map]);
  
  return null;
}

export default function MapView({ layers, onFeatureClick }: MapViewProps) {
  const [center] = useState<[number, number]>([40.7128, -74.0060]);
  const [zoom] = useState(12);

  const getFeatureStyle = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    return {
      color: layer?.color || '#3b82f6',
      weight: 2,
      opacity: 0.8,
      fillOpacity: 0.3,
    };
  };

  return (
    <div className="h-full w-full" data-testid="map-container">
      <MapContainer
        center={center}
        zoom={zoom}
        className="h-full w-full"
        zoomControl={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {layers
          .filter(layer => layer.visible)
          .map(layer => (
            <GeoJSON
              key={layer.id}
              data={layer.data}
              style={() => getFeatureStyle(layer.id)}
              onEachFeature={(feature, leafletLayer) => {
                leafletLayer.on('click', () => {
                  onFeatureClick?.(feature);
                });
              }}
            />
          ))}
        
        <MapController layers={layers} />
      </MapContainer>
    </div>
  );
}
