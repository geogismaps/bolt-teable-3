import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, Loader2, Shield } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function SuperAdminBootstrap() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    companyName: '',
    adminEmail: '',
    adminName: '',
    adminPassword: '',
  });
  const [success, setSuccess] = useState(false);

  const bootstrapMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest('POST', '/api/superadmin/bootstrap', data);
      return response.json();
    },
    onSuccess: (data) => {
      setSuccess(true);
      toast({
        title: 'Bootstrap successful',
        description: data.message || 'Organization and admin user created successfully',
      });
    },
    onError: (error: any) => {
      toast({
        variant: 'destructive',
        title: 'Bootstrap failed',
        description: error.message || 'Failed to create organization',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    bootstrapMutation.mutate(formData);
  };

  const handleChange = (field: keyof typeof formData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [field]: e.target.value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/20 p-4">
      <div className="w-full max-w-md space-y-4">
        <Alert variant="destructive" data-testid="alert-warning">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="font-medium">
            <strong>Development/Testing Only!</strong> This bootstrap page creates the first organization without authentication.
            Required env var: <code className="bg-destructive/20 px-1 rounded">ENABLE_SUPERADMIN_BOOTSTRAP=true</code>.
            Disable before production deployment!
          </AlertDescription>
        </Alert>

        <Card data-testid="card-bootstrap">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <CardTitle>Superadmin Bootstrap</CardTitle>
            </div>
            <CardDescription>
              Create the first organization and admin user to start testing
            </CardDescription>
          </CardHeader>
          <CardContent>
            {success ? (
              <div className="space-y-4">
                <Alert data-testid="alert-success">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription>
                    Organization and admin user created successfully! You can now log in at{' '}
                    <a href="/login" className="underline font-medium">
                      /login
                    </a>
                  </AlertDescription>
                </Alert>
                
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>Next steps:</p>
                  <ol className="list-decimal list-inside space-y-1">
                    <li>Log in with the admin credentials you created</li>
                    <li>Test the OAuth and Google Drive Picker workflow</li>
                    <li>Remove or disable this bootstrap page before production</li>
                  </ol>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="company-name">Company Name *</Label>
                  <Input
                    id="company-name"
                    data-testid="input-company-name"
                    value={formData.companyName}
                    onChange={handleChange('companyName')}
                    placeholder="Acme Corporation"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-name">Admin Full Name *</Label>
                  <Input
                    id="admin-name"
                    data-testid="input-admin-name"
                    value={formData.adminName}
                    onChange={handleChange('adminName')}
                    placeholder="John Doe"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-email">Admin Email *</Label>
                  <Input
                    id="admin-email"
                    data-testid="input-admin-email"
                    type="email"
                    value={formData.adminEmail}
                    onChange={handleChange('adminEmail')}
                    placeholder="admin@example.com"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-password">Admin Password *</Label>
                  <Input
                    id="admin-password"
                    data-testid="input-admin-password"
                    type="password"
                    value={formData.adminPassword}
                    onChange={handleChange('adminPassword')}
                    placeholder="Strong password (min 6 characters)"
                    minLength={6}
                    required
                  />
                </div>

                <Button
                  type="submit"
                  data-testid="button-create-org"
                  className="w-full"
                  disabled={bootstrapMutation.isPending}
                >
                  {bootstrapMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    'Create Organization & Admin User'
                  )}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        <p className="text-xs text-center text-muted-foreground">
          This endpoint self-disables after the first organization is created
        </p>
      </div>
    </div>
  );
}
