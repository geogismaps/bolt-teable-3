import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Users, Building2, CreditCard, Activity, Settings, Plus, Copy, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { PageShell, PageHeader } from "@/components/layout";

interface Organization {
  id: string;
  name: string;
  billing_plan: string;
  max_users: number;
  max_connections: number;
  stripe_customer_id: string | null;
  created_at: string;
}

interface OrganizationFeature {
  organization_id: string;
  feature_key: string;
  enabled: boolean;
  feature_name?: string;
  feature_tier?: string;
}

interface FeatureDefinition {
  key: string;
  name: string;
  description: string;
  tier: string;
}

export default function SuperAdminDashboard() {
  const { toast } = useToast();
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null);
  const [isCreateOrgDialogOpen, setIsCreateOrgDialogOpen] = useState(false);
  const [orgFormData, setOrgFormData] = useState({
    companyName: '',
    adminEmail: '',
    adminName: '',
    adminPassword: '',
  });

  // Generate cryptographically secure random password
  const generatePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    const array = new Uint8Array(12);
    crypto.getRandomValues(array);
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(array[i] % chars.length);
    }
    return password;
  };

  // Fetch all organizations
  const { data: organizations, isLoading: orgsLoading } = useQuery<Organization[]>({
    queryKey: ['/api/supabase/organizations'],
  });

  // Fetch feature definitions
  const { data: featureDefinitions } = useQuery<FeatureDefinition[]>({
    queryKey: ['/api/supabase/features'],
  });

  // Fetch features for selected organization
  const { data: orgFeatures } = useQuery<OrganizationFeature[]>({
    queryKey: ['/api/supabase/organizations', selectedOrgId, 'features'],
    enabled: !!selectedOrgId,
  });

  // Create organization mutation
  const createOrgMutation = useMutation({
    mutationFn: async (data: typeof orgFormData) => {
      const response = await apiRequest('POST', `/api/supabase/organizations`, {
        companyName: data.companyName,
        adminEmail: data.adminEmail,
        adminName: data.adminName,
        adminPassword: data.adminPassword,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/supabase/organizations'] });
      toast({
        title: 'Organization created',
        description: 'New organization and admin user have been created successfully',
      });
      setIsCreateOrgDialogOpen(false);
      setOrgFormData({
        companyName: '',
        adminEmail: '',
        adminName: '',
        adminPassword: '',
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error creating organization',
        description: error.message,
      });
    },
  });

  // Toggle feature mutation
  const toggleFeatureMutation = useMutation({
    mutationFn: async ({ orgId, featureKey, enabled }: { orgId: string; featureKey: string; enabled: boolean }) => {
      const response = await apiRequest('PATCH', `/api/supabase/organizations/${orgId}/features/${featureKey}`, { enabled });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/supabase/organizations', selectedOrgId, 'features'] });
      toast({
        title: 'Feature updated',
        description: 'Feature flag has been updated successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const handleCreateOrg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgFormData.adminPassword) {
      const newPassword = generatePassword();
      setOrgFormData({ ...orgFormData, adminPassword: newPassword });
      return; // Will re-render with password populated
    }
    createOrgMutation.mutate(orgFormData);
  };

  const copyPassword = () => {
    navigator.clipboard.writeText(orgFormData.adminPassword);
    toast({
      title: 'Copied to clipboard',
      description: 'Admin password copied successfully',
    });
  };

  const selectedOrg = organizations?.find(o => o.id === selectedOrgId);

  const planColors: Record<string, string> = {
    free: 'bg-gray-500',
    basic: 'bg-blue-500',
    pro: 'bg-purple-500',
    enterprise: 'bg-amber-500',
  };

  return (
    <PageShell maxWidth="7xl">
      <PageHeader
        icon={Shield}
        title="Super Admin Dashboard"
        description="Manage all organizations, features, and billing"
        testId="heading-super-admin"
        actions={
          <>
            <Dialog open={isCreateOrgDialogOpen} onOpenChange={setIsCreateOrgDialogOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-create-org">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Organization
                </Button>
              </DialogTrigger>
              <DialogContent data-testid="dialog-create-org">
                <DialogHeader>
                  <DialogTitle>Create New Organization</DialogTitle>
                  <DialogDescription>
                    Set up a new organization and its first admin user
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateOrg}>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="companyName">Company Name</Label>
                      <Input
                        id="companyName"
                        placeholder="Acme Legal Group"
                        value={orgFormData.companyName}
                        onChange={(e) => setOrgFormData({ ...orgFormData, companyName: e.target.value })}
                        required
                        data-testid="input-company-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="adminEmail">Admin Email</Label>
                      <Input
                        id="adminEmail"
                        type="email"
                        placeholder="admin@acmelegal.com"
                        value={orgFormData.adminEmail}
                        onChange={(e) => setOrgFormData({ ...orgFormData, adminEmail: e.target.value })}
                        required
                        data-testid="input-admin-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="adminName">Admin Name</Label>
                      <Input
                        id="adminName"
                        placeholder="John Smith"
                        value={orgFormData.adminName}
                        onChange={(e) => setOrgFormData({ ...orgFormData, adminName: e.target.value })}
                        required
                        data-testid="input-admin-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="adminPassword">Admin Password</Label>
                      <div className="flex gap-2">
                        <Input
                          id="adminPassword"
                          type="text"
                          value={orgFormData.adminPassword}
                          onChange={(e) => setOrgFormData({ ...orgFormData, adminPassword: e.target.value })}
                          required
                          readOnly
                          data-testid="input-admin-password"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => setOrgFormData({ ...orgFormData, adminPassword: generatePassword() })}
                          data-testid="button-generate-password"
                        >
                          <Activity className="h-4 w-4" />
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={copyPassword}
                          disabled={!orgFormData.adminPassword}
                          data-testid="button-copy-password"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Click generate, then copy and share with admin securely
                      </p>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsCreateOrgDialogOpen(false);
                        setOrgFormData({
                          companyName: '',
                          adminEmail: '',
                          adminName: '',
                          adminPassword: '',
                        });
                      }}
                      data-testid="button-cancel-create-org"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createOrgMutation.isPending || !orgFormData.adminPassword}
                      data-testid="button-submit-create-org"
                    >
                      {createOrgMutation.isPending ? 'Creating...' : 'Create Organization'}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
            <Button variant="outline" data-testid="button-refresh-data">
              <Activity className="w-4 h-4 mr-2" />
              Refresh Data
            </Button>
          </>
        }
      />

      {/* Stats Overview */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Organizations</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="stat-total-orgs">
                {organizations?.length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="stat-active-users">
                {organizations?.reduce((sum, org) => sum + (org.max_users || 0), 0) || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Paid Plans</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="stat-paid-plans">
                {organizations?.filter(o => o.billing_plan !== 'free').length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Features</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="stat-total-features">
                {featureDefinitions?.length || 0}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Organizations List */}
          <Card>
            <CardHeader>
              <CardTitle>Organizations</CardTitle>
              <CardDescription>Select an organization to manage features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[600px] overflow-auto">
              {orgsLoading ? (
                <>
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </>
              ) : (
                organizations?.map((org) => (
                  <div
                    key={org.id}
                    className={`p-4 rounded-lg border cursor-pointer transition-colors hover-elevate ${
                      selectedOrgId === org.id ? 'border-primary bg-accent' : 'border-border'
                    }`}
                    onClick={() => setSelectedOrgId(org.id)}
                    data-testid={`org-card-${org.id}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h3 className="font-semibold" data-testid={`org-name-${org.id}`}>{org.name}</h3>
                        <div className="flex gap-2 items-center flex-wrap">
                          <Badge className={planColors[org.billing_plan]} data-testid={`org-plan-${org.id}`}>
                            {org.billing_plan}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {org.max_users} users • {org.max_connections} connections
                          </span>
                        </div>
                        {org.stripe_customer_id && (
                          <p className="text-xs text-muted-foreground">
                            Stripe: {org.stripe_customer_id.substring(0, 20)}...
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Feature Flags Management */}
          <Card>
            <CardHeader>
              <CardTitle>Feature Flags</CardTitle>
              <CardDescription>
                {selectedOrg ? `Managing features for ${selectedOrg.name}` : 'Select an organization to manage features'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[600px] overflow-auto">
              {!selectedOrgId ? (
                <div className="text-center text-muted-foreground py-8">
                  Select an organization to view and manage feature flags
                </div>
              ) : (
                featureDefinitions?.map((feature) => {
                  const orgFeature = orgFeatures?.find(f => f.feature_key === feature.key);
                  const isEnabled = orgFeature?.enabled || false;

                  return (
                    <div
                      key={feature.key}
                      className="flex items-center justify-between p-3 rounded-lg border"
                      data-testid={`feature-${feature.key}`}
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-sm">{feature.name}</h4>
                          <Badge variant="outline" className="text-xs">
                            {feature.tier}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{feature.description}</p>
                      </div>
                      <Switch
                        checked={isEnabled}
                        onCheckedChange={(enabled) => {
                          toggleFeatureMutation.mutate({
                            orgId: selectedOrgId,
                            featureKey: feature.key,
                            enabled,
                          });
                        }}
                        disabled={toggleFeatureMutation.isPending}
                        data-testid={`switch-${feature.key}`}
                      />
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>

        {/* Payment & Usage Details (Placeholder for future integration) */}
        {selectedOrg && (
          <Card>
            <CardHeader>
              <CardTitle>Payment & Usage Details</CardTitle>
              <CardDescription>Billing and resource usage for {selectedOrg.name}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Billing Plan</p>
                  <p className="text-lg font-semibold capitalize">{selectedOrg.billing_plan}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Max Users</p>
                  <p className="text-lg font-semibold">{selectedOrg.max_users}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Max Connections</p>
                  <p className="text-lg font-semibold">{selectedOrg.max_connections}</p>
                </div>
              </div>
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 Stripe integration can be added here for payment details, subscription status, and usage metrics
                </p>
              </div>
            </CardContent>
          </Card>
        )}
    </PageShell>
  );
}
