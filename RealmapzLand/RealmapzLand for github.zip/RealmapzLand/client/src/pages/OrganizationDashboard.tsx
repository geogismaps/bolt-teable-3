import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Map, Users, Shield, Settings, Database, Activity, Building2 } from "lucide-react";
import { PageShell, PageHeader } from "@/components/layout";

interface OrganizationStats {
  id: string;
  name: string;
  billing_plan: string;
  user_count: number;
  connection_count: number;
  layer_count: number;
}

interface FeatureSummary {
  feature_key: string;
  enabled: boolean;
  feature_name: string;
}

export default function OrganizationDashboard() {
  // Fetch current organization details
  const { data: orgStats, isLoading: statsLoading } = useQuery<OrganizationStats>({
    queryKey: ['/api/organization/stats'],
  });

  // Fetch enabled features
  const { data: enabledFeatures } = useQuery<FeatureSummary[]>({
    queryKey: ['/api/organization/features'],
  });

  const quickLinks = [
    {
      title: "Map View",
      description: "View and manage your GIS layers",
      icon: Map,
      href: "/",
      color: "text-blue-500",
      testId: "link-map-view"
    },
    {
      title: "Documents",
      description: "Manage your documents and files",
      icon: Database,
      href: "/documents",
      color: "text-green-500",
      testId: "link-documents"
    },
    {
      title: "Permissions",
      description: "Configure field-level permissions",
      icon: Shield,
      href: "/permissions",
      color: "text-purple-500",
      testId: "link-permissions"
    },
    {
      title: "Admin Dashboard",
      description: "Super admin features (admin only)",
      icon: Settings,
      href: "/admin",
      color: "text-orange-500",
      testId: "link-admin"
    },
  ];

  return (
    <PageShell maxWidth="7xl">
      <PageHeader
        icon={Building2}
        title="Organization Dashboard"
        description={statsLoading ? 'Loading...' : orgStats?.name || 'Your Organization'}
        testId="heading-org-dashboard"
      />

      {/* Organization Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Billing Plan</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <div className="text-2xl font-bold capitalize" data-testid="stat-billing-plan">
                  {orgStats?.billing_plan || 'Free'}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Team Members</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-12" />
              ) : (
                <div className="text-2xl font-bold" data-testid="stat-team-members">
                  {orgStats?.user_count || 0}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Connections</CardTitle>
              <Database className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-12" />
              ) : (
                <div className="text-2xl font-bold" data-testid="stat-connections">
                  {orgStats?.connection_count || 0}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Map Layers</CardTitle>
              <Map className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-12" />
              ) : (
                <div className="text-2xl font-bold" data-testid="stat-map-layers">
                  {orgStats?.layer_count || 0}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Links */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Navigate to key features and settings</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {quickLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <Card className="cursor-pointer hover-elevate transition-all" data-testid={link.testId}>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <link.icon className={`w-8 h-8 ${link.color}`} />
                        <div>
                          <CardTitle className="text-base">{link.title}</CardTitle>
                          <CardDescription className="text-xs">{link.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Enabled Features */}
        <Card>
          <CardHeader>
            <CardTitle>Enabled Features</CardTitle>
            <CardDescription>Features available for your organization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {enabledFeatures?.filter(f => f.enabled).length === 0 ? (
                <p className="text-sm text-muted-foreground">No features enabled</p>
              ) : (
                enabledFeatures?.filter(f => f.enabled).map((feature) => (
                  <Badge key={feature.feature_key} variant="secondary" data-testid={`feature-${feature.feature_key}`}>
                    {feature.feature_name}
                  </Badge>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Activity Feed (Placeholder) */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest actions and updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 rounded-lg border">
                <Activity className="w-4 h-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Activity logging coming soon</p>
                  <p className="text-xs text-muted-foreground">Track team actions and system events</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
    </PageShell>
  );
}
