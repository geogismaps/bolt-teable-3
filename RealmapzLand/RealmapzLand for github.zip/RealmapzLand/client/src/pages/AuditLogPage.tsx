import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileText, Calendar, User, Database, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { PageShell, PageHeader, PageSection } from '@/components/layout';

interface AuditLogEntry {
  id: string;
  user_id: string;
  layer_id: string;
  record_id: string;
  field_name: string;
  old_value: any;
  new_value: any;
  action: string;
  source_ip: string | null;
  session_id: string | null;
  user_agent: string | null;
  edited_at: string;
  user_username: string;
  user_email: string;
  layer_name: string;
}

export default function AuditLogPage() {
  // Filters
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [selectedLayer, setSelectedLayer] = useState<string>('');
  const [selectedField, setSelectedField] = useState<string>('');
  
  // Pagination
  const [page, setPage] = useState(0);
  const pageSize = 50;

  // Selected entry for detail view
  const [selectedEntry, setSelectedEntry] = useState<AuditLogEntry | null>(null);

  // Build query parameters
  const queryParams = new URLSearchParams();
  queryParams.set('limit', String(pageSize));
  queryParams.set('offset', String(page * pageSize));
  if (startDate) queryParams.set('startDate', new Date(startDate).toISOString());
  if (endDate) queryParams.set('endDate', new Date(endDate).toISOString());
  if (selectedUser) queryParams.set('userId', selectedUser);
  if (selectedLayer) queryParams.set('layerId', selectedLayer);
  if (selectedField) queryParams.set('fieldName', selectedField);

  // Fetch audit logs
  const { data: auditLogs = [], isLoading, refetch } = useQuery<AuditLogEntry[]>({
    queryKey: ['/api/audit-logs', queryParams.toString()],
    queryFn: async () => {
      const response = await fetch(`/api/audit-logs?${queryParams.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch audit logs');
      }
      return response.json();
    },
  });

  // Extract unique values for filters
  const uniqueUsers = useMemo(() => {
    const users = new Map<string, string>();
    auditLogs.forEach(log => {
      if (log.user_id && log.user_username) {
        users.set(log.user_id, log.user_username);
      }
    });
    return Array.from(users.entries());
  }, [auditLogs]);

  const uniqueLayers = useMemo(() => {
    const layers = new Map<string, string>();
    auditLogs.forEach(log => {
      if (log.layer_id && log.layer_name) {
        layers.set(log.layer_id, log.layer_name);
      }
    });
    return Array.from(layers.entries());
  }, [auditLogs]);

  const uniqueFields = useMemo(() => {
    const fields = new Set<string>();
    auditLogs.forEach(log => {
      if (log.field_name) {
        fields.add(log.field_name);
      }
    });
    return Array.from(fields);
  }, [auditLogs]);

  const resetFilters = () => {
    setStartDate('');
    setEndDate('');
    setSelectedUser('');
    setSelectedLayer('');
    setSelectedField('');
    setPage(0);
  };

  const formatValue = (value: any) => {
    if (value === null || value === undefined) return '(empty)';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  };

  return (
    <PageShell maxWidth="7xl">
      <PageHeader 
        icon={FileText}
        title="Audit Log"
        description="Track all data changes made to your organization's records"
        testId="heading-audit-log"
      />

      {/* Filters Card */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter audit logs by date, user, layer, or field</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {/* Date Range */}
            <div className="grid gap-2">
              <Label htmlFor="start-date">Start Date</Label>
              <Input
                id="start-date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                data-testid="input-start-date"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="end-date">End Date</Label>
              <Input
                id="end-date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                data-testid="input-end-date"
              />
            </div>

            {/* User Filter */}
            <div className="grid gap-2">
              <Label>User</Label>
              <Select value={selectedUser} onValueChange={setSelectedUser}>
                <SelectTrigger data-testid="select-user-filter">
                  <SelectValue placeholder="All users" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All users</SelectItem>
                  {uniqueUsers.map(([id, username]) => (
                    <SelectItem key={id} value={id}>{username}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Layer Filter */}
            <div className="grid gap-2">
              <Label>Layer</Label>
              <Select value={selectedLayer} onValueChange={setSelectedLayer}>
                <SelectTrigger data-testid="select-layer-filter">
                  <SelectValue placeholder="All layers" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All layers</SelectItem>
                  {uniqueLayers.map(([id, name]) => (
                    <SelectItem key={id} value={id}>{name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Field Filter */}
            <div className="grid gap-2">
              <Label>Field</Label>
              <Select value={selectedField} onValueChange={setSelectedField}>
                <SelectTrigger data-testid="select-field-filter">
                  <SelectValue placeholder="All fields" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All fields</SelectItem>
                  {uniqueFields.map(field => (
                    <SelectItem key={field} value={field}>{field}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={() => refetch()} variant="outline" size="sm" data-testid="button-refresh">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={resetFilters} variant="outline" size="sm" data-testid="button-reset-filters">
              Reset Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card>
        <CardHeader>
          <CardTitle>Change History</CardTitle>
          <CardDescription>
            Showing {auditLogs.length} {auditLogs.length === 1 ? 'entry' : 'entries'}
            {auditLogs.length === pageSize && ' (showing first ' + pageSize + ')'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading audit logs...</div>
          ) : auditLogs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No audit logs found</div>
          ) : (
            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {auditLogs.map((log) => (
                  <Card
                    key={log.id}
                    className="hover-elevate cursor-pointer"
                    onClick={() => setSelectedEntry(log)}
                    data-testid={`audit-entry-${log.id}`}
                  >
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{log.action.toUpperCase()}</Badge>
                            <span className="font-mono text-sm text-muted-foreground">
                              {log.field_name}
                            </span>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Old:</span>{' '}
                              <span className="font-medium">{formatValue(log.old_value)}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">New:</span>{' '}
                              <span className="font-medium">{formatValue(log.new_value)}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {log.user_username}
                            </div>
                            <div className="flex items-center gap-1">
                              <Database className="h-3 w-3" />
                              {log.layer_name}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(log.edited_at), 'PPpp')}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}

          {/* Pagination */}
          <div className="flex items-center justify-between mt-4">
            <Button
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
              variant="outline"
              size="sm"
              data-testid="button-prev-page"
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {page + 1}
            </span>
            <Button
              onClick={() => setPage(p => p + 1)}
              disabled={auditLogs.length < pageSize}
              variant="outline"
              size="sm"
              data-testid="button-next-page"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Detail View Dialog */}
      {selectedEntry && (
        <Card className="mt-4">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Entry Details</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedEntry(null)}
                data-testid="button-close-details"
              >
                Close
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">User</Label>
                <p className="font-medium">{selectedEntry.user_username}</p>
                {selectedEntry.user_email && (
                  <p className="text-sm text-muted-foreground">{selectedEntry.user_email}</p>
                )}
              </div>
              <div>
                <Label className="text-muted-foreground">Timestamp</Label>
                <p className="font-medium">{format(new Date(selectedEntry.edited_at), 'PPpp')}</p>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Layer</Label>
                <p className="font-medium">{selectedEntry.layer_name}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Record ID</Label>
                <p className="font-medium">{selectedEntry.record_id}</p>
              </div>
            </div>

            <Separator />

            <div>
              <Label className="text-muted-foreground">Field Name</Label>
              <p className="font-mono font-medium">{selectedEntry.field_name}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Old Value</Label>
                <div className="mt-2 p-3 bg-muted rounded-md">
                  <code className="text-sm">{formatValue(selectedEntry.old_value)}</code>
                </div>
              </div>
              <div>
                <Label className="text-muted-foreground">New Value</Label>
                <div className="mt-2 p-3 bg-muted rounded-md">
                  <code className="text-sm">{formatValue(selectedEntry.new_value)}</code>
                </div>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-3 gap-4 text-sm">
              {selectedEntry.source_ip && (
                <div>
                  <Label className="text-muted-foreground">IP Address</Label>
                  <p className="font-mono">{selectedEntry.source_ip}</p>
                </div>
              )}
              {selectedEntry.session_id && (
                <div>
                  <Label className="text-muted-foreground">Session ID</Label>
                  <p className="font-mono text-xs truncate">{selectedEntry.session_id}</p>
                </div>
              )}
              {selectedEntry.user_agent && (
                <div className="col-span-2">
                  <Label className="text-muted-foreground">User Agent</Label>
                  <p className="text-xs truncate">{selectedEntry.user_agent}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </PageShell>
  );
}
