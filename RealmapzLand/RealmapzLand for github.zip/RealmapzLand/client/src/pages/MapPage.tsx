import { useState, useEffect, useRef, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { Eye, EyeOff, ZoomIn, Table, Settings, Trash2, Plus, RefreshCw, Filter, X, Minus, ChevronDown, ChevronUp, Sparkles, Share2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useFieldPermissions, filterHiddenFields } from '@/hooks/useFieldPermissions';
import AddLayerModal from '@/components/AddLayerModal';
import ConnectSheetDialog from '@/components/ConnectSheetDialog';
import LayerPropertiesModal from '@/components/LayerPropertiesModal';
import AttributeTable from '@/components/AttributeTable';
import { LinkViewerModal } from '@/components/LinkViewerModal';
import NaturalLanguageQuery from '@/components/NaturalLanguageQuery';
import ShareMapModal from '@/components/ShareMapModal';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { MapLayer, LayerFilter } from '@shared/schema';

interface SheetConnection {
  id: string;
  spreadsheetId: string;
  spreadsheetName: string;
  hasTokens: boolean;
  createdAt: Date;
}

type BaseMapType = 'streets' | 'satellite' | 'hybrid';

const BASE_MAPS: Record<BaseMapType, { url: string; attribution: string; name: string }> = {
  streets: {
    name: 'Street Map',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  },
  satellite: {
    name: 'Satellite',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '&copy; <a href="https://www.esri.com/">Esri</a>'
  },
  hybrid: {
    name: 'Hybrid',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '&copy; <a href="https://www.esri.com/">Esri</a>'
  }
};

interface FilterRule {
  id: string;
  layerId: string;
  fieldName: string;
  operator: string;
  value: string;
  source?: 'manual' | 'nl'; // Track filter source for UX distinction
}

interface DemoLayerResponse {
  id: string;
  layerName: string;
  geometryField: string;
  geojson: any;
  headers: string[];
}

/**
 * Custom hook for fetching layer GeoJSON with smart polling
 * Polls every 30 seconds ONLY when enabled (attribute table is open)
 */
function useLayerGeojson(layerId: string, enabled: boolean) {
  return useQuery({
    queryKey: ['/api/layers', layerId, 'geojson'],
    queryFn: async () => {
      if (!layerId || layerId === 'demo-layer') return null;
      const response = await fetch(`/api/layers/${layerId}/geojson`);
      if (!response.ok) {
        throw new Error(`Failed to load layer: ${response.statusText}`);
      }
      return response.json();
    },
    enabled: enabled && !!layerId && layerId !== 'demo-layer',
    refetchInterval: enabled ? 30000 : false, // Poll every 30 seconds when enabled
    refetchOnWindowFocus: false, // Don't refetch on window focus
    staleTime: 25000, // Consider data stale after 25 seconds (slightly less than polling interval)
  });
}

export default function MapPage() {
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeLayerId, setActiveLayerId] = useState<string | null>(null);
  const [layersData, setLayersData] = useState<Map<string, any>>(new Map());
  const [showAddLayerModal, setShowAddLayerModal] = useState(false);
  const [connectSheetOpen, setConnectSheetOpen] = useState(false);
  const [pendingConnectionId, setPendingConnectionId] = useState<string | null>(null);
  const [propertiesLayer, setPropertiesLayer] = useState<MapLayer | null>(null);
  const [attributeTableLayer, setAttributeTableLayer] = useState<MapLayer | null>(null);
  const [attributeTableExpanded, setAttributeTableExpanded] = useState(false);
  const [shareLayer, setShareLayer] = useState<MapLayer | null>(null);
  const [baseMap, setBaseMap] = useState<BaseMapType>('satellite');
  const mapRef = useRef<L.Map | null>(null);
  
  // Link viewer modal state
  const [linkViewer, setLinkViewer] = useState<{ url: string; title: string } | null>(null);
  
  // Smart polling for attribute table layer (polls every 30s when table is open)
  const attributeTableQuery = useLayerGeojson(
    attributeTableLayer?.id ?? '',
    !!attributeTableLayer
  );
  
  // Sync attribute table query data with layersData (for map rendering and filtering)
  useEffect(() => {
    if (attributeTableQuery.data && attributeTableLayer?.id) {
      setLayersData(prev => new Map(prev).set(attributeTableLayer.id, attributeTableQuery.data));
    }
  }, [attributeTableQuery.data, attributeTableLayer?.id]);

  // Filter state
  const [activeFilters, setActiveFilters] = useState<FilterRule[]>([]);
  const [filterLayerId, setFilterLayerId] = useState<string>('');
  const [filterField, setFilterField] = useState<string>('');
  const [filterOperator, setFilterOperator] = useState<string>('equals');
  const [filterValue, setFilterValue] = useState<string>('');
  const [filteredLayersData, setFilteredLayersData] = useState<Map<string, any>>(new Map());
  const [filtersExpanded, setFiltersExpanded] = useState(false);
  
  // Demo layer state
  const [demoDismissed, setDemoDismissed] = useState(() => {
    return localStorage.getItem('demo-layer-dismissed') === 'true';
  });
  const [demoLayerVisible, setDemoLayerVisible] = useState(true);
  const [demoLayerConfig, setDemoLayerConfig] = useState<Partial<MapLayer>>({});

  // Check for pending connection after OAuth redirect (SECURE - no tokens in URL)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const authStatus = params.get('auth');
    const connectionId = params.get('connectionId');
    
    if (authStatus === 'success' && connectionId) {
      setPendingConnectionId(connectionId);
      setConnectSheetOpen(true);
      // Clean URL
      window.history.replaceState({}, '', '/');
    }
  }, []);

  // Fetch user's Google Sheets connections
  const { data: connections = [] } = useQuery<SheetConnection[]>({
    queryKey: ['/api/connections'],
  });

  // Fetch current user
  const { data: currentUser } = useQuery<{ id: string; email: string; full_name: string; role: string; organization_id: string }>({
    queryKey: ['/api/me'],
  });

  // Fetch user's layers
  const { data: layers = [], isLoading: layersLoading } = useQuery<MapLayer[]>({
    queryKey: ['/api/layers'],
  });
  
  // Fetch layer permissions for current user
  const { data: layerPermissions = [] } = useQuery<Array<{ layerId: string; layerName: string; permissionLevel: 'hidden' | 'view' | 'edit'; isInherited: boolean }>>({
    queryKey: [`/api/layer-permissions/user/${currentUser?.id}`],
    enabled: !!currentUser?.id,
  });
  
  // Fetch demo layer data when user has no layers and hasn't dismissed
  const { data: demoLayerData, isError: demoError, error: demoErrorDetails } = useQuery<DemoLayerResponse>({
    queryKey: ['/api/demo-layer'],
    enabled: !layersLoading && layers.length === 0 && !demoDismissed,
    staleTime: 10 * 60 * 1000, // Cache for 10 minutes
    retry: 1, // Only retry once to avoid hammering the API
  });
  
  // Create synthetic demo layer object for UI consistency
  const demoLayer: MapLayer | null = demoLayerData && !demoDismissed && layers.length === 0 ? {
    id: 'demo-layer',
    userId: '',
    connectionId: '',
    sheetName: demoLayerData.layerName || 'Demo Sites',
    layerName: demoLayerData.layerName || 'Demo Sites',
    geometryField: demoLayerData.geometryField,
    visible: demoLayerVisible,
    color: demoLayerConfig.color || '#3b82f6', // Blue color for demo layer
    symbologyType: demoLayerConfig.symbologyType || 'single',
    symbologyConfig: demoLayerConfig.symbologyConfig || {
      fillColor: '#3b82f6',
      fillOpacity: 0.5,
      borderColor: '#1e40af',
      borderWidth: 2,
    },
    labelsEnabled: demoLayerConfig.labelsEnabled !== undefined ? demoLayerConfig.labelsEnabled : true,
    labelConfig: demoLayerConfig.labelConfig || {
      labelField: 'Name',
      fontSize: 11,
      color: '#ffffff',
      backgroundColor: 'rgba(0, 0, 0, 0.7)',
      borderColor: '#3b82f6',
      borderWidth: 1,
    },
    popupsEnabled: demoLayerConfig.popupsEnabled !== undefined ? demoLayerConfig.popupsEnabled : true,
    popupConfig: demoLayerConfig.popupConfig || {
      template: 'default',
      fields: demoLayerData.headers || ['Name', 'Status', 'Area_in_sq', 'Dimension'],
      maxFieldLength: 100,
      showGeometry: false,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
    // @ts-ignore - Add custom flag for demo layer
    isDemo: true,
  } : null;
  
  // Merge user layers with demo layer (demo layer appears at top)
  const allLayers = demoLayer ? [demoLayer, ...layers] : layers;
  
  // Helper function to get permission level for a layer
  const getLayerPermission = (layerId: string): 'hidden' | 'view' | 'edit' => {
    // Demo layer is always editable
    if (layerId === 'demo-layer') return 'edit';
    
    const permission = layerPermissions.find(p => p.layerId === layerId);
    if (permission) {
      return permission.permissionLevel;
    }
    
    // Default based on role: viewer=view, editor/admin=edit
    return currentUser?.role === 'viewer' ? 'view' : 'edit';
  };
  
  // Filter layers based on permissions (hide hidden layers)
  const visibleLayers = allLayers.filter(layer => getLayerPermission(layer.id) !== 'hidden');
  
  // Demo layer dismissal handler
  const handleDismissDemo = () => {
    localStorage.setItem('demo-layer-dismissed', 'true');
    setDemoDismissed(true);
    
    // Clear demo layer data
    setLayersData(prev => {
      const newMap = new Map(prev);
      newMap.delete('demo-layer');
      return newMap;
    });
    
    // Clear demo selections
    if (activeLayerId === 'demo-layer') {
      setActiveLayerId(null);
    }
    if (attributeTableLayer?.id === 'demo-layer') {
      setAttributeTableLayer(null);
    }
    if (propertiesLayer?.id === 'demo-layer') {
      setPropertiesLayer(null);
    }
    
    toast({
      title: 'Demo layer dismissed',
      description: 'The demo layer has been hidden. Add your own Google Sheets to get started.',
    });
  };

  // Connect to Google Sheets
  const handleConnectGoogleSheets = async () => {
    const response = await fetch('/api/auth/google');
    const { authUrl } = await response.json();
    window.location.href = authUrl;
  };

  // Load layer data from Google Sheets (now uses secure backend proxy)
  const loadLayerData = async (layer: MapLayer) => {
    try {
      const response = await fetch(`/api/layers/${layer.id}/geojson`);
      if (!response.ok) {
        throw new Error(`Failed to load layer: ${response.statusText}`);
      }
      const geojson = await response.json();
      
      // ERROR FEEDBACK: Check if features array is empty or missing
      if (!geojson.features || geojson.features.length === 0) {
        console.warn(`Layer "${layer.layerName}" has no features. Check geometry field configuration.`);
        alert(`Warning: Layer "${layer.layerName}" loaded but contains no geographic features. Please verify the geometry field is correctly configured.`);
        return;
      }
      
      setLayersData(prev => new Map(prev).set(layer.id, geojson));
      
      // Auto-zoom to the layer extent when data is first loaded
      if (mapRef.current) {
        try {
          const geojsonLayer = L.geoJSON(geojson);
          const bounds = geojsonLayer.getBounds();
          if (bounds.isValid()) {
            mapRef.current.fitBounds(bounds, { padding: [50, 50] });
          }
        } catch (error) {
          console.error('Error auto-zooming to layer:', error);
        }
      }
    } catch (error) {
      console.error('Error loading layer data:', error);
      alert(`Failed to load layer "${layer.layerName}": ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  // Handle demo layer data injection and errors
  useEffect(() => {
    if (demoError && demoErrorDetails) {
      // Show error toast for demo layer failure
      const errorData = demoErrorDetails as any;
      toast({
        title: 'Demo data unavailable',
        description: errorData.response?.data?.userMessage || 'Unable to load demo data',
        variant: 'destructive',
      });
    }
    
    if (demoLayerData && !demoDismissed && layers.length === 0) {
      // Inject demo layer GeoJSON into layersData
      setLayersData(prev => {
        const newMap = new Map(prev);
        newMap.set('demo-layer', demoLayerData.geojson);
        return newMap;
      });
      
      // Auto-zoom to demo layer extent
      if (mapRef.current && demoLayerData.geojson) {
        try {
          const geojsonLayer = L.geoJSON(demoLayerData.geojson);
          const bounds = geojsonLayer.getBounds();
          if (bounds.isValid()) {
            mapRef.current.fitBounds(bounds, { padding: [50, 50] });
          }
        } catch (error) {
          console.error('Error auto-zooming to demo layer:', error);
        }
      }
    }
  }, [demoLayerData, demoError, demoErrorDetails, demoDismissed, layers.length, toast]);
  
  // Auto-dismiss demo layer when user adds their first real layer
  useEffect(() => {
    if (layers.length > 0 && !demoDismissed) {
      // Clean up demo layer data
      setLayersData(prev => {
        const newMap = new Map(prev);
        newMap.delete('demo-layer');
        return newMap;
      });
      
      // Clear demo selections if they reference the demo layer
      if (activeLayerId === 'demo-layer') {
        setActiveLayerId(null);
      }
      if (attributeTableLayer?.id === 'demo-layer') {
        setAttributeTableLayer(null);
      }
      if (propertiesLayer?.id === 'demo-layer') {
        setPropertiesLayer(null);
      }
    }
  }, [layers.length, demoDismissed]);

  // Load all visible layers (FIXED: Re-fetch when visibility changes)
  useEffect(() => {
    const visibleLayers = layers.filter(l => l.visible);
    
    // DON'T clear data for hidden layers - keep them in cache for modal access
    // This ensures LayerPropertiesModal can still extract field names from hidden layers
    
    // Load data for visible layers that aren't already cached
    visibleLayers.forEach(layer => {
      if (!layersData.has(layer.id)) {
        loadLayerData(layer);
      }
    });
  }, [layers]);

  // Toggle layer visibility (with demo layer support)
  const toggleLayerVisibility = useMutation({
    mutationFn: async ({ id, visible }: { id: string; visible: boolean }) => {
      // Handle demo layer locally (no server call)
      if (id === 'demo-layer') {
        setDemoLayerVisible(visible);
        return Promise.resolve();
      }
      return apiRequest('PATCH', `/api/layers/${id}`, { visible });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layers'] });
      // DON'T clear cache - keep data for modal field extraction
    },
  });

  // Delete layer (with demo layer support)
  const deleteLayer = useMutation({
    mutationFn: async (id: string) => {
      // Handle demo layer as dismissal
      if (id === 'demo-layer') {
        handleDismissDemo();
        return Promise.resolve();
      }
      return apiRequest('DELETE', `/api/layers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/layers'] });
    },
  });

  // Filter handlers
  const addFilterRule = () => {
    if (!filterLayerId || !filterField || !filterOperator || !filterValue) {
      alert('Please fill in all filter fields');
      return;
    }

    const newFilter: FilterRule = {
      id: Date.now().toString(),
      layerId: filterLayerId,
      fieldName: filterField,
      operator: filterOperator,
      value: filterValue,
      source: 'manual', // Mark as manually created filter
    };

    setActiveFilters([...activeFilters, newFilter]);
    
    // Clear form
    setFilterLayerId('');
    setFilterField('');
    setFilterValue('');
  };

  const removeFilterRule = (filterId: string) => {
    setActiveFilters(activeFilters.filter(f => f.id !== filterId));
  };

  const clearAllFilters = () => {
    setActiveFilters([]);
  };

  // Natural Language Query handlers
  const handleNLFiltersGenerated = (nlFilters: FilterRule[]) => {
    // Remove any existing NL filters and add new ones
    const manualFilters = activeFilters.filter(f => f.source !== 'nl');
    setActiveFilters([...manualFilters, ...nlFilters]);
  };

  const clearNLFilters = () => {
    setActiveFilters(activeFilters.filter(f => f.source !== 'nl'));
  };

  // Get available fields for NL query (from first visible layer with data)
  const getNLQueryContext = (): { 
    layerId: string; 
    layerName: string; 
    fields: string[];
    fieldMetadata: Array<{ name: string; sampleValue: string }>;
  } | null => {
    // Find first visible layer with data
    const visibleLayer = allLayers.find(l => l.visible && layersData.has(l.id));
    if (!visibleLayer) return null;

    const geojson = layersData.get(visibleLayer.id);
    if (!geojson?.features?.[0]?.properties) return null;

    const properties = geojson.features[0].properties;
    const fields = Object.keys(properties);
    
    // Extract sample values for AI prompt
    const fieldMetadata = fields.map(fieldName => ({
      name: fieldName,
      sampleValue: String(properties[fieldName] ?? 'null'),
    }));

    return {
      layerId: visibleLayer.id,
      layerName: visibleLayer.layerName,
      fields,
      fieldMetadata,
    };
  };

  // Link viewer handler
  const handleLinkOpen = (url: string, fieldName: string) => {
    setLinkViewer({ url, title: fieldName });
  };

  // Apply filters to GeoJSON data
  const applyFilters = () => {
    console.log('🔍 applyFilters called', { 
      activeFiltersCount: activeFilters.length, 
      activeFilters,
      layersDataSize: layersData.size 
    });

    if (activeFilters.length === 0) {
      // No filters - use original data
      console.log('📌 No active filters, using original data');
      setFilteredLayersData(new Map());
      return;
    }

    const newFilteredData = new Map<string, any>();

    layersData.forEach((geojson, layerId) => {
      const layerFilters = activeFilters.filter(f => f.layerId === layerId);
      
      console.log(`🗺️ Processing layer ${layerId}`, {
        totalFeatures: geojson.features?.length,
        layerFiltersCount: layerFilters.length,
        layerFilters
      });
      
      if (layerFilters.length === 0) {
        // No filters for this layer - use original data
        newFilteredData.set(layerId, geojson);
        return;
      }

      // Filter features
      const filteredFeatures = geojson.features.filter((feature: any) => {
        // Check if feature passes all filters for this layer
        const passes = layerFilters.every(filter => {
          const fieldValue = feature.properties?.[filter.fieldName];
          
          let result = false;
          switch (filter.operator) {
            case 'equals':
              result = String(fieldValue) === String(filter.value);
              break;
            case 'not_equals':
              result = String(fieldValue) !== String(filter.value);
              break;
            case 'contains':
              result = String(fieldValue).toLowerCase().includes(String(filter.value).toLowerCase());
              break;
            case 'not_contains':
              result = !String(fieldValue).toLowerCase().includes(String(filter.value).toLowerCase());
              break;
            case 'starts_with':
              result = String(fieldValue).toLowerCase().startsWith(String(filter.value).toLowerCase());
              break;
            case 'ends_with':
              result = String(fieldValue).toLowerCase().endsWith(String(filter.value).toLowerCase());
              break;
            case 'greater_than':
              result = parseFloat(fieldValue) > parseFloat(filter.value);
              break;
            case 'less_than':
              result = parseFloat(fieldValue) < parseFloat(filter.value);
              break;
            default:
              result = true;
          }
          
          console.log(`  ✓ Filter check: ${filter.fieldName} ${filter.operator} "${filter.value}"`, {
            fieldValue,
            result
          });
          
          return result;
        });
        
        return passes;
      });

      console.log(`✅ Filtered ${geojson.features.length} → ${filteredFeatures.length} features`);

      newFilteredData.set(layerId, {
        ...geojson,
        features: filteredFeatures
      });
    });

    console.log('💾 Setting filtered data', { 
      newFilteredDataSize: newFilteredData.size,
      keys: Array.from(newFilteredData.keys())
    });
    setFilteredLayersData(newFilteredData);
  };

  // Auto-apply filters whenever activeFilters or layersData changes
  useEffect(() => {
    applyFilters();
  }, [activeFilters, layersData]);

  // Derive field list for selected filter layer (memoized)
  const filterLayerFields = useMemo(() => {
    if (!filterLayerId) return [];
    const geojson = layersData.get(filterLayerId);
    if (!geojson?.features?.[0]?.properties) return [];
    
    const layer = allLayers.find(l => l.id === filterLayerId);
    if (!layer) return [];
    
    // Get all field names except geometry field and __rowIndex
    return Object.keys(geojson.features[0].properties).filter(
      field => field !== layer.geometryField && field !== '__rowIndex'
    );
  }, [filterLayerId, layersData, allLayers]);

  // Fetch field permissions for selected filter layer
  const { data: filterFieldPermissions } = useFieldPermissions(
    filterLayerId || '',
    filterLayerFields,
    !!filterLayerId && filterLayerId !== 'demo-layer' && filterLayerFields.length > 0
  );

  // Get field names for selected filter layer (with permissions applied)
  const getFilterFieldOptions = (): string[] => {
    if (!filterLayerId || filterLayerFields.length === 0) return [];
    
    // Apply field permissions - exclude hidden fields
    return filterHiddenFields(filterLayerFields, filterFieldPermissions);
  };

  // Get unique values for selected field
  const getFilterValueOptions = () => {
    if (!filterLayerId || !filterField) return [];
    const geojson = layersData.get(filterLayerId);
    if (!geojson?.features) return [];
    
    const uniqueValues = new Set<string>();
    geojson.features.forEach((feature: any) => {
      const value = feature.properties?.[filterField];
      if (value !== null && value !== undefined) {
        uniqueValues.add(String(value));
      }
    });
    
    return Array.from(uniqueValues).sort();
  };

  // Zoom to layer extent
  const zoomToLayer = (layerId: string) => {
    const geojson = layersData.get(layerId);
    if (!geojson || !mapRef.current) return;

    try {
      const geojsonLayer = L.geoJSON(geojson);
      const bounds = geojsonLayer.getBounds();
      if (bounds.isValid()) {
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
      }
    } catch (error) {
      console.error('Error zooming to layer:', error);
    }
  };

  // Apply symbology styling to features
  const getFeatureStyle = (feature: any, layer: MapLayer) => {
    const config = layer.symbologyConfig as any;
    
    // Default style
    const defaultStyle = {
      color: config?.borderColor || layer.color || '#3498db',
      weight: config?.borderWidth !== undefined ? config.borderWidth : 2,
      opacity: 1,
      fillOpacity: config?.fillOpacity !== undefined ? config.fillOpacity : 0.5,
      fillColor: config?.fillColor || layer.color || '#3498db',
    };

    if (layer.symbologyType === 'single') {
      return defaultStyle;
    }

    if (layer.symbologyType === 'graduated' && config?.gradField) {
      // Graduated symbology (choropleth)
      const value = Number(feature.properties?.[config.gradField]);
      if (isNaN(value)) return defaultStyle;

      // Get all values to compute breaks
      const geojson = layersData.get(layer.id);
      if (!geojson?.features) return defaultStyle;

      const values = geojson.features
        .map((f: any) => Number(f.properties?.[config.gradField]))
        .filter((v: number) => !isNaN(v))
        .sort((a: number, b: number) => a - b);

      // Compute class breaks (FIXED: Handle sparse datasets)
      const numClasses = config.gradClasses || 5;
      const breaks: number[] = [];
      
      // GUARD: Handle sparse datasets
      if (values.length < numClasses) {
        // Fewer features than classes - create breaks between values
        for (let i = 1; i < values.length; i++) {
          breaks.push((values[i - 1] + values[i]) / 2);
        }
      } else if (config.gradMethod === 'equal') {
        const min = values[0];
        const max = values[values.length - 1];
        const interval = (max - min) / numClasses;
        for (let i = 1; i < numClasses; i++) {
          breaks.push(min + interval * i);
        }
      } else if (config.gradMethod === 'quantile') {
        for (let i = 1; i < numClasses; i++) {
          const index = Math.floor((values.length * i) / numClasses);
          breaks.push(values[index]);
        }
      } else {
        // Natural breaks (simplified)
        const numPerClass = Math.floor(values.length / numClasses);
        if (numPerClass === 0) {
          // Fallback to quantile for very sparse data
          for (let i = 1; i < numClasses; i++) {
            const index = Math.floor((values.length * i) / numClasses);
            breaks.push(values[index]);
          }
        } else {
          for (let i = 1; i < numClasses; i++) {
            breaks.push(values[i * numPerClass]);
          }
        }
      }

      // Find which class this feature belongs to
      let classIndex = 0;
      for (let i = 0; i < breaks.length; i++) {
        if (value >= breaks[i]) classIndex = i + 1;
      }

      // Get color from ramp
      const colorRamps: Record<string, string[]> = {
        blues: ['#f7fbff', '#deebf7', '#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#084594'],
        greens: ['#f7fcf5', '#e5f5e0', '#c7e9c0', '#a1d99b', '#74c476', '#41ab5d', '#238b45', '#005a32'],
        reds: ['#fff5f0', '#fee0d2', '#fcbba1', '#fc9272', '#fb6a4a', '#ef3b2c', '#cb181d', '#99000d'],
        oranges: ['#fff5eb', '#fee6ce', '#fdd0a2', '#fdae6b', '#fd8d3c', '#f16913', '#d94801', '#8c2d04'],
        purples: ['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'],
        'red-yellow-green': ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63', '#1a9850'],
        'spectral': ['#9e0142', '#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#e6f598', '#abdda4', '#66c2a5', '#3288bd', '#5e4fa2'],
      };

      const ramp = colorRamps[config.gradColorRamp as keyof typeof colorRamps] || colorRamps.blues;
      const color = ramp.slice(0, numClasses)[classIndex] || defaultStyle.fillColor;

      return {
        ...defaultStyle,
        fillColor: color,
        color: color,
      };
    }

    if (layer.symbologyType === 'categorized' && config?.catField && config?.catColors) {
      // Categorized symbology (unique values)
      const value = String(feature.properties?.[config.catField] || '');
      const color = config.catColors[value] || defaultStyle.fillColor;

      return {
        ...defaultStyle,
        fillColor: color,
        color: color,
      };
    }

    return defaultStyle;
  };

  // Map initialization component to capture map instance
  function MapInitializer() {
    const map = useMap();
    useEffect(() => {
      mapRef.current = map;
    }, [map]);
    return null;
  }

  return (
    <div className="flex h-screen w-full bg-background">
      {/* Dark Sidebar */}
      {sidebarOpen && (
        <div className="w-[380px] flex-shrink-0 flex flex-col" 
          style={{ backgroundColor: '#2c3e50', color: 'white' }}>
          {/* Sidebar Header */}
          <div className="p-4 border-b" style={{ backgroundColor: '#34495e', borderColor: '#445566' }}>
            <h2 className="text-lg font-semibold">GIS Layers</h2>
          </div>

          {/* Sidebar Content */}
          <ScrollArea className="flex-1">
            <div className="p-3">
              {/* Base Map Selector */}
              <div className="mb-4 p-3 rounded border" style={{ backgroundColor: '#34495e', borderColor: '#445566' }}>
                <h3 className="text-sm font-semibold mb-2">Base Map</h3>
                <div className="grid grid-cols-3 gap-1">
                  {(Object.keys(BASE_MAPS) as BaseMapType[]).map((type) => (
                    <Button
                      key={type}
                      size="sm"
                      variant={baseMap === type ? "default" : "outline"}
                      className="text-xs h-8"
                      onClick={() => setBaseMap(type)}
                      data-testid={`button-basemap-${type}`}
                    >
                      {BASE_MAPS[type].name}
                    </Button>
                  ))}
                </div>
              </div>

              <Separator className="my-4" style={{ backgroundColor: '#445566' }} />

              {/* Layers List */}
              <div className="space-y-2">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-semibold">Map Layers</h3>
                  <div className="flex gap-1">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={async () => {
                        // Invalidate layers list
                        await queryClient.invalidateQueries({ queryKey: ['/api/layers'] });
                        // Reload all visible user layers from Google Sheets (skip demo layer)
                        layers.filter(l => l.visible).forEach(layer => {
                          loadLayerData(layer);
                        });
                        // Also refresh demo layer if it's visible
                        if (demoLayer && demoLayerVisible) {
                          queryClient.invalidateQueries({ queryKey: ['/api/demo-layer'] });
                        }
                      }}
                      title="Refresh layers from Google Sheets"
                      data-testid="button-refresh-layers"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={() => setShowAddLayerModal(true)}
                      disabled={connections.filter(c => c.spreadsheetName !== 'Pending Connection').length === 0}
                      title="Add layer from connected sheet"
                      data-testid="button-add-layer"
                    >
                      <Table className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {layersLoading ? (
                  <div className="text-sm text-center py-4 opacity-75">Loading layers...</div>
                ) : visibleLayers.length === 0 ? (
                  <div className="text-sm text-center py-4 opacity-75">
                    No layers yet. Connect Google Sheets in Settings, then click the table icon to add a layer.
                  </div>
                ) : (
                  visibleLayers.map(layer => {
                    const permission = getLayerPermission(layer.id);
                    const isViewOnly = permission === 'view';
                    
                    return (
                    <div
                      key={layer.id}
                      className="p-3 rounded border transition-all cursor-pointer"
                      style={{
                        backgroundColor: activeLayerId === layer.id ? '#1e3a5f' : '#1a252f',
                        borderColor: activeLayerId === layer.id ? '#3498db' : '#445566',
                      }}
                      onClick={() => setActiveLayerId(layer.id)}
                      data-testid={`layer-item-${layer.id}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded" 
                            style={{ backgroundColor: layer.color || '#3498db' }}
                          />
                          <span className="font-medium text-sm">{layer.layerName}</span>
                          {/* @ts-ignore - isDemo flag added to synthetic layer */}
                          {layer.isDemo && (
                            <Badge variant="secondary" className="text-xs" data-testid="badge-demo-layer">
                              Demo
                            </Badge>
                          )}
                          {isViewOnly && (
                            <Badge variant="outline" className="text-xs" data-testid={`badge-view-only-${layer.id}`}>
                              View Only
                            </Badge>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLayerVisibility.mutate({ 
                              id: layer.id, 
                              visible: !layer.visible 
                            });
                          }}
                          data-testid={`button-toggle-visibility-${layer.id}`}
                        >
                          {layer.visible ? (
                            <Eye className="w-4 h-4" />
                          ) : (
                            <EyeOff className="w-4 h-4 opacity-50" />
                          )}
                        </Button>
                      </div>

                      {/* Layer Controls */}
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          className="flex-1 h-7 text-xs"
                          style={{ backgroundColor: '#3498db' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            zoomToLayer(layer.id);
                          }}
                          data-testid={`button-zoom-${layer.id}`}
                        >
                          <ZoomIn className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 h-7 text-xs"
                          style={{ backgroundColor: '#2ecc71' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            // Load layer data if not already loaded
                            if (!layersData.has(layer.id)) {
                              loadLayerData(layer);
                            }
                            setAttributeTableLayer(layer);
                            setAttributeTableExpanded(false);
                          }}
                          data-testid={`button-table-${layer.id}`}
                        >
                          <Table className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 h-7 text-xs"
                          style={{ backgroundColor: isViewOnly ? '#95a5a6' : '#f39c12' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            // Ensure layer data is loaded before opening modal
                            if (!layersData.has(layer.id)) {
                              loadLayerData(layer);
                            }
                            setPropertiesLayer(layer);
                          }}
                          disabled={isViewOnly}
                          title={isViewOnly ? 'View-only permission' : 'Layer properties'}
                          data-testid={`button-properties-${layer.id}`}
                        >
                          <Settings className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 h-7 text-xs"
                          style={{ backgroundColor: isViewOnly ? '#95a5a6' : '#3b82f6' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setShareLayer(layer);
                          }}
                          disabled={isViewOnly}
                          title={isViewOnly ? 'View-only permission' : 'Share layer'}
                          data-testid={`button-share-${layer.id}`}
                        >
                          <Share2 className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 h-7 text-xs"
                          style={{ backgroundColor: isViewOnly ? '#95a5a6' : '#e74c3c' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm('Delete this layer?')) {
                              deleteLayer.mutate(layer.id);
                            }
                          }}
                          disabled={isViewOnly}
                          title={isViewOnly ? 'View-only permission' : 'Delete layer'}
                          data-testid={`button-delete-${layer.id}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    );
                  })
                )}
              </div>

              <Separator className="my-4" style={{ backgroundColor: '#445566' }} />

              {/* Natural Language Query Section */}
              {(() => {
                const nlContext = getNLQueryContext();
                const hasActiveNLFilters = activeFilters.some(f => f.source === 'nl');
                
                return nlContext ? (
                  <div className="mb-4 p-3 rounded border" style={{ backgroundColor: '#34495e', borderColor: '#445566' }}>
                    <NaturalLanguageQuery
                      layerId={nlContext.layerId}
                      layerName={nlContext.layerName}
                      availableFields={nlContext.fields}
                      fieldMetadata={nlContext.fieldMetadata}
                      onFiltersGenerated={handleNLFiltersGenerated}
                      onClear={clearNLFilters}
                      hasActiveNLFilters={hasActiveNLFilters}
                    />
                  </div>
                ) : null;
              })()}

              {/* Filters Section (Collapsible) */}
              <div className="mb-4 p-3 rounded border" style={{ backgroundColor: '#34495e', borderColor: '#445566' }}>
                <div 
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => setFiltersExpanded(!filtersExpanded)}
                  data-testid="filters-header"
                >
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    Filters
                    {activeFilters.length > 0 && (
                      <Badge variant="secondary" className="ml-1 text-xs">
                        {activeFilters.length}
                      </Badge>
                    )}
                  </h3>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 w-6 p-0"
                    data-testid="button-toggle-filters"
                  >
                    {filtersExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </Button>
                </div>

                {/* Filter Form - Only shown when expanded */}
                {filtersExpanded && (
                  <div className="mt-3 space-y-2">
                    <div>
                      <label className="text-xs opacity-75 mb-1 block">Layer:</label>
                      <select 
                        className="w-full text-sm px-2 py-1 rounded border"
                        style={{ backgroundColor: '#2c3e50', borderColor: '#445566', color: 'white' }}
                        value={filterLayerId}
                        onChange={(e) => {
                          setFilterLayerId(e.target.value);
                          setFilterField('');
                          setFilterValue('');
                        }}
                        data-testid="select-filter-layer"
                      >
                        <option value="">Select layer...</option>
                        {visibleLayers.filter(l => layersData.has(l.id)).map(layer => (
                          <option key={layer.id} value={layer.id}>{layer.layerName}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs opacity-75 mb-1 block">Field:</label>
                      <select 
                        className="w-full text-sm px-2 py-1 rounded border"
                        style={{ backgroundColor: '#2c3e50', borderColor: '#445566', color: 'white' }}
                        value={filterField}
                        onChange={(e) => {
                          setFilterField(e.target.value);
                          setFilterValue('');
                        }}
                        disabled={!filterLayerId}
                        data-testid="select-filter-field"
                      >
                        <option value="">Select field...</option>
                        {getFilterFieldOptions().map(field => (
                          <option key={field} value={field}>{field}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs opacity-75 mb-1 block">Operator:</label>
                      <select 
                        className="w-full text-sm px-2 py-1 rounded border"
                        style={{ backgroundColor: '#2c3e50', borderColor: '#445566', color: 'white' }}
                        value={filterOperator}
                        onChange={(e) => setFilterOperator(e.target.value)}
                        data-testid="select-filter-operator"
                      >
                        <option value="equals">Equals</option>
                        <option value="not_equals">Not Equals</option>
                        <option value="contains">Contains</option>
                        <option value="not_contains">Not Contains</option>
                        <option value="starts_with">Starts With</option>
                        <option value="ends_with">Ends With</option>
                        <option value="greater_than">Greater Than</option>
                        <option value="less_than">Less Than</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs opacity-75 mb-1 block">Value:</label>
                      <select 
                        className="w-full text-sm px-2 py-1 rounded border"
                        style={{ backgroundColor: '#2c3e50', borderColor: '#445566', color: 'white' }}
                        value={filterValue}
                        onChange={(e) => setFilterValue(e.target.value)}
                        disabled={!filterField}
                        data-testid="select-filter-value"
                      >
                        <option value="">Select value...</option>
                        {getFilterValueOptions().map(value => (
                          <option key={value} value={value}>{value}</option>
                        ))}
                      </select>
                    </div>

                    <Button
                      size="sm"
                      className="w-full mt-2"
                      style={{ backgroundColor: '#3498db' }}
                      onClick={addFilterRule}
                      data-testid="button-add-filter"
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add Filter
                    </Button>
                  </div>
                )}

                {/* Active Filters - Always shown */}
                {activeFilters.length > 0 && (
                  <div className="mt-3 space-y-2">
                    <div className="text-xs opacity-75 mb-1">Active Filters:</div>
                    {activeFilters.map(filter => {
                      const layer = layers.find(l => l.id === filter.layerId);
                      return (
                        <div 
                          key={filter.id}
                          className="p-2 rounded border flex justify-between items-start gap-2"
                          style={{ backgroundColor: '#1a252f', borderColor: '#445566' }}
                          data-testid={`filter-rule-${filter.id}`}
                        >
                          <div className="text-xs flex-1">
                            <div className="font-semibold flex items-center gap-1">
                              {filter.source === 'nl' && <Sparkles className="w-3 h-3 text-primary" />}
                              {layer?.layerName || 'Unknown'}
                            </div>
                            <div className="opacity-75">{filter.fieldName} {filter.operator} "{filter.value}"</div>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                            onClick={() => removeFilterRule(filter.id)}
                            data-testid={`button-remove-filter-${filter.id}`}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      );
                    })}

                    <Button
                      size="sm"
                      variant="destructive"
                      className="w-full mt-2"
                      onClick={clearAllFilters}
                      data-testid="button-clear-filters"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Clear All Filters
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Map Container with Resizable Attribute Table */}
      <div className="flex-1 relative">
        <ResizablePanelGroup direction="vertical">
          {/* Map Panel */}
          <ResizablePanel 
            defaultSize={attributeTableLayer ? (attributeTableExpanded ? 30 : 60) : 100}
            minSize={20}
          >
            <MapContainer
              center={[39.8283, -98.5795]} // Center of USA
              zoom={4}
              className="z-0"
              style={{ width: '100%', height: '100%' }}
              data-testid="map-container"
            >
          <MapInitializer />
          <TileLayer
            key={baseMap}
            attribution={BASE_MAPS[baseMap].attribution}
            url={BASE_MAPS[baseMap].url}
          />
          {/* Add label overlay for hybrid mode */}
          {baseMap === 'hybrid' && (
            <TileLayer
              key="hybrid-labels"
              url="https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"
              attribution='&copy; <a href="https://www.esri.com/">Esri</a>'
            />
          )}

          {/* Render GeoJSON layers with symbology and labels */}
          {visibleLayers.filter(l => l.visible).map(layer => {
            // Use filtered data when filters are active, otherwise use original data
            const geojson = activeFilters.length > 0 
              ? filteredLayersData.get(layer.id) 
              : layersData.get(layer.id);
            
            console.log(`🎨 Rendering layer ${layer.layerName}`, {
              layerId: layer.id,
              activeFiltersCount: activeFilters.length,
              usingFilteredData: activeFilters.length > 0,
              featuresCount: geojson?.features?.length,
              filteredLayersDataHasLayer: filteredLayersData.has(layer.id),
              originalLayersDataHasLayer: layersData.has(layer.id)
            });
            
            if (!geojson) {
              console.warn(`⚠️ No geojson data for layer ${layer.id}`);
              return null;
            }

            // Create unique key that includes feature count to force re-render when filters change
            // Using feature count ensures the component unmounts/remounts when data changes
            const configKey = `${layer.id}-${geojson.features.length}-${layer.labelsEnabled}-${layer.popupsEnabled}`;

            return (
              <GeoJSON
                key={configKey}
                data={geojson}
                style={(feature) => getFeatureStyle(feature, layer)}
                onEachFeature={(feature, leafletLayer) => {
                  // Add labels if enabled
                  if (layer.labelsEnabled && layer.labelConfig) {
                    const config = layer.labelConfig as any;
                    const labelValue = feature.properties?.[config.labelField];
                    
                    if (labelValue !== undefined && labelValue !== null) {
                      // bindTooltip returns the layer, not the tooltip
                      leafletLayer.bindTooltip(String(labelValue), {
                        permanent: true,
                        direction: 'center',
                        className: 'feature-label',
                      });
                      
                      // FIXED: Use layer's tooltipopen event to access the actual tooltip element
                      leafletLayer.on('tooltipopen', (e: any) => {
                        const tooltipEl = e.tooltip.getElement();
                        if (tooltipEl) {
                          tooltipEl.style.fontSize = `${config.fontSize || 12}px`;
                          tooltipEl.style.color = config.color || '#000000';
                          tooltipEl.style.fontWeight = '500';
                          tooltipEl.style.whiteSpace = 'nowrap';
                          tooltipEl.style.border = 'none';
                          
                          if (config.showBackground) {
                            tooltipEl.style.backgroundColor = config.backgroundColor || '#ffffff';
                            tooltipEl.style.padding = '2px 4px';
                            tooltipEl.style.borderRadius = '3px';
                            tooltipEl.style.boxShadow = '0 1px 3px rgba(0,0,0,0.2)';
                          } else {
                            tooltipEl.style.backgroundColor = 'transparent';
                            tooltipEl.style.textShadow = '1px 1px 2px white, -1px -1px 2px white';
                            tooltipEl.style.boxShadow = 'none';
                          }
                        }
                      });
                    }
                  }

                  // Add popups if enabled
                  if (layer.popupsEnabled && layer.popupConfig) {
                    const config = layer.popupConfig as any;
                    const props = feature.properties || {};
                    
                    // Generate popup content based on template
                    const generatePopupContent = () => {
                      const fields = config.fields || [];
                      const template = config.template || 'default';
                      const maxLength = config.maxFieldLength || 50;
                      
                      // SECURITY FIX: HTML escape to prevent XSS
                      const escapeHtml = (str: string) => {
                        const div = document.createElement('div');
                        div.textContent = String(str);
                        return div.innerHTML;
                      };
                      
                      const truncate = (str: string) => {
                        const s = String(str);
                        return escapeHtml(s.length > maxLength ? s.substring(0, maxLength) + '...' : s);
                      };

                      if (template === 'table') {
                        return `
                          <table style="width: 100%; font-size: 13px;">
                            <tbody>
                              ${fields.map((field: string) => {
                                const value = props[field];
                                if (value === undefined || value === null) return '';
                                return `
                                  <tr style="border-bottom: 1px solid #ddd;">
                                    <td style="padding: 4px; font-weight: 600;">${escapeHtml(field)}</td>
                                    <td style="padding: 4px;">${truncate(value)}</td>
                                  </tr>
                                `;
                              }).join('')}
                            </tbody>
                          </table>
                        `;
                      } else if (template === 'card') {
                        return `
                          <div style="font-size: 13px;">
                            ${fields.map((field: string) => {
                              const value = props[field];
                              if (value === undefined || value === null) return '';
                              return `
                                <div style="margin-bottom: 8px; padding: 6px; background: #f5f5f5; border-radius: 4px;">
                                  <div style="font-size: 11px; color: #666; margin-bottom: 2px;">${escapeHtml(field)}</div>
                                  <div style="font-weight: 500;">${truncate(value)}</div>
                                </div>
                              `;
                            }).join('')}
                          </div>
                        `;
                      } else {
                        // default template
                        return `
                          <div style="font-size: 13px;">
                            ${fields.map((field: string) => {
                              const value = props[field];
                              if (value === undefined || value === null) return '';
                              return `<div style="margin-bottom: 4px;"><strong>${escapeHtml(field)}:</strong> ${truncate(value)}</div>`;
                            }).join('')}
                          </div>
                        `;
                      }
                    };

                    const popupContent = generatePopupContent();
                    if (popupContent.trim()) {
                      leafletLayer.bindPopup(popupContent, {
                        maxWidth: config.maxWidth || 300,
                        className: 'custom-popup',
                      });
                    }
                  }
                }}
              />
            );
          })}
            </MapContainer>

            {/* Toggle Sidebar Button */}
            <Button
              className="absolute top-4 left-4 z-[1000]"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              data-testid="button-toggle-sidebar"
            >
              {sidebarOpen ? '◀' : '▶'}
            </Button>
          </ResizablePanel>

          {/* Attribute Table Panel */}
          {attributeTableLayer && (
            <>
              <ResizableHandle withHandle />
              <ResizablePanel 
                key={attributeTableExpanded ? 'expanded' : 'collapsed'}
                defaultSize={attributeTableExpanded ? 70 : 40}
                minSize={15}
              >
                <AttributeTable
                  layerId={attributeTableLayer.id}
                  layerName={attributeTableLayer.layerName}
                  geometryField={attributeTableLayer.geometryField || undefined}
                  features={attributeTableQuery.data?.features ?? layersData.get(attributeTableLayer.id)?.features ?? []}
                  onClose={() => setAttributeTableLayer(null)}
                  isExpanded={attributeTableExpanded}
                  onToggleExpand={() => setAttributeTableExpanded(!attributeTableExpanded)}
                  onDataUpdated={() => {
                    // Invalidate query to refetch fresh data after edit
                    queryClient.invalidateQueries({ 
                      queryKey: ['/api/layers', attributeTableLayer.id, 'geojson'] 
                    });
                  }}
                  onLinkOpen={handleLinkOpen}
                  manualRefresh={() => attributeTableQuery.refetch()}
                  lastSynced={attributeTableQuery.dataUpdatedAt}
                  isRefreshing={attributeTableQuery.isFetching}
                  readOnly={getLayerPermission(attributeTableLayer.id) === 'view'}
                />
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>
      </div>

      {/* Add Layer Modal */}
      <AddLayerModal 
        open={showAddLayerModal} 
        onOpenChange={setShowAddLayerModal}
      />

      {/* Connect Sheet Dialog (secure - no tokens exposed) */}
      <ConnectSheetDialog 
        open={connectSheetOpen} 
        onOpenChange={setConnectSheetOpen}
        pendingConnectionId={pendingConnectionId}
        onConnectionComplete={() => {
          // Open Add Layer modal after successful connection
          setTimeout(() => setShowAddLayerModal(true), 300);
        }}
      />

      {/* Layer Properties Modal */}
      <LayerPropertiesModal
        open={!!propertiesLayer}
        onOpenChange={(open) => !open && setPropertiesLayer(null)}
        layer={propertiesLayer}
        layerData={propertiesLayer ? layersData.get(propertiesLayer.id) : null}
        onShareLayer={(layer) => {
          setPropertiesLayer(null); // Close properties modal first
          setShareLayer(layer); // Open share modal
        }}
      />

      {/* Share Map Modal */}
      <ShareMapModal
        open={!!shareLayer}
        onOpenChange={(open) => !open && setShareLayer(null)}
        layerId={shareLayer?.id || ''}
        layerName={shareLayer?.layerName || ''}
      />

      {/* Link Viewer Modal */}
      <LinkViewerModal
        open={!!linkViewer}
        onClose={() => setLinkViewer(null)}
        url={linkViewer?.url || null}
        title={linkViewer?.title}
      />
    </div>
  );
}
