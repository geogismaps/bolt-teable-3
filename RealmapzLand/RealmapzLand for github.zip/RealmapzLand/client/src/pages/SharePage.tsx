import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, TileLayer, GeoJSON, Marker } from "react-leaflet";
import { LatLngBounds } from "leaflet";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Eye, Calendar } from "lucide-react";
import { format } from "date-fns";
import { useEffect, useState } from "react";
import "leaflet/dist/leaflet.css";

interface ShareData {
  shareToken: string;
  layerId: string;
  layerName: string;
  embedEnabled: boolean;
  viewCount: number;
  createdAt: string;
  expiresAt: string | null;
  color: string;
  geometryField: string | null;
  labelField: string | null;
  symbology: any;
  popupFields: string[] | null;
}

export default function SharePage() {
  const { token } = useParams();
  const [, navigate] = useLocation();
  const [isEmbedMode, setIsEmbedMode] = useState(false);

  // Check if embed mode is enabled via query parameter
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setIsEmbedMode(params.get('embed') === '1');
  }, []);

  // Fetch share metadata
  const shareQuery = useQuery<ShareData>({
    queryKey: ['/api/share', token],
    queryFn: async () => {
      const response = await fetch(`/api/share/${token}`);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Share not found');
        }
        if (response.status === 410) {
          throw new Error('Share has expired');
        }
        throw new Error('Failed to load shared map');
      }
      return response.json();
    },
    enabled: !!token,
  });

  // Fetch layer data
  const layerDataQuery = useQuery({
    queryKey: ['/api/share', token, 'data'],
    queryFn: async () => {
      const response = await fetch(`/api/share/${token}/data`);
      if (!response.ok) {
        throw new Error('Failed to load map data');
      }
      return response.json();
    },
    enabled: !!token && !!shareQuery.data,
  });

  // Error states
  if (shareQuery.isError || layerDataQuery.isError) {
    const error = shareQuery.error || layerDataQuery.error;
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="p-6 max-w-md w-full">
          <div className="flex items-center gap-3 text-destructive mb-4">
            <AlertCircle className="h-6 w-6" />
            <h2 className="text-xl font-semibold">Unable to Load Map</h2>
          </div>
          <p className="text-muted-foreground">
            {error?.message || 'This map link is invalid or has expired.'}
          </p>
        </Card>
      </div>
    );
  }

  // Loading state
  if (shareQuery.isLoading || layerDataQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
          <p className="mt-4 text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }

  const shareData = shareQuery.data;
  const layerData = layerDataQuery.data;

  if (!shareData || !layerData) {
    return null;
  }

  // Check if embed mode is requested but not enabled
  if (isEmbedMode && !shareData.embedEnabled) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="p-6 max-w-md w-full">
          <div className="flex items-center gap-3 text-destructive mb-4">
            <AlertCircle className="h-6 w-6" />
            <h2 className="text-xl font-semibold">Embedding Not Enabled</h2>
          </div>
          <p className="text-muted-foreground">
            This map link does not allow embedding. Please view it directly instead.
          </p>
        </Card>
      </div>
    );
  }

  // Calculate map bounds
  let bounds: LatLngBounds | undefined;
  if (layerData.geojson?.features && layerData.geojson.features.length > 0) {
    const coords: [number, number][] = [];
    layerData.geojson.features.forEach((feature: any) => {
      if (feature.geometry?.type === 'Point') {
        const [lng, lat] = feature.geometry.coordinates;
        coords.push([lat, lng]);
      } else if (feature.geometry?.type === 'Polygon') {
        feature.geometry.coordinates[0].forEach(([lng, lat]: [number, number]) => {
          coords.push([lat, lng]);
        });
      }
    });
    if (coords.length > 0) {
      bounds = new LatLngBounds(coords);
    }
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Header (hidden in embed mode) */}
      {!isEmbedMode && (
        <header className="border-b bg-card p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold" data-testid="text-layer-name">
                {shareData.layerName}
              </h1>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  {shareData.viewCount} views
                </span>
                {shareData.expiresAt && (
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    Expires {format(new Date(shareData.expiresAt), 'MMM d, yyyy')}
                  </span>
                )}
              </div>
            </div>
            {shareData.embedEnabled && (
              <Badge variant="secondary" data-testid="badge-embed-enabled">
                Embed Enabled
              </Badge>
            )}
          </div>
        </header>
      )}

      {/* Map */}
      <div className="flex-1 relative">
        <MapContainer
          className="h-full w-full"
          center={bounds ? bounds.getCenter() : [0, 0]}
          zoom={bounds ? undefined : 2}
          bounds={bounds}
          boundsOptions={{ padding: [50, 50] }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {layerData.geojson && (
            <GeoJSON
              data={layerData.geojson}
              style={() => ({
                color: shareData.color || '#3b82f6',
                weight: 2,
                fillOpacity: 0.3,
              })}
              onEachFeature={(feature, layer) => {
                // Add popup with configured fields
                if (shareData.popupFields && feature.properties) {
                  const popupContent = shareData.popupFields
                    .map(field => {
                      const value = feature.properties[field];
                      return value ? `<strong>${field}:</strong> ${value}` : null;
                    })
                    .filter(Boolean)
                    .join('<br/>');
                  
                  if (popupContent) {
                    layer.bindPopup(popupContent);
                  }
                }

                // Add label if configured
                if (shareData.labelField && feature.properties[shareData.labelField]) {
                  const label = feature.properties[shareData.labelField];
                  layer.bindTooltip(String(label), { permanent: false, direction: 'top' });
                }
              }}
            />
          )}
        </MapContainer>
      </div>

      {/* Footer (hidden in embed mode) */}
      {!isEmbedMode && (
        <footer className="border-t bg-card p-4 text-center text-sm text-muted-foreground">
          Powered by realmapz
        </footer>
      )}
    </div>
  );
}
