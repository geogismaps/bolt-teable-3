import { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabaseClient';

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();
  
  // Sign in state
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [signingIn, setSigningIn] = useState(false);
  
  // Sign up state
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [organizationName, setOrganizationName] = useState('');
  const [signingUp, setSigningUp] = useState(false);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setSigningIn(true);
    
    try {
      await signIn(signInEmail, signInPassword);
      
      // Get the session to access the token
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.access_token && session?.user) {
        // Check if user needs to change password using Bearer token
        try {
          const checkResponse = await fetch(`/api/supabase/users/${session.user.id}/must-change-password`, {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.access_token}`,
            },
          });
          
          if (checkResponse.ok) {
            const { mustChangePassword } = await checkResponse.json();
            if (mustChangePassword) {
              setLocation('/change-password');
              return;
            }
          }
        } catch (checkError) {
          console.error('Error checking must_change_password:', checkError);
          // Continue with login even if check fails
        }
      }
      
      toast({
        title: 'Welcome back!',
        description: 'You have successfully signed in.',
      });
      setLocation('/settings');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Sign in failed',
        description: error.message || 'Invalid email or password',
      });
    } finally {
      setSigningIn(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSigningUp(true);
    
    try {
      const result = await signUp(signUpEmail, signUpPassword, fullName, organizationName);
      
      // Provision user in our database (organization + user + features)
      if (result.user && result.session) {
        const provisionResponse = await fetch('/api/auth/provision', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${result.session.access_token}`
          },
          body: JSON.stringify({
            userId: result.user.id,
            email: signUpEmail,
            fullName,
            organizationName: organizationName || `${fullName}'s Organization`
          })
        });
        
        if (!provisionResponse.ok) {
          throw new Error('Failed to set up your organization');
        }
      }
      
      toast({
        title: 'Account created!',
        description: 'You can now sign in with your credentials.',
      });
      
      // Clear form
      setSignUpEmail('');
      setSignUpPassword('');
      setFullName('');
      setOrganizationName('');
    } catch (error: any) {
      console.error('Sign-up error:', error);
      toast({
        variant: 'destructive',
        title: 'Sign up failed',
        description: error.message || 'Could not create account',
      });
    } finally {
      setSigningUp(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">realmapz</CardTitle>
          <CardDescription>
            AI-Powered Land & Legal Management
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="signin">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin" data-testid="tab-signin">Sign In</TabsTrigger>
              <TabsTrigger value="signup" data-testid="tab-signup">Sign Up</TabsTrigger>
            </TabsList>
            
            <TabsContent value="signin">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signin-email">Email</Label>
                  <Input
                    id="signin-email"
                    type="email"
                    placeholder="you@example.com"
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    required
                    data-testid="input-signin-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signin-password">Password</Label>
                  <Input
                    id="signin-password"
                    type="password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    required
                    data-testid="input-signin-password"
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={signingIn}
                  data-testid="button-signin"
                >
                  {signingIn ? 'Signing in...' : 'Sign In'}
                </Button>
                <div className="text-center">
                  <Link href="/forgot-password">
                    <Button variant="ghost" className="text-sm" data-testid="link-forgot-password">
                      Forgot your password?
                    </Button>
                  </Link>
                </div>
              </form>
            </TabsContent>
            
            <TabsContent value="signup">
              <form onSubmit={handleSignUp} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-name">Full Name</Label>
                  <Input
                    id="signup-name"
                    type="text"
                    placeholder="John Doe"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    data-testid="input-signup-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="you@example.com"
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    required
                    data-testid="input-signup-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-password">Password</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    required
                    minLength={6}
                    data-testid="input-signup-password"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-org">Organization Name (Optional)</Label>
                  <Input
                    id="signup-org"
                    type="text"
                    placeholder="Acme Corp"
                    value={organizationName}
                    onChange={(e) => setOrganizationName(e.target.value)}
                    data-testid="input-signup-org"
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={signingUp}
                  data-testid="button-signup"
                >
                  {signingUp ? 'Creating account...' : 'Create Account'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
        
        <CardFooter className="flex flex-col space-y-2 text-sm text-muted-foreground">
          <p>No credit card required • Free tier available</p>
        </CardFooter>
      </Card>
    </div>
  );
}
