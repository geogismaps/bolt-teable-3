import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UserManagement } from "@/components/UserManagement";
import { FieldPermissions } from "@/components/FieldPermissions";
import { LayerPermissions } from "@/components/LayerPermissions";
import { Shield, Users, Lock, Activity, Layers } from "lucide-react";
import { PageShell, PageHeader } from "@/components/layout";

export default function PermissionsPage() {
  const [activeTab, setActiveTab] = useState('users');

  // Fetch organizations - for now, use the first one or demo org
  const { data: organizations = [] } = useQuery<any[]>({
    queryKey: ['/api/supabase/organizations'],
  });

  // Use first organization or demo org ID
  const organizationId = organizations[0]?.id || '00000000-0000-0000-0000-000000000001';

  return (
    <PageShell maxWidth="7xl">
      <PageHeader
        icon={Shield}
        title="Permissions & Access Control"
        description="Manage users, roles, and field-level permissions for your organization"
        testId="heading-permissions"
      />
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full max-w-2xl grid-cols-4">
              <TabsTrigger value="users" className="gap-2" data-testid="tab-users">
                <Users className="h-4 w-4" />
                Users
              </TabsTrigger>
              <TabsTrigger value="permissions" className="gap-2" data-testid="tab-permissions">
                <Lock className="h-4 w-4" />
                Field Permissions
              </TabsTrigger>
              <TabsTrigger value="layers" className="gap-2" data-testid="tab-layers">
                <Layers className="h-4 w-4" />
                Layer Permissions
              </TabsTrigger>
              <TabsTrigger value="activity" className="gap-2" data-testid="tab-activity">
                <Activity className="h-4 w-4" />
                Activity Log
              </TabsTrigger>
            </TabsList>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>
                    Add users to your organization and assign them roles. Each role has different default permissions.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6 grid gap-4 md:grid-cols-4">
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                        <h3 className="font-semibold text-sm">Owner</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Full access to everything including billing and settings
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-secondary" />
                        <h3 className="font-semibold text-sm">Admin</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Can manage users and set permissions for all fields
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-muted-foreground" />
                        <h3 className="font-semibold text-sm">Editor</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Can edit all fields by default, limited admin access
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-muted-foreground/50" />
                        <h3 className="font-semibold text-sm">Viewer</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Read-only access, cannot edit any fields
                      </p>
                    </div>
                  </div>
                  <UserManagement organizationId={organizationId} />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Field Permissions Tab */}
            <TabsContent value="permissions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Field-Level Permissions</CardTitle>
                  <CardDescription>
                    Control which fields each user can view, edit, or hide. Custom permissions override role defaults.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6 grid gap-4 md:grid-cols-3">
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-green-500" />
                        <h3 className="font-semibold text-sm">Edit Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        User can view and modify field values in Google Sheets
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <h3 className="font-semibold text-sm">View Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        User can see field values but cannot make changes
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-red-500" />
                        <h3 className="font-semibold text-sm">Hidden Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Field is completely hidden from user's view
                      </p>
                    </div>
                  </div>
                  <FieldPermissions organizationId={organizationId} />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Layer Permissions Tab */}
            <TabsContent value="layers" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Layer-Level Permissions</CardTitle>
                  <CardDescription>
                    Control which layers each user can access. Viewers can only view layers, Editors and Admins can edit by default.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6 grid gap-4 md:grid-cols-3">
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-green-500" />
                        <h3 className="font-semibold text-sm">Edit Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        User can view layer on map and edit feature attributes
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <h3 className="font-semibold text-sm">View Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        User can see layer on map but cannot edit features
                      </p>
                    </div>
                    <div className="border rounded-md p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-2 w-2 rounded-full bg-red-500" />
                        <h3 className="font-semibold text-sm">Hidden Permission</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Layer is completely hidden from user's map
                      </p>
                    </div>
                  </div>
                  <LayerPermissions organizationId={organizationId} />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Activity Log Tab */}
            <TabsContent value="activity" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Activity Log</CardTitle>
                  <CardDescription>
                    Audit trail of all permission changes and user management actions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>Activity logging is enabled and tracking all changes.</p>
                    <p className="text-sm mt-2">
                      Activity logs can be viewed via the API endpoint: <code className="bg-muted px-2 py-1 rounded">/api/supabase/activity/:orgId</code>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
    </PageShell>
  );
}
