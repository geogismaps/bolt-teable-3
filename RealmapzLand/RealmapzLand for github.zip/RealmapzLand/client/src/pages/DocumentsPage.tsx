import { useState } from 'react';
import DocumentList from '@/components/DocumentList';
import Timeline from '@/components/Timeline';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Upload, FileText, Clock } from 'lucide-react';
import { PageShell, PageHeader } from '@/components/layout';

export default function DocumentsPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const sampleDocuments = [
    {
      id: 'doc1',
      name: 'Property_Deed_2023.pdf',
      type: 'pdf' as const,
      size: '2.4 MB',
      uploadedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      uploadedBy: 'John Smith',
      parcelId: 'P001',
    },
    {
      id: 'doc2',
      name: 'Survey_Report_Final.pdf',
      type: 'pdf' as const,
      size: '5.1 MB',
      uploadedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      uploadedBy: 'Jane Doe',
      parcelId: 'P002',
    },
    {
      id: 'doc3',
      name: 'Aerial_Photo_2024.jpg',
      type: 'image' as const,
      size: '8.7 MB',
      uploadedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      uploadedBy: 'Admin',
    },
  ];

  const sampleEvents = [
    {
      id: '1',
      date: new Date(2024, 0, 15),
      type: 'ownership' as const,
      title: 'Ownership Transfer',
      description: 'Property transferred from John Smith to Jane Doe',
      owner: 'Jane Doe',
    },
    {
      id: '2',
      date: new Date(2023, 8, 22),
      type: 'document' as const,
      title: 'Survey Report Filed',
      description: 'Official land survey completed and documented',
      documentId: 'doc-123',
    },
    {
      id: '3',
      date: new Date(2023, 3, 10),
      type: 'survey' as const,
      title: 'Property Survey',
      description: 'Boundary survey conducted by certified surveyor',
    },
  ];

  return (
    <PageShell maxWidth="7xl">
      <PageHeader
        icon={FileText}
        title="Documents & Timeline"
        description="Manage documents and view ownership timeline"
        testId="heading-documents"
        actions={
          <Button data-testid="button-upload-document">
            <Upload className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        }
      />

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList>
          <TabsTrigger value="documents" className="gap-2" data-testid="tab-documents">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="timeline" className="gap-2" data-testid="tab-timeline">
            <Clock className="h-4 w-4" />
            Timeline
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-4">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-documents"
            />
          </div>

          <DocumentList
            documents={sampleDocuments}
            onView={(doc) => console.log('View:', doc)}
            onDownload={(doc) => console.log('Download:', doc)}
          />
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          <Timeline
            events={sampleEvents}
            onEventClick={(event) => console.log('Event:', event)}
          />
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}
