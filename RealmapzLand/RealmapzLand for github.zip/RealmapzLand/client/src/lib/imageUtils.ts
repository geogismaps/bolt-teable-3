/**
 * Image detection and processing utilities
 */

/**
 * Common image file extensions
 */
const IMAGE_EXTENSIONS = [
  'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg',
  'tiff', 'tif', 'ico', 'heic', 'heif'
];

/**
 * Extensions/patterns that suggest 360° panorama images
 * Convention: Files with "360", "pano", "panorama" in name or specific extensions
 */
const PANORAMA_PATTERNS = [
  /360/i,
  /pano/i,
  /panorama/i,
  /equirectangular/i,
  /spherical/i
];

/**
 * Check if a URL points to an image file
 */
export function isImageUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  
  try {
    const urlLower = url.toLowerCase();
    
    // Check for image extensions
    const hasImageExtension = IMAGE_EXTENSIONS.some(ext => 
      urlLower.includes(`.${ext}`)
    );
    
    // Check for Google Drive image URLs
    const isGoogleDriveImage = (
      urlLower.includes('drive.google.com') && 
      (urlLower.includes('/file/') || urlLower.includes('uc?id='))
    );
    
    return hasImageExtension || isGoogleDriveImage;
  } catch (error) {
    return false;
  }
}

/**
 * Check if an image URL is likely a 360° panorama
 * Based on filename patterns or column names
 */
export function is360Panorama(url: string, columnName?: string): boolean {
  if (!url) return false;
  
  const urlLower = url.toLowerCase();
  const columnLower = columnName?.toLowerCase() || '';
  
  // Check if filename or column name suggests 360° panorama
  const urlMatches = PANORAMA_PATTERNS.some(pattern => pattern.test(urlLower));
  const columnMatches = PANORAMA_PATTERNS.some(pattern => pattern.test(columnLower));
  
  return urlMatches || columnMatches;
}

/**
 * Convert Google Drive URL to embeddable/direct image URL
 */
export function getGoogleDriveImageUrl(url: string): string {
  if (!url.includes('drive.google.com')) return url;
  
  // Extract file ID from various Google Drive URL formats
  let fileId = null;
  
  // Format: https://drive.google.com/file/d/{fileId}/view
  const fileMatch = url.match(/\/file\/d\/([^\/]+)/);
  if (fileMatch) {
    fileId = fileMatch[1];
  }
  
  // Format: https://drive.google.com/open?id={fileId}
  const openMatch = url.match(/[?&]id=([^&]+)/);
  if (openMatch) {
    fileId = openMatch[1];
  }
  
  // Format: https://drive.google.com/uc?id={fileId}
  const ucMatch = url.match(/uc\?id=([^&]+)/);
  if (ucMatch) {
    fileId = ucMatch[1];
  }
  
  // Return direct image URL if file ID found
  if (fileId) {
    return `https://drive.google.com/uc?export=view&id=${fileId}`;
  }
  
  return url;
}

/**
 * Generate thumbnail URL for an image
 * For Google Drive, uses thumbnail parameter
 */
export function getThumbnailUrl(url: string, size: number = 100): string {
  const imageUrl = getGoogleDriveImageUrl(url);
  
  // For Google Drive, add thumbnail size parameter
  if (imageUrl.includes('drive.google.com/uc')) {
    return imageUrl.replace('export=view', `export=view&sz=w${size}`);
  }
  
  // For other images, return original (browser will scale)
  return imageUrl;
}

/**
 * Detect which columns in a dataset contain image URLs
 */
export function detectImageColumns(headers: string[], rows: any[][]): Set<string> {
  const imageColumns = new Set<string>();
  
  if (!headers || !rows || rows.length === 0) return imageColumns;
  
  headers.forEach((header, colIndex) => {
    // Check column name for image-related keywords
    const headerLower = header.toLowerCase();
    const hasImageKeyword = ['image', 'photo', 'picture', 'img', 'thumbnail'].some(
      keyword => headerLower.includes(keyword)
    );
    
    if (hasImageKeyword) {
      imageColumns.add(header);
      return;
    }
    
    // Sample first few rows to check if values are image URLs
    const sampleSize = Math.min(5, rows.length);
    let imageUrlCount = 0;
    
    for (let i = 0; i < sampleSize; i++) {
      const value = rows[i][colIndex];
      if (value && isImageUrl(String(value))) {
        imageUrlCount++;
      }
    }
    
    // If majority of sampled values are image URLs, mark column as image column
    if (imageUrlCount >= sampleSize * 0.6) {
      imageColumns.add(header);
    }
  });
  
  return imageColumns;
}
