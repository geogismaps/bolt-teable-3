/**
 * Content Type Detection Utilities
 * Intelligently detects PDFs, images, 360 panoramas, and generic links
 */

/**
 * Content types we can display
 */
export type ContentType = 'pdf' | 'image' | 'panorama' | 'link';

/**
 * Common PDF file patterns
 */
const PDF_PATTERNS = [
  /\.pdf$/i,
  /\.pdf[?#]/i,  // PDF with query params or fragments
];

/**
 * Common image file extensions
 */
const IMAGE_EXTENSIONS = [
  'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg',
  'tiff', 'tif', 'ico', 'heic', 'heif'
];

/**
 * Patterns that suggest 360° panorama images
 */
const PANORAMA_PATTERNS = [
  /360/i,
  /pano/i,
  /panorama/i,
  /equirectangular/i,
  /spherical/i
];

/**
 * Detect content type from URL and optional column name
 * Priority: PDF → 360 Panorama → Image → Link
 */
export function detectContentType(url: string, columnName?: string): ContentType {
  if (!url || typeof url !== 'string') return 'link';
  
  const urlLower = url.toLowerCase();
  const columnLower = columnName?.toLowerCase() || '';
  
  // 1. Check for PDF (highest priority)
  if (isPDFUrl(url)) {
    return 'pdf';
  }
  
  // 2. Check for 360 panorama (before regular images)
  if (is360Panorama(url, columnName)) {
    return 'panorama';
  }
  
  // 3. Check for images
  if (isImageUrl(url)) {
    return 'image';
  }
  
  // 4. Default to link
  return 'link';
}

/**
 * Check if a URL points to a PDF file
 */
export function isPDFUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  
  const urlLower = url.toLowerCase();
  
  // Check for explicit .pdf extension in URL
  if (urlLower.includes('.pdf')) return true;
  
  // Check for PDF patterns
  const hasPDFPattern = PDF_PATTERNS.some(pattern => pattern.test(url));
  if (hasPDFPattern) return true;
  
  // For Google Drive URLs without .pdf extension, check the filename
  // Sometimes Drive URLs have filenames in the query params
  if (urlLower.includes('drive.google.com')) {
    try {
      const urlObj = new URL(url);
      const filename = urlObj.searchParams.get('filename') || '';
      if (filename.toLowerCase().endsWith('.pdf')) return true;
    } catch (e) {
      // Invalid URL, continue without filename check
    }
  }
  
  return false;
}

/**
 * Check if a URL points to an image file
 */
export function isImageUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  
  const urlLower = url.toLowerCase();
  
  // Don't classify PDFs as images
  if (isPDFUrl(url)) return false;
  
  // Check for image extensions
  const hasImageExtension = IMAGE_EXTENSIONS.some(ext => 
    urlLower.includes(`.${ext}`)
  );
  
  if (hasImageExtension) return true;
  
  // Check for Google Drive URLs
  if (urlLower.includes('drive.google.com')) {
    // Check filename parameter first
    try {
      const urlObj = new URL(url);
      const filename = urlObj.searchParams.get('filename') || '';
      const filenameLower = filename.toLowerCase();
      
      // If filename has image extension, it's an image
      if (IMAGE_EXTENSIONS.some(ext => filenameLower.endsWith(`.${ext}`))) {
        return true;
      }
      
      // If filename has PDF extension, NOT an image
      if (filenameLower.endsWith('.pdf')) {
        return false;
      }
    } catch (e) {
      // Invalid URL, continue with fallback logic
    }
    
    // Drive URLs with /file/d/ or /uc?export=view could be images OR PDFs
    // Without explicit extension, we can't be sure, so treat as link/generic
    // Only trust explicit image extensions
    return false;
  }
  
  return false;
}

/**
 * Check if an image URL is likely a 360° panorama
 * Based on filename patterns or column names
 */
export function is360Panorama(url: string, columnName?: string): boolean {
  if (!url) return false;
  
  const urlLower = url.toLowerCase();
  const columnLower = columnName?.toLowerCase() || '';
  
  // Check if filename or column name suggests 360° panorama
  const urlMatches = PANORAMA_PATTERNS.some(pattern => pattern.test(urlLower));
  const columnMatches = PANORAMA_PATTERNS.some(pattern => pattern.test(columnLower));
  
  return urlMatches || columnMatches;
}

/**
 * Convert URL to appropriate format for viewer
 */
export function getViewerUrl(url: string, contentType: ContentType): string {
  if (!url.includes('drive.google.com')) return url;
  
  // Extract Google Drive file ID
  const fileId = extractGoogleDriveFileId(url);
  if (!fileId) return url;
  
  switch (contentType) {
    case 'pdf':
      // PDF preview URL
      return `https://drive.google.com/file/d/${fileId}/preview`;
    
    case 'image':
    case 'panorama':
      // Direct image view URL
      return `https://drive.google.com/uc?export=view&id=${fileId}`;
    
    case 'link':
    default:
      // Preview URL for other documents
      return `https://drive.google.com/file/d/${fileId}/preview`;
  }
}

/**
 * Extract file ID from various Google Drive URL formats
 */
export function extractGoogleDriveFileId(url: string): string | null {
  if (!url.includes('drive.google.com')) return null;
  
  // Format 1: /file/d/{fileId}
  let match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  
  // Format 2: open?id={fileId}
  match = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  
  // Format 3: uc?id={fileId}
  match = url.match(/uc\?id=([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  
  return null;
}

/**
 * Generate thumbnail URL for display in table
 */
export function getThumbnailUrl(url: string, size: number = 100): string {
  const fileId = extractGoogleDriveFileId(url);
  
  if (fileId) {
    // Google Drive thumbnail
    return `https://drive.google.com/uc?export=view&id=${fileId}&sz=w${size}`;
  }
  
  // For other URLs, return original (browser will scale)
  return url;
}
