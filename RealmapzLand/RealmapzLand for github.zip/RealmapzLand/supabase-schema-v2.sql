-- realmapz SaaS Platform - Complete Schema
-- Run this SQL in your Supabase SQL Editor (https://app.supabase.com → SQL Editor)
-- This creates tables for multi-tenant SaaS with authentication, feature flags, and billing

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- 1. ORGANIZATIONS TABLE (Enhanced for SaaS)
-- ============================================
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  -- Billing fields for Stripe integration
  billing_plan TEXT DEFAULT 'free', -- 'free', 'basic', 'pro', 'enterprise'
  stripe_customer_id TEXT UNIQUE,
  stripe_subscription_id TEXT,
  subscription_status TEXT DEFAULT 'inactive', -- 'active', 'trialing', 'past_due', 'canceled', 'inactive'
  trial_ends_at TIMESTAMPTZ,
  -- Usage limits
  max_users INTEGER DEFAULT 1,
  max_connections INTEGER DEFAULT 1,
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ============================================
-- 2. USERS TABLE (Linked to Supabase Auth)
-- ============================================
-- Users are linked to auth.users via id
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role TEXT NOT NULL DEFAULT 'viewer', -- owner, admin, editor, viewer
  -- Auth metadata
  is_active BOOLEAN DEFAULT true,
  last_sign_in_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_org ON users(organization_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ============================================
-- 3. FEATURE DEFINITIONS (Master Feature List)
-- ============================================
CREATE TABLE IF NOT EXISTS feature_definitions (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  tier TEXT NOT NULL DEFAULT 'free', -- 'free', 'basic', 'pro', 'enterprise'
  default_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ============================================
-- 4. ORGANIZATION FEATURES (Feature Flags)
-- ============================================
CREATE TABLE IF NOT EXISTS organization_features (
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  feature_key TEXT REFERENCES feature_definitions(key) ON DELETE CASCADE,
  enabled BOOLEAN DEFAULT false,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  PRIMARY KEY (organization_id, feature_key)
);

-- Index for feature checks
CREATE INDEX IF NOT EXISTS idx_org_features ON organization_features(organization_id, enabled);

-- ============================================
-- 5. GOOGLE_SHEET_CONNECTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS google_sheet_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  spreadsheet_id TEXT NOT NULL,
  spreadsheet_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_connections_org ON google_sheet_connections(organization_id);

-- ============================================
-- 6. FIELD_PERMISSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS field_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES google_sheet_connections(id) ON DELETE CASCADE,
  sheet_name TEXT NOT NULL,
  field_name TEXT NOT NULL,
  permission_level TEXT NOT NULL, -- view, edit, hidden
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, connection_id, sheet_name, field_name)
);

CREATE INDEX IF NOT EXISTS idx_field_permissions_user ON field_permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_connection ON field_permissions(connection_id);
CREATE INDEX IF NOT EXISTS idx_field_permissions_lookup ON field_permissions(user_id, connection_id, sheet_name);

-- ============================================
-- 7. ACTIVITY_LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_activity_org ON activity_logs(organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_logs(user_id, created_at DESC);

-- ============================================
-- 8. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_sheet_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE field_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- Organizations: Users can only see their own organization
CREATE POLICY "Users can view their own organization"
  ON organizations
  FOR SELECT
  USING (
    id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Organizations: Owners can update their organization
CREATE POLICY "Owners can update their organization"
  ON organizations
  FOR UPDATE
  USING (
    id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role = 'owner'
    )
  );

-- Users: Users can view users in their organization
CREATE POLICY "Users can view users in their organization"
  ON users
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Users: Admins and owners can manage users in their org
CREATE POLICY "Admins can manage users in their organization"
  ON users
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Feature Definitions: Everyone can read (public catalog)
CREATE POLICY "Anyone can view feature definitions"
  ON feature_definitions
  FOR SELECT
  USING (true);

-- Organization Features: Users can view their org's features
CREATE POLICY "Users can view their organization features"
  ON organization_features
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Organization Features: Owners can manage features
CREATE POLICY "Owners can manage organization features"
  ON organization_features
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role = 'owner'
    )
  );

-- Connections: Users can view connections in their organization
CREATE POLICY "Users can view connections in their organization"
  ON google_sheet_connections
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Connections: Admins can manage connections
CREATE POLICY "Admins can manage connections in their organization"
  ON google_sheet_connections
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Field Permissions: Users can view permissions in their organization
CREATE POLICY "Users can view permissions in their organization"
  ON field_permissions
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- Field Permissions: Admins can manage permissions
CREATE POLICY "Admins can manage permissions in their organization"
  ON field_permissions
  FOR ALL
  USING (
    organization_id IN (
      SELECT organization_id FROM users 
      WHERE id = auth.uid() AND role IN ('admin', 'owner')
    )
  );

-- Activity Logs: Users can view logs in their organization
CREATE POLICY "Users can view activity logs in their organization"
  ON activity_logs
  FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- ============================================
-- SERVICE ROLE POLICIES (for triggers & system operations)
-- ============================================

-- Allow service_role to insert organizations (for signup trigger)
CREATE POLICY "Service role can insert organizations"
  ON organizations
  FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

-- Allow service_role to insert users (for signup trigger)
CREATE POLICY "Service role can insert users"
  ON users
  FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

-- Allow service_role to insert organization features (for signup trigger)
CREATE POLICY "Service role can insert organization features"
  ON organization_features
  FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

-- Activity Logs: System can insert logs (all authenticated users)
CREATE POLICY "Authenticated users can create activity logs"
  ON activity_logs
  FOR INSERT
  WITH CHECK (
    organization_id IN (
      SELECT organization_id FROM users WHERE id = auth.uid()
    )
  );

-- ============================================
-- 9. FUNCTIONS
-- ============================================

-- Function: Create organization and first user on sign-up
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  new_org_id UUID;
BEGIN
  -- Create new organization for user
  INSERT INTO organizations (name, billing_plan, max_users, max_connections)
  VALUES (
    COALESCE(NEW.raw_user_meta_data->>'organization_name', 'My Organization'),
    'free',
    1,
    1
  )
  RETURNING id INTO new_org_id;

  -- Create user record linked to auth.users
  INSERT INTO users (id, organization_id, email, full_name, role)
  VALUES (
    NEW.id,
    new_org_id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    'owner' -- First user is always owner
  );

  -- Initialize default features for free tier
  INSERT INTO organization_features (organization_id, feature_key, enabled)
  SELECT new_org_id, key, (tier = 'free')
  FROM feature_definitions;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger: Auto-create organization on user sign-up
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Function: Check if feature is enabled for organization
CREATE OR REPLACE FUNCTION is_feature_enabled(
  p_organization_id UUID,
  p_feature_key TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  v_enabled BOOLEAN;
BEGIN
  SELECT enabled INTO v_enabled
  FROM organization_features
  WHERE organization_id = p_organization_id
    AND feature_key = p_feature_key;
  
  -- If not explicitly set, check default from feature definition
  IF v_enabled IS NULL THEN
    SELECT default_enabled INTO v_enabled
    FROM feature_definitions
    WHERE key = p_feature_key;
  END IF;
  
  RETURN COALESCE(v_enabled, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get user's effective permissions for a field
CREATE OR REPLACE FUNCTION get_user_field_permission(
  p_user_id UUID,
  p_connection_id UUID,
  p_sheet_name TEXT,
  p_field_name TEXT
)
RETURNS TEXT AS $$
DECLARE
  v_permission TEXT;
  v_user_role TEXT;
BEGIN
  -- Check if there's an explicit field permission
  SELECT permission_level INTO v_permission
  FROM field_permissions
  WHERE user_id = p_user_id
    AND connection_id = p_connection_id
    AND sheet_name = p_sheet_name
    AND field_name = p_field_name;
  
  IF v_permission IS NOT NULL THEN
    RETURN v_permission;
  END IF;
  
  -- Fallback to role-based default permissions
  SELECT role INTO v_user_role
  FROM users
  WHERE id = p_user_id;
  
  -- Default permissions based on role
  RETURN CASE
    WHEN v_user_role IN ('owner', 'admin') THEN 'edit'
    WHEN v_user_role = 'editor' THEN 'edit'
    WHEN v_user_role = 'viewer' THEN 'view'
    ELSE 'hidden'
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 10. SEED FEATURE DEFINITIONS
-- ============================================

INSERT INTO feature_definitions (key, name, description, tier, default_enabled) VALUES
  ('attribute_editing', 'Attribute Editing', 'Edit data directly in Google Sheets from the app', 'basic', false),
  ('image_viewer', 'Image Viewer', 'View images embedded in your data', 'free', true),
  ('pdf_viewer', 'PDF Viewer', 'View PDF documents embedded in your data', 'basic', false),
  ('panorama_viewer', '360° Panorama Viewer', 'View 360° panoramic images with interactive controls', 'pro', false),
  ('drone_imagery', 'Drone Imagery Support', 'Support for high-resolution drone imagery and aerial photos', 'pro', false),
  ('field_permissions', 'Field-Level Permissions', 'Granular control over which users can view/edit specific fields', 'basic', false),
  ('advanced_filtering', 'Advanced Filtering', 'Complex filter rules with AND/OR logic', 'pro', false),
  ('export_data', 'Data Export', 'Export your data as GeoJSON, CSV, or Shapefile', 'basic', false),
  ('api_access', 'API Access', 'REST API access to your data programmatically', 'enterprise', false),
  ('custom_styling', 'Custom Map Styling', 'Advanced symbology and custom map layer styling', 'pro', false),
  ('user_management', 'User Management', 'Invite and manage multiple users in your organization', 'basic', false)
ON CONFLICT (key) DO NOTHING;

-- ============================================
-- SETUP COMPLETE!
-- ============================================

SELECT 
  'Supabase SaaS schema setup complete!' as message,
  (SELECT COUNT(*) FROM feature_definitions) as features_count;
